# 测试报告 rep_705ac8398bf3

- 结论：failed
- 运行：run_e5ab8b382b94
- 范围：2/2
- 源码提交：未记录
- 规则版本：未记录
- 环境 Python：3.11.9
- 服务：未配置

AI 摘要未采用，以下为事实摘要
摘要：本次范围 2/2，通过 1，失败 1，阻塞或未完成 0，未覆盖验收项 0。

## 范围与覆盖
- 已选验收项：2
- 适用验收项：2
- 覆盖验收项：2
- 通过：1
- 失败：1
- 阻塞或未完成：0

## 未覆盖清单
- 无

## 分层计数
- L1：4 个用例
- L2：0 个用例
- L3：0 个用例

## 用例明细
| 用例 | 验收项 | 分层 | 结果 | 证据 |
| --- | --- | --- | --- | --- |
| case_57fee0535c2d | ai_e01d33a73f54 | L1 | failed | evidence/case_57fee0535c2d-0.log |
| case_0d003feffcba | ai_e01d33a73f54 | L1 | failed | evidence/case_0d003feffcba-0.log |
| case_a4d556194661 | ai_2fedd100b454 | L1 | passed | evidence/case_a4d556194661-0.log |
| case_c4df49ace3cd | ai_2fedd100b454 | L1 | passed | evidence/case_c4df49ace3cd-0.log |

## 失败证据
- case_57fee0535c2d：evidence/case_57fee0535c2d-0.log
- case_0d003feffcba：evidence/case_0d003feffcba-0.log

## AI 分析
### 分析状态：generated
**观察**：运行 run_e5ab8b382b94 状态为 completed，共 4 个用例：case_57fee0535c2d 与 case_0d003feffcba 失败，case_a4d556194661 与 case_c4df49ace3cd 通过。两个失败用例各仅尝试 1 次，开始与结束时间均为 2026-11-17T12:28:01+08:00（耗时约 0 秒），attempt 的 message 字段为空，evidence_refs 指向 evidence/case_57fee0535c2d-0.log 与 evidence/case_0d003feffcba-0.log。两个通过用例在 12:28:51 与 12:28:52 执行。run 的 service_started 为 false、service_name 为空、l1 为 null、request_ids 为空、analysis 与 mock_judgement 均为空数组。
**证据引用**：evidence/case_57fee0535c2d-0.log、evidence/case_0d003feffcba-0.log
**候选原因**：
- 两个失败用例在 0 秒内即失败且无错误消息，疑似用例前置条件或环境准备阶段（如服务未启动、依赖缺失）直接中断（把握程度：medium）
- run 记录 service_started=false 且 service_name 为空，失败用例可能依赖未启动的被测服务（把握程度：medium）
- 失败用例与通过用例执行时间相差约 50 秒，失败用例可能属于先执行的快速失败批次，存在执行顺序或初始化时序问题（把握程度：low）
**尚未验证**：
- 未读取 evidence/case_57fee0535c2d-0.log 与 evidence/case_0d003feffcba-0.log 的实际内容，失败根因尚未确认
- 未确认两个失败用例是否依赖被测服务，以及 service_started=false 是否为其失败的直接原因
- 未确认失败用例与通过用例在 scope 中对应的 acceptance_item（ai_e01d33a73f54、ai_2fedd100b454）归属关系
**下一步**：
- 读取两个失败用例的 evidence 日志，提取具体错误信息与堆栈
- 核对失败用例是否依赖被测服务，并确认服务启动状态与用例执行顺序
- 根据日志定位根因后，单独重跑 case_57fee0535c2d 与 case_0d003feffcba 验证是否可复现

## 问题
- issue_866da816fc3d [P2/pending] 用例失败：命令行入口 python -m aitest.cli project.list 正常退出（退出码 0）（发生 1 次）
- issue_87b7f78cdaec [P2/closed] 用例失败：命令行入口可被调用并输出帮助信息，退出码为 0（发生 1 次）
- issue_e82419c31d25 [P2/pending] 用例失败：doctor 子命令可执行并返回退出码 0，输出包含诊断信息（发生 1 次）
- issue_fecfbb3fa63b [P2/pending] 用例失败：命令行入口 python -m aitest.cli doctor 正常退出（退出码 0）（发生 1 次）

## Mock 判定
- 未判定

## 模板处置
- 未应用模板

## 验收意见
未填写验收意见

## 证据索引
| 引用 | 存在 | 字节 |
| --- | --- | --- |
| evidence/case_57fee0535c2d-0.log | 是 | 164 |
| evidence/case_0d003feffcba-0.log | 是 | 164 |
| evidence/case_a4d556194661-0.log | 是 | 357 |
| evidence/case_c4df49ace3cd-0.log | 是 | 100 |
