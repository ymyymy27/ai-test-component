# 测试报告 rep_1dcbcd4af67d

## 结论
本次运行未完成：已选 6/11，未覆盖 5，失败 0，阻塞或未完成 4。

- 结论值：incomplete
- 运行：run_8f01a8e801df
- 范围：6/11
- 未覆盖：5
- 失败：0
- 源码提交：未记录
- 规则版本：未记录
- 环境 Python：3.11.9
- 服务：未配置

AI 摘要未采用，以下为事实摘要：
> 本次范围 6/11，通过 2，失败 0，阻塞或未完成 4，未覆盖验收项 5。

## 范围与覆盖
- 已选验收项：6
- 适用验收项：11
- 覆盖验收项：6
- 通过：2
- 失败：0
- 阻塞或未完成：4

## 验收项主表
| 验收项 | 内容 | 模块 | 结果 | 用例 |
| --- | --- | --- | --- | --- |
| ai_357769aba1e2 | L1/L2/L3 执行 | - | blocked | case_f014ee5b1fd0 |
| ai_5f79fe66d2d7 | 证据生成 | - | blocked | case_3174ecf79984 |
| ai_188c45e27606 | 判定与报告 | - | blocked | case_5c99e7aa0357 |
| ai_62b367be89c1 | 验收状态 status.json | - | blocked | case_c51af0223f14 |
| ai_e6688e901ffd | 面板 vitest 测试 | - | passed | case_793ba041277f |
| ai_96549fad4a80 | 扩展 node test | - | passed | case_2908f2fc1219 |
| ai_2cc7160475c8 | CLI 版本输出 | - | not_selected | - |
| ai_082c7749287f | doctor 子命令诊断输出与退出码 | - | not_selected | - |
| ai_26cc45cf5eb3 | project.list 子命令退出码 | - | not_selected | - |
| ai_67c8a8b0858a | --help 子命令列表 | - | not_selected | - |
| ai_10803930426b | stdin JSON 输入与单行 JSON 输出约定 | - | not_selected | - |

## 未覆盖清单
- ai_2cc7160475c8：CLI 版本输出
- ai_082c7749287f：doctor 子命令诊断输出与退出码
- ai_26cc45cf5eb3：project.list 子命令退出码
- ai_67c8a8b0858a：--help 子命令列表
- ai_10803930426b：stdin JSON 输入与单行 JSON 输出约定

## 未验证项
- 无

## 分层计数
- L1：0 个用例
- L2：6 个用例
- L3：0 个用例

## 项目级检查（L1，不计验收项覆盖）
- 未配置项目级检查

## 用例明细
| 用例 | 验收项 | 分层 | 结果 | 证据 |
| --- | --- | --- | --- | --- |
| case_f014ee5b1fd0 | ai_357769aba1e2 | L2 | blocked | - |
| case_3174ecf79984 | ai_5f79fe66d2d7 | L2 | blocked | - |
| case_5c99e7aa0357 | ai_188c45e27606 | L2 | blocked | - |
| case_c51af0223f14 | ai_62b367be89c1 | L2 | blocked | - |
| case_793ba041277f | ai_e6688e901ffd | L2 | passed | evidence/case_793ba041277f-0.log |
| case_2908f2fc1219 | ai_96549fad4a80 | L2 | passed | evidence/case_2908f2fc1219-0.log |

## 失败证据
- 无失败用例

## 涉及模块
- 已映射模块：无
- 未映射文件：无

## AI 分析
### 分析状态：generated
**观察**：本次运行共 6 个用例：4 个（case_f014ee5b1fd0、case_3174ecf79984、case_5c99e7aa0357、case_c51af0223f14）结果为 blocked，消息均为“依赖安装失败”；2 个（case_793ba041277f、case_2908f2fc1219）在 16:27:58-16:27:59 通过。run 级 dependency_install_ok=false，dependencies 为 [pytest]，evidence_refs 含 evidence/deps-install.log。
**证据引用**：evidence/deps-install.log、evidence/case_793ba041277f-0.log、evidence/case_2908f2fc1219-0.log
**候选原因**：
- 依赖安装阶段失败（dependency_install_ok=false），导致依赖 pytest 的 4 个用例被阻塞（把握程度：high）
- 依赖安装失败可能由网络/包源不可达或环境权限问题引起（把握程度：unknown）
- 通过的两个用例可能不依赖 pytest 或使用已存在的环境（把握程度：low）
**尚未验证**：
- evidence/deps-install.log 的具体错误内容尚未读取，无法确定安装失败根因
- 4 个 blocked 用例是否确实依赖 pytest 尚未核实
- 通过用例与阻塞用例的环境差异尚未验证
**下一步**：
- 读取 evidence/deps-install.log 定位安装失败的具体错误
- 确认 4 个 blocked 用例的依赖声明与 pytest 的关系
- 修复依赖安装（如更换包源或预装 pytest）后重跑 blocked 用例


## 问题
- 问题数：0；本运行失败次数：0
- 无

## Mock 判定
- @：unknown（达到读取上限（最多 40 个文件、3 层），未判定）
- @playwright：unknown（达到读取上限（最多 40 个文件、3 层），未判定）
- @vue：unknown（达到读取上限（最多 40 个文件、3 层），未判定）
- api.example.com：unknown（达到读取上限（最多 40 个文件、3 层），未判定）
- app：unknown（达到读取上限（最多 40 个文件、3 层），未判定）
- esbuild：unknown（达到读取上限（最多 40 个文件、3 层），未判定）
- example：unknown（达到读取上限（最多 40 个文件、3 层），未判定）
- example.invalid：unknown（达到读取上限（最多 40 个文件、3 层），未判定）
- flaskr：unknown（达到读取上限（最多 40 个文件、3 层），未判定）
- github.com：unknown（达到读取上限（最多 40 个文件、3 层），未判定）
- mirror.invalid：unknown（达到读取上限（最多 40 个文件、3 层），未判定）
- sample：unknown（达到读取上限（最多 40 个文件、3 层），未判定）

## 模板处置
- 未应用模板

## 验收意见
未填写验收意见

## 证据索引
| 引用 | 存在 | 字节 | 媒体类型 | sha256 |
| --- | --- | --- | --- | --- |
| evidence/deps-install.log | 是 | 68 | application/octet-stream | 967ea4cf5fc978c3748b32fd50f5d327844b2ae72b5218dffcbfd43ac2ac4504 |
| evidence/case_793ba041277f-0.log | 是 | 1646 | application/octet-stream | fb5856d56d93af9824c646635d408903404c07148925d3fd0ccb88abdc0c9dd2 |
| evidence/case_2908f2fc1219-0.log | 是 | 3808 | application/octet-stream | dda0b64eea42a444dbf1513a9ef048612db4f6778e910103442699cd58ddcd02 |
