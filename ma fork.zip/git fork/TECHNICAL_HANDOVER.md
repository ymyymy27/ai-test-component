# 技术交接文档 · `ai-test-component`

> **给接手者的话**：这份文档的目标是"你不用问我任何问题就能继续开发"。
> 它记录事实、约定、陷阱与出处；所有指标都可在本机复现（每条都给了命令）。
> 有疑问时，**以 `附件/` 两份基线文档为准**，其次才是本文档与 `docs/adr/`。

| | |
| --- | --- |
| 当前版本 | `0.1.0`（`pyproject.toml`，单一来源见 `src/ai_test/version.py`） |
| 交接时状态 | Stage 0 完成；**M1 存储与写入内核第①②③片完成、第④片完成一半**（详见 §12） |
| 规模 | `src/` 69 文件 / 2,945 行；`tests/` 24 文件 / 1,976 行；`docs/` 8 篇 / 678 行 |
| 门禁现状 | `ruff` 0 问题；`mypy --strict` 67 文件 0 问题；`pytest` **85 passed / 6 skipped**；M1 出口判据 **6/6 绿** |
| 基线 | `附件/AI辅助测试平台需求文档_v1.0.md`（494 行）、`附件/AI辅助测试平台技术架构文档_v2.4.md`（563 行） |

---

## 0. 建议的阅读顺序

| 顺序 | 文档 | 用途 |
| --- | --- | --- |
| 1 | 本文 §1–§3 | 知道要做什么、怎么跑起来 |
| 2 | `README.md` | 项目简介与命令速查 |
| 3 | `docs/architecture.md` | 分层、依赖方向、为什么这么分 |
| 4 | **本文 §5（存储内核）** | 代码里最难、最需要先懂的部分 |
| 5 | `docs/adr/ADR-001/002/003` | 三个关键决策的完整推理（含"被否方案"与实测） |
| 6 | `IMPLEMENTATION_PLAN.md` §16 | 逐片执行记录、出口判据、未做项 |
| 7 | `CODE_REVIEW.md` | 骨架里的问题清单与修复跟踪（**接手前必读**：里面还有未修项） |
| 8 | `PROGRESS_REPORT.md` / `DAILY_2026-09-12.md` | 累计进度 / 最近一天进展 |
| 9 | `docs/operations.md`、`docs/formats.md`、`docs/integration.md` | 运维、数据格式、接入契约 |

---

## 1. 项目是什么

**一句话**：让小型研发团队把"这次到底测了什么、真的测过了吗、有没有糊弄"讲清楚。组件不替你测，它负责让每个"通过了"都必须有可追溯的证据（原始输出、请求响应、数据库结果、操作者、版本、模拟数据声明），并由**两个不同的人**签字验收。

**三条硬约束**（架构 §1:13，违反即架构性错误）：

1. **零数据库**（不用 SQLite/Postgres/Redis 等作为组件自身存储）；
2. **零消息队列**；
3. **零专用 API / Worker / Runner 服务**。

配套要求：复用宿主的身份、界面与执行环境；业务检查（证据真实性、Mock 边界、权限、双签）**不因轻量化而取消**。

**两种运行形态**（架构 §2）：

- **本地模式**：CLI / Python API / stdio MCP，记录本机真实操作者；
- **团队模式**：挂进现有 Python ASGI 宿主，支持共享项目、10 人会话与双人会签。**团队模式才是完整团队需求的验收形态**（当前未实现，见 §12）。

**三条"不许糊弄"的规则**（贯穿全部业务逻辑，接手新功能时必须遵守）：

1. 绿灯（能合并 / HTTP 200 / 页面能点）**不等于**通过；
2. 使用模拟数据**必须声明**，且不能算作真实链路通过；
3. 没跑过的**不许**写成"已通过"；AI 的产出只是草稿与候选分析，不能签字、不能判通过、不能自己关闭缺陷。

---

## 2. 快速上手

### 2.1 环境

| 项 | 值 |
| --- | --- |
| Python | `>=3.12,<4`（`pyproject.toml`）；本机开发用的是 3.14.x |
| 依赖 | `httpx>=0.28,<1`、`portalocker>=3.2,<4`、`pydantic>=2.11,<3` |
| 可选 extra | `mcp`（MCP 服务器）、`postgres-check`（只读库校验）、`team`（**当前为空**，M2 后填充）、`dev`（build/mypy/pytest/ruff） |
| 工具链 | `uv`（推荐）、或系统 Python + 用户级安装的 ruff/mypy/pytest |

### 2.2 安装与运行

```bash
# 推荐：uv（CI 就用它）
uv sync --extra dev --locked        # --locked 会校验 uv.lock 与 pyproject 一致
uv run ruff check . && uv run mypy && uv run pytest
uv build                            # sdist + wheel

# 没有 uv 时（本机就是用这条路径）：无需安装即可跑测试，因为 tests/conftest.py 把 src/ 塞进了 sys.path
python -m pytest
python -m ruff check .
python -m mypy
```

> **注意**：`tests/conftest.py` 只有一行——把 `src/` 加入 `sys.path`。因此 **`tests.support` 这类测试辅助模块只能从仓库根目录运行 pytest**（pytest 会把包含 conftest 的目录加入导入路径）；从别处跑会 import 失败。

### 2.3 CLI

```bash
aitest --workspace .aitest init                     # 初始化工作空间（幂等；不会覆盖已有数据）
aitest --workspace .aitest doctor                   # 只读健康检查（JSON）
aitest --workspace .aitest capabilities             # 能力发现
aitest --workspace .aitest project-create demo 演示项目
aitest --workspace .aitest project-get demo
aitest --workspace .aitest doctor --verbose         # 失败时输出完整堆栈
```

- `--workspace` 默认 `.aitest/`（相对当前目录；已加入 `.gitignore`）。
- 所有输出都是 JSON；**失败一律输出统一错误信封**（见 §6），退出码见 §6.2。
- 未安装包时的调用方式（**注意 Windows**：`python` 可能是 Microsoft Store 的假别名，真的解释器用 `py`）：

```bash
# 未安装：把 src 放进导入路径
PYTHONPATH=src py -m ai_test.interfaces.cli --workspace .smoke init
PYTHONPATH=src py -m ai_test.interfaces.cli --workspace .smoke doctor

# 已安装（pip install -e . / uv sync）：
aitest --workspace .smoke doctor
```

实测（本机验证过的输出节选）：

```jsonc
// aitest doctor —— 七项检查全部 HEALTHY，status 由真实检查推导
{ "status": "HEALTHY", "writable": true,
  "checks": [ {"name":"workspace","status":"HEALTHY"}, {"name":"layout","status":"HEALTHY"},
              {"name":"writable","status":"HEALTHY"}, {"name":"pointer","status":"HEALTHY","detail":"generation=gen-000001"},
              {"name":"state","status":"HEALTHY","detail":"revision=1, kinds=1"},
              {"name":"index","status":"HEALTHY","detail":"kinds=1, blocks_checked=1, entries=1"},
              {"name":"generations","status":"HEALTHY","detail":"generations=['gen-000001']"} ] }

// aitest project-get nope —— 标准错误信封 + 退出码 3
{ "error": { "code": "NOT_FOUND", "message": "project 'nope' does not exist",
             "retryable": false, "details": { "project_id": "nope" } } }
```

### 2.4 Python API

```python
from ai_test import AITestAPI, create_component

api = AITestAPI(".aitest-data")          # initialize=True 默认：幂等初始化
project = api.create_project("demo", "演示项目")
report = api.doctor()                     # 真实健康报告，不是常量

component = create_component(".aitest-data", initialize=False)   # 只读装配：不建任何状态
component.records.get("projects", "demo")
component.records.index_page("runs", limit=200)
component.objects.put_bytes(b"evidence")
```

### 2.5 ASGI 挂载（现状）

```python
from ai_test import AitestASGIApp
app.mount("/plugins/ai-test", AitestASGIApp())     # 当前只有 GET /health 与 GET /capabilities
```

**当前没有 `configure_host()`、没有 lifespan、没有 Bridge 握手**——接入方不能按团队模式的上限预期现有能力（`docs/integration.md` 已明确写出这一点）。

### 2.6 MCP（可选）

```bash
uv sync --extra mcp
```
`create_mcp_server(workspace)` 暴露两个**只读**工具：`capabilities`、`doctor`（需要 `mcp` extra，否则明确报错）。

---

## 3. 仓库地图

```
ai-test-component-main/
├── 附件/                          # 两份基线文档（需求 v1.0 / 架构 v2.4）——唯一权威
├── src/ai_test/
│   ├── __init__.py                # 公开 API：AITestAPI / AitestASGIApp / Component / ComponentError / create_component / __version__
│   ├── version.py                 # 版本单一来源（importlib.metadata + 兜底 0.1.0）
│   ├── composition.py             # 组装根：create_component(workspace, *, initialize=False) -> Component
│   ├── domain/                    # 纯领域模型（10 个模块，无外部依赖，架构测试强制）
│   ├── application/
│   │   ├── errors.py              # 错误体系（13 个标准码的子集）+ envelope()
│   │   ├── ports/                 # 端口协议：storage / system / access / execution / verification /
│   │   │                          #   model_provider / source_control / telemetry
│   │   └── use_cases/             # 用例：已实现 3 个（capabilities/maintenance/project_context），
│   │                              #   7 个是抛 FeatureNotImplemented 的桩
│   ├── infrastructure/
│   │   ├── file_store/            # ★ 存储内核（见 §5）
│   │   ├── adapters/              # 外部系统适配器（deepseek / execution 有最小实现；agent /
│   │   │                          #   database_check / github / http 只有边界文档字符串）
│   │   ├── telemetry.py           # InMemoryTelemetry
│   │   └── documents.py           # write_markdown
│   ├── interfaces/                # cli / python_api / asgi_host / mcp_server / panel
│   └── resources/                 # 打包资源：schemas/host-event.schema.json、rules/default.md、
│                                  #   prompts/evidence-review.md、templates/report.md、panel/{index.js,styles.css}
├── tests/
│   ├── unit/                      # 单元（含 CLI 契约、原子写重试）
│   ├── integration/               # 集成（文件存储、分块索引、协调者、段日志、工作单元、doctor、恢复）
│   ├── architecture/              # 分层与依赖方向守护（见 §4）
│   ├── performance/               # ★ M1 出口判据 + 基准脚本 + 夹具（见 §8.3）
│   ├── acceptance/                # 占位（仅 README）：AC01–AC15 用例待 T1 示例应用
│   ├── recovery/                  # 占位（仅 README）：RV01–RV14 恢复/故障专项
│   ├── support.py                 # 测试辅助（OpenCounter：统计 Path.open 次数）
│   └── conftest.py                # 把 src/ 加入 sys.path
├── docs/                          # architecture / formats / integration / operations + adr/
├── examples/                      # embedded-python（README）、web-component（index.html）
├── .github/workflows/ci.yml       # CI 矩阵 + 每周依赖上界守卫
├── review_probe.py                # 代码审查用的行为探针（11 段 A–K，可重跑复核）
├── review_archive_check.py        # 检查 sdist/wheel 内容是否齐全
├── CODE_REVIEW.md                 # 审查发现（9 P1 / 7 P2 / 14 P3 / 14 SC）+ §11 修复跟踪
├── IMPLEMENTATION_PLAN.md         # 实施计划 M0–M8 + T1–T3 + §16 逐片执行记录
├── PROGRESS_REPORT.md             # 累计进度（对外汇报用）
└── DAILY_2026-09-12.md            # 单日进展
```

**忽略但存在**：`.venv/`、`.uv-cache/`、`.bench/`（基准产物 JSON）、`.mypy_cache/`、`.ruff_cache/`、`.review-probe/`、`.uv-tmp/` —— 全部在 `.gitignore` 内。

---

## 4. 架构与分层（必须遵守，有测试守护）

```
interfaces ──► application ──► domain
                    ▲
                    │ 实现端口
              infrastructure
                    │
              composition（唯一组装点）
```

规则（架构 §3:166，由 `tests/architecture/test_dependency_direction.py` 自动强制）：

1. **`domain/` 不得依赖 `application/`、`infrastructure/`、`interfaces/`**（纯模型 + 不变量）；
2. **不得存在内部导入环**（CI 会失败）；
3. **`infrastructure/` 不得导入 `interfaces/`**；
4. 依赖注入通过 `application/ports/` 的 `Protocol`；`infrastructure` 提供实现；
5. **只有 `composition.py` 知道具体实现类**（接口层拿到的都是装配好的 `Component`）。

为什么这么严：需求明确要求"核心只有一套"——本地模式与团队模式必须走同一条业务路径（架构 §2:58）。分层一旦松动，就会出现"CLI 能跑、团队模式不能跑"的分裂。

### 4.1 端口清单（`application/ports/`）

| 文件 | 端口 | 现状 |
| --- | --- | --- |
| `storage.py` | `RecordRepository`（`get`/`put`/`list`/`index_page`）、`EvidenceObjectStore`、`WorkspaceUnitOfWork`（`unit_of_work`）+ DTO `IndexEntry`/`IndexPage` | ✅ 已实现（`FileRecordRepository` / `FileObjectStore`） |
| `system.py` | `Clock`、`WorkspaceLocator`、`WorkspaceInspector`（`inspect()`）+ `WorkspaceCheck` 与状态常量 | `WorkspaceInspector` ✅；`Clock`/`WorkspaceLocator` 未接线 |
| `telemetry.py` | `TelemetryPort`（`increment`/`health`） | ✅ `InMemoryTelemetry` |
| `access.py` | `IdentityPort`、`SecretPort` | ⬜ 未实现（需宿主 IdentityBridge） |
| `execution.py` | `ExecutionRequest`/`ExecutionResult`、`ExecutionPort` | 🟡 `LocalProcessExecutor` 最小实现 |
| `verification.py` | `VerificationResult`、`VerificationPort` | ⬜ 未实现 |
| `model_provider.py` | `ModelRequest`/`ModelResult`、`ModelProvider` | 🟡 `DeepSeekProvider` 最小实现 |
| `source_control.py` | `Revision`、`SourceControlPort` | ⬜ 未实现 |

> **已知缺口**：架构 §3:164 的端口清单里还有 **`IdGenerator`**，当前不存在（审查 SC08 记录在案，属 M1/M3 范围）。

---

## 5. ★ 存储内核详解（最难的部分，先读懂这节）

实现集中在 `src/ai_test/infrastructure/file_store/`，决策依据是 `docs/adr/ADR-001`（索引分块）、`ADR-002`（写入协调者）、`ADR-003`（版本与迁移）。

### 5.1 磁盘布局

```
<workspace>/
├── current.json                        # 指针：{schema_version, generation, writer_epoch}
├── generations/<generation>/           # 当前只有 gen-000001
│   ├── state.json                      # 入口：修订、writer_epoch、额度、每个 kind 的块入口
│   ├── blocks/<kind>/<NNNNNN>.json      # 索引块：≤200 条摘要，封块后不可变
│   ├── records/<kind>/<id>/r########.json   # 不可变记录（文件名自带修订号）
│   └── streams/<kind>/                  # 事件/链路：seg-NNNNNN.jsonl + index.json
├── objects/sha256/<前两位>/<其余62位>     # 内容寻址附件
└── .locks/
    ├── writer.lock                     # OS 级排他租约（portalocker）
    └── writer.json                     # 持有者诊断（instance/pid/host/acquired_at/heartbeat_at/writer_epoch）
```

**为什么这样分**：`generations/` 支持整代迁移（ADR-003：迁移时新建 generation，不原地覆盖）；`blocks/` 与 `records/` 分离使"索引可重建"成为可能（记录是不可变真相，索引是派生数据）。

### 5.2 各文件的 schema（常量都在 `records.py` / `segments.py` 顶部）

```jsonc
// current.json —— POINTER_SCHEMA = "aatp.workspace-pointer/1.0"
{ "schema_version": "aatp.workspace-pointer/1.0", "generation": "gen-000001", "writer_epoch": 3 }

// generations/<gen>/state.json —— STATE_SCHEMA = "aatp.workspace-state/2.0"
{
  "schema_version": "aatp.workspace-state/2.0",
  "revision": 42,                    // 提交计数（每次提交 +1，批量提交加 N）
  "writer_epoch": 3,                 // 与指针一致（ADR-002 §2 要求）
  "quotas": {},                      // 额度（尚未使用）
  "blocks": {                        // 每个 kind 一个"当前块"入口；不含任何记录摘要
    "tasks": { "file": "blocks/tasks/000003.json", "count": 57, "next": "blocks/tasks/000002.json" }
  }
}

// generations/<gen>/blocks/<kind>/<NNNNNN>.json —— BLOCK_SCHEMA = "aatp.index-block/1.0"
{
  "schema_version": "aatp.index-block/1.0",
  "kind": "tasks",
  "created_revision": 380,
  "next": "blocks/tasks/000002.json",       // 前驱块（块链向后）
  "entries": {
    "tasks/t000001": { "revision": 2, "path": "generations/gen-000001/records/tasks/t000001/r00000002.json" }
  }
}

// generations/<gen>/records/<kind>/<id>/r########.json —— 记录正文（不可变）
{ ...业务字段..., "revision": 2 }            // put() 会覆写 revision 字段

// generations/<gen>/streams/<kind>/index.json —— STREAM_INDEX_SCHEMA = "aatp.stream-index/1.0"
{
  "schema_version": "aatp.stream-index/1.0", "kind": "traces",
  "segment_lines": 10000, "segment_bytes": 8388608, "next_id": 100000,
  "segments": [ { "file": "seg-000001.jsonl", "first_id": 0, "last_id": 9999,
                  "lines": 10000, "bytes": 1832456, "sealed": true } ]
}
// 段文件为 JSONL，每行一条并自带 event_id（由写入器分配，流内单调递增）
```

关键常量：

| 常量 | 值 | 位置 |
| --- | --- | --- |
| `STATE_SCHEMA` | `aatp.workspace-state/2.0` | `records.py` |
| `POINTER_SCHEMA` | `aatp.workspace-pointer/1.0` | `records.py` |
| `BLOCK_SCHEMA` | `aatp.index-block/1.0` | `records.py` |
| `STREAM_INDEX_SCHEMA` | `aatp.stream-index/1.0` | `segments.py` |
| `INITIAL_GENERATION` | `gen-000001` | `records.py` |
| `DEFAULT_BLOCK_SIZE` | 200 条/块 | `records.py` |
| `MAX_PAGE_LIMIT` | 200 条/页 | `records.py` |
| `MAX_DOCTOR_BLOCKS` | 50（doctor 校验块的上限） | `records.py` |
| 段封段阈值 | 10,000 行 或 8 MiB | `segments.py` |

### 5.3 写入路径

**单条写入** `FileRecordRepository.put(kind, record_id, payload, *, expected_revision=None, lease_held=False, epoch=None)`：

1. 校验 `kind` / `record_id`（不得为空、不得含 `/` `\`，不得是 `.`/`..`）→ 非法抛 `ValueError`（CLI 映射为 `INVALID_ARGUMENT`/退出码 2）；
2. 拿租约（除非 `lease_held=True`，表示调用方已持有——协调者用）；
3. 读指针（含 `writer_epoch`）；若传了 `epoch` 且与指针不一致 → **`STALE_REVISION` + `details.reason=OLD_WRITER_EPOCH`，什么都不写**；
4. 用**记录目录扫描**得出当前修订（见 §5.4），核对 `expected_revision`；
5. `revision = 当前 + 1`，写记录文件（`deepcopy(payload)` 后覆写 `revision`）；
6. 写索引块（块满则封块并在新块写新条目）；
7. 写 `state.json`（块入口 + `revision+1` + `writer_epoch`）。

**顺序不可调换**：第 6 步"规划块"会先读取现有块，**索引不可读就在落盘前失败**（不留半提交数据）。

**批量写入（工作单元）** `unit_of_work(*, lease_held=False, epoch=None)`：

```python
with repository.unit_of_work() as unit:      # 或 unit_of_work(lease_held=True, epoch=coord.epoch)
    unit.put("runs", "r1", {...})            # 暂存：返回它将获得的修订号，但**不落盘**
    unit.put("runs", "r2", {...})
    unit.flush()                             # 真正写：N 条记录 + 每块一次 + **一次** state.json
# 不调用 flush() 等于什么都没发生（暂存阶段零副作用）
```

- 同一批内对同一 key 两次 `put` → 修订号连续（1、2），只产生一条最新记录；
- `flush()` 前会**再核对一次 epoch**，被接管则抛 `STALE_REVISION` 且不落盘；
- 实测：5 条记录 = 7 次原子替换；逐条 `put` 则为 15 次。
- 协调者的 `serve_batch()` 就是用它把队列一次提交（见 §5.6）。

**原子写**（`atomic.py`，全仓唯一实现，records/segments/locks 都走它）：

```
mkstemp(同目录) → 写入 → flush() → os.fsync() → os.replace() → 失败则删除临时文件并抛出
```

`os.replace` 带**有界重试**：判定瞬时错误的函数是 `is_transient()`，按 **`errno ∈ {EACCES, EPERM, EBUSY}` 或 `winerror ∈ {5, 32}`** 判定；默认 14 次指数退避（上限 0.5 s，约 7 s 总预算），可用环境变量 **`AITEST_REPLACE_ATTEMPTS`** 覆盖；每次重试向 stderr 打一行日志；**超预算抛原错误**。

> ⚠️ **血泪坑（务必保留这段逻辑与它的测试）**：Windows 的 `WinError 5/32` 被 Python 映射成 `errno.EACCES = 13`。第一版实现写的是 `error.errno in {5, 32}` → **永远不命中**，重试形同虚设，瞬时拒绝直接抛给调用方。在真实 Windows 宿主上这会让写入在杀毒软件面前必然失败。回归测试：`tests/unit/test_atomic_write_retry.py`。

### 5.4 读取路径（三种，语义不同，别混用）

| 方法 | 用途 | 读取的文件 | 说明 |
| --- | --- | --- | --- |
| `get(kind, id)` | 取一条记录 | 指针 + state + 记录 | **不遍历索引块**：用 `records/<kind>/<id>/r########.json` 的**文件名约定**取最大修订（一次目录列举），因此索引块损坏也能读、成本与总量无关。但**版本门禁仍生效**（读 state 校验 schema） |
| `index_page(kind, limit≤200, cursor=None)` | 页面/列表查询 | 指针 + state + 命中块（≤4 个） | §13 的"查询读取文件数不随总量增长"就靠它。返回 `IndexPage(items=(IndexEntry...), next_cursor)`，条目只有 `key/kind/record_id/revision/path`，**不含正文** |
| `list(kind)` | 全量迭代 | 所有块 + 所有正文 | O(N)，固有口径；按"最新块优先"去重，同一 key 只出现一次 |

**分页游标**：字符串 `"<块相对路径>#<块内偏移>"`；页满恰在块尾时游标指向**下一块的偏移 0**，链尾则为 `None`。

> ⚠️ **血泪坑**：第一版实现只在"块内还有剩余"时设置游标，导致**页边界正好落在块尾时后续块永远读不到**。回归测试：`tests/integration/test_chunked_index.py::test_page_pagination_walks_the_block_chain`。

**同一 key 的重复条目**：封块后再次更新同一 key，会在新块产生新条目；读取按"最新块优先"去重。**跨页去重由消费方负责**（同一 key 可能在较新的页与较旧的页各出现一次；取首次出现即最新）。将来 §5.1:262 的"可重建摘要"层会统一这件事。

### 5.5 写入协调者（`coordinator.py`，ADR-002）

```python
from ai_test.infrastructure.file_store.coordinator import WriteCoordinator, WriteIntent

coordinator = WriteCoordinator(repository, auto_heartbeat=True)
coordinator.open()                       # 取租约 → epoch+1 写指针 → 写侧车 → 起心跳线程
try:
    coordinator.submit(WriteIntent("tasks", "t1", {"v": 1}))          # 本地模式：准入后立即提交
    coordinator.enqueue(WriteIntent("runs", "r1", {...}, priority=TERMINAL))  # 团队模式：只入队
    coordinator.serve_batch(max_intents=50)                          # 常驻循环：批量提交
finally:
    coordinator.close()                  # 停心跳 → 释放租约 → 清侧车
```

| 语义 | 实现 |
| --- | --- |
| 单写者 | `WriterLease`（portalocker 排他），取不到 → `WorkspaceInUse` + 脱敏持有者诊断（含 `heartbeat_age_seconds`，**不含路径**） |
| 版本轮次 | `open()` 时 `writer_epoch = 当前 + 1` 并写指针；提交前核对；不一致 → `STALE_REVISION(OLD_WRITER_EPOCH)` |
| 有界队列 | 容量 100，其中 10 个保留给**终态**（`priority=TERMINAL`），普通上限 90；满 → `RateLimited`（`retryable=True`，`details.retry_after_ms=250`） |
| 出队顺序 | 终态优先，同级 FIFO |
| 心跳 | 默认每 5 s 刷新；`ensure_serving()` 检查心跳年龄，> 30 s → `WorkspaceNotReady(COORDINATOR_STALE)` 并拒绝新写 |
| 心跳兼所有权核对 | `heartbeat()` 同时比对 `writer_epoch`，被接管即抛 `STALE_REVISION` 并停止服务 |
| 指标 | `metrics()` → `{instance_id, writer_epoch, opened, queue:{normal,terminal}, counts:{commits,rate_limited,stale_rejected}, queue_wait_ms:{samples,p50,p95,max}, commit_ms:{...}}` |

队列元素是 `(受理时刻, WriteIntent)`，因此 **`queue_wait_ms` 是实测值**（受理 → 提交完成），不是估算。

### 5.6 段式日志（`segments.py`，ADR-001 §3）

```python
from ai_test.infrastructure.file_store.segments import SegmentedLog

log = SegmentedLog(generation_dir, "traces", segment_lines=10_000, segment_bytes=8 * 1024 * 1024)
log.append({"node": "n1", "parent": None})        # event_id 由写入器分配
page = log.read(after_id=44, limit=5)             # 只打开"索引 + 命中段"
log.stats()                                       # {kind, segments, sealed_segments, lines, bytes, next_id}
```

达到行数或字节阈值即**封段**（`sealed=True`），后续写入落新段；段索引损坏/版本不符会明确报错（`ValueError` / 索引 schema 检查）。

### 5.7 不变量清单（改存储时必须保持，都有测试）

| # | 不变量 | 出处 | 测试 |
| --- | --- | --- | --- |
| 1 | `state.json` 大小与记录总数无关 | ADR-001 §不变量 1 | `test_index_invariants.py::test_state_json_size_is_independent_of_record_count` |
| 2 | 一次提交只重写 1 个索引块 | ADR-001 §不变量 2 | `...::test_put_rewrites_exactly_one_index_block` |
| 3 | 页面查询读取文件数恒定 | ADR-001 §不变量 3 | `...::test_page_query_reads_a_constant_number_of_files` |
| 4 | 单次提交成本不随总量增长 | ADR-002 补充 | `...::test_put_cost_does_not_grow_with_record_count` |
| 5 | 全量迭代只解析一次 `state.json` | ADR-001 §不变量 3 回归项 | `...::test_full_scan_parses_the_index_once` |
| 6 | 第二写者返回 `WORKSPACE_IN_USE` + 脱敏诊断 | ADR-002 §不变量 1 | `...::test_second_writer_reports_workspace_in_use` |
| 7 | 指针丢失不得清空索引 | 审查 P1-9 | `tests/integration/test_workspace_recovery.py` |
| 8 | 索引不可读时写入必须在落盘前失败 | ADR-001 实现记录 §5 | `test_chunked_index.py::test_get_works_without_the_index_but_writes_refuse` |
| 9 | 放弃工作单元不留任何文件 | ADR-002 §4 | `test_unit_of_work.py::test_discarding_a_unit_writes_nothing` |
| 10 | 索引**重建**能力（删除块后从记录重建、重建期报"恢复中"） | ADR-001 §不变量 5 后半 | ⬜ **未实现**（M1 第④片剩余） |

---

## 6. 错误与契约

### 6.1 错误类型（`application/errors.py`）

| 类 | code | CLI 退出码 | retryable |
| --- | --- | --- | --- |
| `ComponentError`（基类） | `INTERNAL` | 1 | false |
| `InvalidArgument` | `INVALID_ARGUMENT` | 2 | false |
| `NotFound` | `NOT_FOUND` | 3 | false |
| `StaleRevision`（兼容别名 `ConflictError`） | `STALE_REVISION` | 4 | false |
| `Conflict` | `CONFLICT` | 4 | false |
| `RateLimited` | `RATE_LIMITED` | 4 | **true**（带 `retry_after_ms`） |
| `WorkspaceInUse` | `WORKSPACE_IN_USE` | 5 | **true** |
| `WorkspaceNotReady` | `WORKSPACE_NOT_READY` | 5 | false |
| `FeatureNotImplemented` | `CAPABILITY_UNAVAILABLE` | 6 | false |

每个错误都有 `message`、`retryable`、`details`，`envelope()` 生成对外响应体：**不含堆栈、绝对路径与凭据**（架构 §4.1:188）。

### 6.1.1 基线要求 13 个标准码 —— 已实现 9 个

架构 §4.1:188 固定了 13 个错误码。当前 `errors.py` 只定义了 **9 个**（上表全部）；**尚未实现**的 4 个是：

| 缺失码 | 何时需要 |
| --- | --- |
| `UNAUTHENTICATED` | M2 宿主身份 Bridge（未认证） |
| `FORBIDDEN` | M2 权限（身份已知但无权） |
| `DEADLINE_EXCEEDED` | M2/M3 执行超时 |
| `SNAPSHOT_REQUIRED` | M2 事件游标过期需重取快照 |

另外基线要求信封含 `correlation_id` 字段（当前信封只有 `code/message/retryable/details`），`retry_after_ms` 目前放在 `details` 里而不是顶层 —— 这三处差异在 M2 落契约层时要一次性对齐（已记录在 `CODE_REVIEW.md` 的 SC 清单里）。

### 6.2 CLI 退出码

`0` 成功（`doctor` 仍可能是 `DEGRADED`）/ `1` 内部错误 / `2` 参数或领域校验（含 argparse 用法错误）/ `3` 不存在 / `4` 冲突或限流 / `5` 工作空间不可用或被占用 / `6` 能力未实现。

**常见 `details.reason`**（排障时先看它）：

| reason | 含义 |
| --- | --- |
| `NOT_INITIALIZED` | 缺 `current.json`（提示 `run: aitest init`） |
| `POINTER_MISSING_WITH_DATA` | 指针丢失但 generation 有数据 → 拒绝覆盖（P1-9 守护） |
| `POINTER_UNREADABLE` / `POINTER_SCHEMA_UNSUPPORTED` | 指针损坏 / 版本不支持 |
| `STATE_MISSING` / `STATE_UNREADABLE` / `STATE_SCHEMA_UNSUPPORTED` / `STATE_INDEX_MISSING` | 状态文件的问题（1.0 旧结构走这条） |
| `INDEX_BLOCK_MISSING` / `INDEX_BLOCK_UNREADABLE` / `INDEX_BLOCK_SCHEMA_UNSUPPORTED` / `INDEX_BLOCK_ENTRIES_MISSING` | 索引块的问题 |
| `OLD_WRITER_EPOCH` | 写入协调者已失去所有权（迟到提交被拒） |
| `COORDINATOR_STALE` / `COORDINATOR_CLOSED` | 心跳过期 / 协调者未 open |
| `UNIT_CLOSED` | 工作单元已 flush，不能重复提交 |

### 6.3 `doctor` 检查项（`records.inspect()` → `use_cases/maintenance.doctor()`）

| 检查名 | 语义 |
| --- | --- |
| `workspace` | 目录存在 |
| `layout` | `objects/sha256`、`generations`、`.locks` 齐全（缺 → `DEGRADED`） |
| `writable` | **真实写入探测**（临时文件写入 + 删除），不是常量 |
| `pointer` | 指针可读且 schema 受支持，detail 带 `generation=...` |
| `state` | 状态可读、schema 受支持，detail 带 `revision=…, kinds=…` |
| `index` | 块链可读 + **引用完整性**（已提交记录在磁盘上存在）；最多校验 `MAX_DOCTOR_BLOCKS` 个块 |
| `generations` | 多 generation → `DEGRADED` |

总体状态 = 最差项（`NOT_READY` > `DEGRADED` > `HEALTHY`）；`doctor` **绝不修改工作空间**（有测试守护）。

---

## 7. 版本与迁移

三套**独立**版本族（ADR-003）：

| 族 | 常量 | 当前值 | 门禁行为 |
| --- | --- | --- | --- |
| 工作空间指针 | `POINTER_SCHEMA` | `aatp.workspace-pointer/1.0` | 不认识 → `POINTER_SCHEMA_UNSUPPORTED` |
| 工作空间状态 | `STATE_SCHEMA` | `aatp.workspace-state/2.0` | `1.0`（内嵌式索引）→ **拒绝读取并提示迁移** |
| 领域记录 | 记录内字段 `schema_version` | 例如 `aatp.project/1.0` | 记录级门禁**未实现**（属 M1④/M3） |

**两条铁律**（ADR-003，务必遵守）：

1. **版本严**：未知或更高版本 → 拒绝读取，**不按当前结构猜测**；
2. **字段宽**：同一版本内新增的**可选字段**必须容忍并原样保留（否则"加个审计字段就全读不出来"）。

**迁移现状**：`file_store/migrations.py` 提供 `supported_workspace_schema()`（由 `STATE_SCHEMA` 驱动，**不要写死版本号**）、`needs_migration(found)`、`MigrationPlan`。**迁移器本体（`aitest migrate --check/--plan/--apply/--resume`）尚未实现**——这是 M1 第④片的首要任务。

> ⚠️ 曾经的地雷：`supported_workspace_schema()` 写死返回 `"1.0"`，而实现早已升到 2.0。现在由常量驱动，改 schema 时只改 `records.STATE_SCHEMA` 一处。

---

## 8. 测试体系

### 8.1 四层

| 目录 | 关注点 | 数量 |
| --- | --- | --- |
| `tests/unit/` | 纯逻辑与契约（CLI 错误码、原子写重试、doctor 用例、项目模型、报告） | 6 文件 |
| `tests/integration/` | 真实文件系统的端到端（存储、分块索引、工作单元、协调者、段日志、恢复、doctor、ASGI） | 8 文件 |
| `tests/architecture/` | 分层与依赖方向（见 §4） | 3 用例 |
| `tests/performance/` | **M1 出口判据 + 基准 + 夹具**（默认跳过，见 §8.3） | 1 文件 / 6 用例 |
| `tests/acceptance/`、`tests/recovery/` | 占位（仅 README）：AC 用例与 RV 故障专项待做 | — |

`mypy` **只检查 `src/ai_test`**（`packages = ["ai_test"]`），测试不参与类型检查；`ruff` 检查全部（含测试与脚本）。

### 8.2 怎么跑

```bash
python -m pytest                      # 85 passed, 6 skipped
python -m pytest tests/integration -v
python -m pytest -k chunked_index -v
python -m ruff check . && python -m mypy
```

### 8.3 性能判据与基准（**M1 的验收口子**）

```bash
# 出口判据：默认跳过以保持 CI 常绿，显式启用
AITEST_PERF=1 python -m pytest tests/performance/test_index_invariants.py -v      # 期望 6/6 绿

# 基准：生成 .bench/<label>.json + 控制台表格
python tests/performance/benchmark.py --label after-m1-uow
python tests/performance/benchmark.py --tasks 20 --runs 40 --trace-nodes 100000 --label full-scale

# 夹具（也可当库用）
from tests.performance.fixture import DatasetSpec, FULL_SCALE, generate, write_trace_segments, disk_usage
```

基准的度量口径写在 `benchmark.py` 头部注释里；**队列等待**分两段测：稳态（逐条 `submit`）与饱和（人为积压 85 条后统一执行）。

`AITEST_PERF=1` 时若出现 `OSError`/`PermissionError`，先看 stderr 有没有 `[aitest] transient replace denial` —— 那是 Windows 上的瞬时拒绝重试日志（**不是**失败，除非重试预算耗尽）。

### 8.4 CI（`.github/workflows/ci.yml`）

- 矩阵：`ubuntu-latest` / `windows-latest` × Python `3.12` / `3.13`，步骤 `uv sync --extra dev --locked` → `ruff` → `mypy` → `pytest`；
- `uv build` 只在 ubuntu + 3.13 跑（够用）；
- **每周一 03:00** 跑 `latest-dependencies`：`uv sync --extra dev --upgrade` + `pytest`，给依赖上界加防线。

### 8.5 加测试的约定

- 测试文件放在对应层目录，命名 `test_<主题>.py`；
- 断言**失败信息要能自解释**（例：`f"取一页打开了 {n} 个文件（预算 4）"`）；
- 统计"读取文件数"这类可观测行为，用 `tests/support.py::OpenCounter`（monkeypatch `Path.open`，含 `read_text`）；
- 统计写放大用 monkeypatch `os.replace` 计数（见 `test_unit_of_work.py`）；
- **修 bug 必须带回归测试**，并在 ADR/计划的"实现记录"里写清踩坑经过（本项目已形成习惯）。

---

## 9. 开发约定与陷阱

### 9.1 约定

| 项 | 要求 |
| --- | --- |
| 行宽 | 100（`ruff`，超了 CI 就红） |
| 类型 | `mypy --strict`，`src/ai_test` 全覆盖；新代码不得用 `Any` 逃避 |
| lint 规则 | `E, F, I, UP, B, SIM`（`UP` 会要求用 `datetime.UTC` 而不是 `timezone.utc`；`SIM` 会要求合并嵌套 `with`） |
| Python 目标 | `ruff target-version = py313`、`mypy python_version = 3.12`（下限对齐） |
| 注释语言 | 中文为主（项目文档语言），标识符与错误码英文 |
| 决策 | 有取舍的改动先写 ADR（模板见 `docs/adr/README.md`），实现后回填"实现记录"（含实测与被否方案） |
| 诚实性 | **不许把"未做"写成"已完成"**；不许把"偶发"当结论——先拿原始错误文本 |

### 9.2 陷阱清单（都是踩过的）

1. **类里定义 `list` 方法会遮蔽内建 `list`**：`FileRecordRepository.list()` 存在时，类体内的 `list[str]` 标注会被解析成那个方法 → mypy 报 `Function ... is not valid as a type`。解决办法：模块级别名（`_StrList = list[str]`、`_IntList = list[int]`）。
2. **`errno` vs `winerror`**：见 §5.3 的血泪坑。任何"瞬时错误重试"都必须按 `errno` 判断。
3. **Windows 文件句柄**：短时间创建上千文件时 `os.replace` 会被杀毒/索引服务拒绝；本项目已有重试，**不要删**。
4. **锁非重入**：`WriterLease` 不可重入。协调者持有租约期间调用 `put` 必须传 `lease_held=True`，否则自己把自己锁死。
5. **读路径不建状态**：`get`/`list`/`index_page`/`inspect`/`doctor` **绝不**创建 layout 或状态；`create_component(initialize=False)` 是默认。
6. **指针丢失 ≠ 可重建**：缺 `current.json` 但 generation 有数据时必须拒绝（守护测试在 `test_workspace_recovery.py`）。
7. **`get` 也要过版本门禁**：早期实现让 `get` 绕过 state，结果 1.0 工作空间能被逐条读出。
8. **测试从仓库根目录跑**：`tests/conftest.py` 只加 `src/`；`tests.support` 依赖 pytest 把 `tests/` 加入导入路径。
9. **`pyproject.toml` 的 sdist 白名单**：新增顶层文档/目录若要进 sdist，记得加进 `[tool.hatch.build.targets.sdist] include`（审查 P3-3）。
10. **`.aitest/` 是 CLI 默认工作空间**，已被 `.gitignore`；别把可信记录提交进仓库。

---

## 10. 已知问题与技术债

### 10.1 需要**人**拍板的决策（阻塞性质）

**D1：写队列上限是否从 90 下调到约 40？**
§13 的"写队列等待 p95 ≤ 250 ms"在**饱和**场景下达不到：每条意图边际成本 5.9 ms × 深度 90 ≈ 530 ms（实测饱和 587 ms）。当前口径是"**稳态**到达速率（10 用户 / 3 个并行测试）达标（实测纯排队 0.008 ms），饱和由 `RATE_LIMITED` 保护"。
若要求饱和条件下也达标，就要下调普通上限——**这偏离架构 §5.2:276**（100 容量 / 10 保留 / 90 普通），必须由架构侧确认后写入 ADR-002，实现方不得擅自改。

### 10.2 未实现清单（按里程碑）

| 里程碑 | 内容 |
| --- | --- |
| **M1④（进行中）** | 1.0 → 2.0 索引迁移（`aitest migrate`）、孤儿文件受控清理、**索引重建**与重建期"恢复中"状态、M1 关门全量基准（含 100 万链路节点） |
| **M2** | `configure_host()` 与 Host Bridge（身份/执行/凭据/维护/遥测）、`POST /queries/{name}`、`POST /actions/{name}`、`GET /events`、`POST /mcp`、`GET /metrics`、统一错误信封与 13 个标准码、`expected_revision` + `idempotency_key`、事件游标与 `SNAPSHOT_REQUIRED`、ADR-004 宿主机协议 |
| **M3–M6** | 交付受理、规则、测试计划（含"可验证结果"校验）、执行与证据（内容寻址、哈希校验、模拟数据边界）、AI 任务与预算上限、缺陷/报告/双签验收/回归锁定 |
| **M7** | 面板八个视图（当前 `resources/panel/index.js` 只是一个 `HTMLElement` 占位） |
| **M8** | 保留期执行、备份/恢复（RPO ≤1h / RTO ≤4h）、容量预检、验收演练 |
| **贯穿** | `IdGenerator` 端口（§3:164）、`Clock`/`WorkspaceLocator` 接线、记录级版本门禁与未知字段容忍、`WorkspaceUnitOfWork` 在 ASGI 生命周期的装配 |

### 10.3 小项技术债

- `infrastructure/file_store/indexes.py` 的 `Page` 已成**死代码**（被 `application/ports/storage.py` 的 `IndexPage` 取代）——按分层规则 DTO 归应用层，建议删除；
- `examples/embedded-python/README.md` 与 `examples/web-component/index.html` 是最小示例，随 API 演进可能过时；
- `review_probe.py` / `review_archive_check.py` 是审查期工具（探针 A–K + 归档内容核查），**不是产品代码**，但可重跑复核结论；
- `docs/architecture.md`、`docs/formats.md` 需要随每次 schema 变更同步（已在 M1 前三片更新过一轮）。

### 10.4 与验收基线的距离

| 维度 | 基线 | 现状 |
| --- | --- | --- |
| FR01–FR18 | 首期 17 项 | 仅 FR01 的最小记录闭环 |
| AC01–AC15 | 全部首期必测 | 0 项（依赖 T1 工单示例应用） |
| VC01–VC12 | — | 0 项 |
| RV01–RV14 | — | RV01 机制已实现并有测试（单写者 + epoch 拒迟到提交）；其余未开始 |
| §13 四项指标 | 提交 p95 ≤500 ms；队列等待 p95 ≤250 ms；空闲内存 ≤200 MiB；查询文件数不随总量增长 | **三项达标**；队列等待见 D1 |
| 运维 | 每日备份、RPO ≤1h / RTO ≤4h、保留期 90/365/180 天 | 未开始（M8） |

**非代码依赖（必须由人或外部资源提供，排期时先确认）**：两名授权验收人（双签，开发者不能自签）、真实 ASGI 宿主与 10 个真实用户会话、独立故障域的备份目标、GitHub 私有仓库只读授权、工单示例应用（T1）。

---

## 11. 常见任务手册

### 11.1 新增一个 CLI 命令

1. `interfaces/cli.py::build_parser()` 加子命令与参数；
2. `_dispatch()` 加分支，抛 `ComponentError` 子类表达失败（**不要** `print` 后 `sys.exit`）；
3. 命令必须在未实现时抛 `FeatureNotImplemented`（退出码 6），不得静默成功；
4. 在 `tests/unit/test_cli_contract.py` 加契约测试（退出码 + 信封 + 不泄漏路径）；
5. 更新 `docs/operations.md` 的命令表。

### 11.2 新增一个用例（业务功能）

1. `domain/` 加模型（含 `__post_init__` 不变量，参考 `Project`）；
2. `application/use_cases/` 加用例类/函数，**只依赖端口**（不要 import infrastructure）；
3. 若需要新端口 → 在 `application/ports/` 定义 `Protocol`，在 infrastructure 实现，在 `composition.py` 接线；
4. `tests/unit/` 加用例测试；`tests/architecture/` 会自动检查分层；
5. 删除对应桩函数（当前 7 个桩见 §4 表格）。

### 11.3 新增一种记录类型（kind）

无需改存储代码：`repository.put("<kind>", "<id>", payload)` 即可，索引块会按 kind 自动分目录。注意：kind 与 id 都不能为空、不能含 `/` `\`。

### 11.4 修改数据 schema

1. 改常量（例如 `STATE_SCHEMA`）与读写逻辑；
2. **同时**提供迁移路径（ADR-003：新建 generation、不原地覆盖、`--check/--plan/--apply/--resume`）；
3. 更新 `docs/formats.md`（含示例 JSON）与对应 ADR 的"实现记录"；
4. 加"旧版本被拒绝 + 迁移后可读"的测试；
5. 若是**同版本加可选字段**：保持"字段宽"——老记录读得出来且字段原样保留。

### 11.5 加一条性能判据

在 `tests/performance/test_index_invariants.py` 加 `@pytest.mark.skipif(os.environ.get("AITEST_PERF") != "1")` 用例（用模块级 `pytestmark` 已统一处理），并在 `tests/performance/README.md` 的表格里登记"出处 + 红/绿预期"。

### 11.6 改存储写入路径

**先跑这三条**，再改：

```bash
AITEST_PERF=1 python -m pytest tests/performance/test_index_invariants.py -v
python -m pytest tests/integration -v
python tests/performance/benchmark.py --label before-change
# 改完
python tests/performance/benchmark.py --label after-change   # 与 before 对比
```

---

## 12. 后续路线（接手第一周建议）

1. **跑通全部门禁**（见 §13 检查清单）——确认环境能复现 CI；
2. **读完 §5 + 三份 ADR + `CODE_REVIEW.md`**——尤其 §11 的"已修/部分/待做"状态表；
3. **完成 M1 第④片**（顺序建议）：
   a. `tests/fixtures/legacy-v1/` 造一个 1.0 工作空间夹具（可直接用 `git` 保存的目录或脚本生成）；
   b. 实现 `migrate --check/--plan/--apply/--resume`：**新建 generation**、逐条搬运、检查点文件、空间预检（2× + 20 GiB）、**源 generation 字节级不变**（写测试断言哈希）；
   c. 索引重建：删块 → 从 `records/**` 重建块与 `state.json`，重建期 `doctor` 报"恢复中"（不变量 10）；
   d. 孤儿文件受控清理（记录文件存在但无索引引用，且超过保留窗口）；
   e. **M1 关门**：`FULL_SCALE`（1,000 任务 / 1,000 用例 / 10,000 运行 / 100,000 尝试 / 1,000,000 链路节点）跑一轮，把 §13 四项指标写进 ADR 与进度文档；六条判据保持全绿；
4. **回答 D1** 后进入 **M2**：先写 ADR-004（宿主机协议），再实现 `configure_host()` + 路由 + 错误信封；入口在 `interfaces/asgi_host.py` 与 `application/ports/access.py`。

**给排期的提醒**：M1 之后的顺序不能乱——架构 §13:539-541 明写"错误索引结构上不得继续堆业务"，这也是 `IMPLEMENTATION_PLAN.md` 里的排期规则。

---

## 13. 交接检查清单（第一天照着做）

```bash
# 1. 环境与门禁（应全部通过）
python -m pytest -q                              # 85 passed, 6 skipped
python -m ruff check .                           # All checks passed
python -m mypy                                    # Success: no issues found in 67 source files
uv lock --check                                   # exit 0（CI 的 --locked 前提）

# 2. M1 出口判据（应 6/6 绿）
AITEST_PERF=1 python -m pytest tests/performance/test_index_invariants.py -v

# 3. 行为复现（审查期探针，应看到 P1-9/P1-1/P1-5 等已翻转）
python review_probe.py

# 4. 基准与基线对比
python tests/performance/benchmark.py --label takeover
# 与 .bench/before-m1.json（开工前）和 .bench/after-m1-uow.json（当前）对比

# 5. 手工冒烟（本机 python 是 Store 假别名，故用 py；未安装包时需 PYTHONPATH=src）
export PYTHONPATH=src
py -m ai_test.interfaces.cli --workspace .smoke init
py -m ai_test.interfaces.cli --workspace .smoke project-create demo 演示项目
py -m ai_test.interfaces.cli --workspace .smoke project-get demo
py -m ai_test.interfaces.cli --workspace .smoke doctor          # 期望 7 项检查 HEALTHY、退出码 0
py -m ai_test.interfaces.cli --workspace .smoke project-get nope; echo "exit=$?"   # 期望 exit=3 + NOT_FOUND 信封
rm -rf .smoke
```

> 没有 `uv` 时，把第 1 步换成 `python -m ruff` / `python -m mypy` / `python -m pytest`（本机就是这么跑的）；`uv lock --check` 需要 `uv`。
> Windows 上若 `python` 报"Microsoft Store"字样，说明它只是别名——用 `py` 或完整解释器路径。

**必读**：`CODE_REVIEW.md` §11（未修项）、`IMPLEMENTATION_PLAN.md` §16（逐片记录与未做项）、`docs/adr/ADR-001/002/003`。

**需要向人确认的事**：D1（队列上限）、部署环境的 Python 版本策略、是否有可挂载的 ASGI 宿主、T1 工单示例应用由谁开发、双签验收人是谁。

---

## 14. 术语表

| 术语 | 含义 |
| --- | --- |
| **工作空间 / workspace** | 组件的一个数据根目录（`current.json` + `generations/` + `objects/` + `.locks/`） |
| **generation** | 一代不可变数据目录；迁移时新建一代而不是原地改 |
| **记录 / record** | 一条业务数据（项目、任务、运行、证据引用……），文件不可变，修订号在文件名里 |
| **kind** | 记录分类（`projects`/`tasks`/`cases`/`runs`/`attempts`/`evidence`…），决定目录与索引块 |
| **索引块 / block** | ≤200 条摘要的 JSON 文件；写满封块，封块后不可变 |
| **入口 / state.json** | 只存修订、epoch、额度与每个 kind 的**当前块**位置 |
| **指针 / current.json** | 指向当前 generation，并保存 `writer_epoch` |
| **writer_epoch** | 写入轮次号；协调者每次接管 +1；提交前核对，防止"前任"迟到提交 |
| **工作单元 / unit of work** | 一批写入在一次提交里完成（一次 `state.json`），失败/放弃则零副作用 |
| **段 / segment** | 事件与链路的限长 JSONL 文件（10,000 行或 8 MiB 封段） |
| **Mock / 模拟数据** | 被测系统的替身；使用必须在交付与计划中声明，且不算真实链路通过 |
| **双签** | 报告验收需两个不同用户在同一内容修订上签字（`has_two_distinct_signers`） |
| **绿灯** | 能合并 / HTTP 200 / 页面能点——**不等于**通过 |
| **§13 四项指标** | 提交 p95 ≤500 ms、写队列等待 p95 ≤250 ms、空闲内存 ≤200 MiB、查询读取文件数不随总量增长 |

---

## 15. 参考索引

| 内容 | 位置 |
| --- | --- |
| 需求基线（FR/AC） | `附件/AI辅助测试平台需求文档_v1.0.md` |
| 架构基线（VC/RV/§13） | `附件/AI辅助测试平台技术架构文档_v2.4.md` |
| 关键行号速查 | §13 准入基线 539-541；§5.2 索引与写入 274-284；§3 分层与端口 164-166；§4.1 宿主与错误码 188-192；双签 §3.3:76 |
| 索引分块决策 | `docs/adr/ADR-001-record-index-chunking.md`（含实现记录与实测） |
| 写入协调者决策 | `docs/adr/ADR-002-write-coordinator-and-writer-epoch.md`（含 D1 处置与 errno 教训） |
| 版本与迁移决策 | `docs/adr/ADR-003-schema-versioning-and-migration.md` |
| 数据格式 | `docs/formats.md` |
| 运维与故障处置 | `docs/operations.md` |
| 接入契约 | `docs/integration.md` |
| 性能判据口径 | `tests/performance/README.md` |
| 审查发现与状态 | `CODE_REVIEW.md`（§11 是状态表） |
| 计划与逐片记录 | `IMPLEMENTATION_PLAN.md`（§16 是执行记录） |
| 进度 | `PROGRESS_REPORT.md`、`DAILY_2026-09-12.md` |

---

*交接完成时间：2026-09-12。本文档所有命令与数字均在当前工作副本上验证过；若与 `附件/` 基线冲突，以基线为准并开 ADR 记录差异。*
