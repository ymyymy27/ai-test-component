# ADR-001 记录索引分块与有界读取

- 状态：**已接受**（Stage 0 定稿，M1 实现）
- 依据：`附件/AI辅助测试平台技术架构文档_v2.4.md` §5.2:284、§13:537；代码审查 `CODE_REVIEW.md` SC02 / P2-2（实测 5 条记录触发 6 次 state 解析）

## 背景

骨架当前的 `generations/<gen>/state.json` 把**每条记录**的 `{revision, path}` 都内嵌在一张表里，并且每次 `put()` 都重写整个文件；`list()` 还会逐条重新解析 state。

而基线明确禁止这种做法：

> "记录索引与幂等映射按项目及批次分块；**state.json 只保存当前修订、分块入口及全局额度，不内嵌所有历史记录或链路节点**。每次提交仅生成受影响块及新的入口，避免单次测试追加一个节点就重写全部历史。"（架构 §5.2:284）
>
> "**一次业务提交只重写受影响的索引块，不随工作空间总记录数线性增长**。"（架构 §13:537）

约束：不能用数据库（架构 §1:13），因此分块必须落在文件上；同时在线查询"不得枚举 objects 目录或全部运行"（§13:537）。

## 决策

### 1. `state.json` 降级为"指针 + 入口 + 额度"

```json
{
  "schema_version": "aatp.workspace-state/2.0",
  "revision": 42,
  "writer_epoch": 3,
  "quotas": {"evidence_bytes": 0, "ai_cny_today": 0, "ai_cny_month": 0, "reserved": {}},
  "blocks": {
    "records/projects":     {"file": "blocks/records-projects/000001.json", "count": 200, "next": null},
    "records/test-cases":   {"file": "blocks/records-test-cases/000003.json", "count": 57,  "next": "blocks/records-test-cases/000002.json"},
    "runs":                 {"file": "blocks/runs/000012.json",             "count": 88,  "next": null},
    "idempotency":          {"file": "blocks/idempotency/000001.json",      "count": 34,  "next": null}
  }
}
```

- 每个入口只保存**当前块的路径与条数**，历史块通过 `next` 链回退（只读历史时按需向后遍历）。
- `state.json` 的大小与记录总数**无关**，只与分块数量同阶。

### 2. 块文件（索引块）

```json
{
  "schema_version": "aatp.index-block/1.0",
  "kind": "records/projects",
  "created_revision": 380,
  "entries": {
    "projects/demo": {"revision": 3, "path": "records/projects/demo/r00000003.json", "digest": "sha256:..."}
  }
}
```

- **单块上限 200 条**（与 §13 的"摘要页最多 200 条"一致）；写满即封块并生成新块，`state.json` 只换入口。
- 提交一次记录 = 写 1 个不可变记录文件 + 重写 1 个块（≤200 条）+ 重写 `state.json`（入口级），与总量无关。

### 3. 追加型数据分段（事件 / 链路节点）

- `events` 与 `traces` 使用限长 JSONL 段：**达到 8 MiB 或 10,000 条即封段**，新段新建文件。
- 段索引保存 `{segment_id, first_event_id, last_event_id, bytes}`，查询按 `event_id` 直接定位段 + 段内偏移，不扫描全部段。
- 追加只写当前段；封段是唯一会创建新文件的操作。

### 4. 查询路径

| 操作 | 允许读取的文件 |
| --- | --- |
| 列表（某 kind 一页 ≤200） | `current.json` → `state.json` → 命中块（+ 需要的记录文件） |
| 详情 | `current.json` → `state.json` → 命中块 → 记录文件 |
| 链路查询 | `current.json` → `state.json` → 段索引 → 命中段 |
| 禁止 | 枚举 `objects/`、遍历 `generations/*/records/**`、加载全部块 |

## 不变量（M1 必须用测试锁住）

1. 一次 `put()` 重写的**块数 = 1**，`state.json` 大小不随记录总数增长（构造 1 万条记录后校验 `state.json` 字节数上界）。
2. 单块条数 ≤ 200；封块后旧块不再被写。
3. 页面读取的文件数 ≤ 常数（与工作空间总记录数无关）。
4. 任意在线查询都不出现对 `objects/` 的目录枚举、不出现对 `runs/` 的全量遍历。
5. 索引可重建：删除块文件后能从记录文件重建（摘要可重建，架构 §13:559），重建期间查询返回"恢复中"而不是过期结论。

## 后果

- 正面：写入与读取成本由 O(总量) 降为 O(页)；`state.json` 冲突面变小；generation 迁移只需搬块与入口。
- 代价：需要块遍历逻辑（读历史修订）、需要 `aatp.workspace-state/2.0` 迁移（见 ADR-003，v1.0 内嵌表 → 拆块必须提供 fixture 与迁移器）。
- 风险：块大小 200 是按"摘要页 ≤200 条"选的，若基准显示写入放大仍偏高，可调块大小或改为按项目分块（每项目一套块），这属于参数调整，不改结构。

## 被否方案

| 方案 | 否决理由 |
| --- | --- |
| 单文件全量索引（现状） | 架构 §5.2:284 明确禁止；实测写放大 O(N)，性能准入不可能过 |
| SQLite | 违反"零数据库"硬约束（架构 §1:13） |
| 每条记录一个索引文件 | 目录项数量爆炸，读取文件数随总量增长，违反 §13:537 |
| 内存索引 + 定期快照 | 崩溃后重建代价不可控，且多进程一致性无法保证 |

## 实现记录（M1 第②片，已完成）

实现：`src/ai_test/infrastructure/file_store/records.py`；行为测试：`tests/integration/test_chunked_index.py`；
性能判据：`tests/performance/test_index_invariants.py`（`AITEST_PERF=1` 启用）。

落地时对本文档做了如下细化（属实现层决定，不改变上面的不变量）：

1. **索引块位置**：`generations/<generation>/blocks/<kind>/<NNNNNN>.json` —— 放在 generation 内，随迁移整代搬走，不放工作空间根。
2. **块自带 `next`**：块文件记录前驱块，使分页仅凭块链即可跨块遍历，不必额外读 state。
3. **块内记 `created_revision`**：便于排障与后续迁移对齐。
4. **单条读取不走索引**：`get` 用 `records/<kind>/<id>/r########.json` 的文件名约定定位最新修订（修订号在文件名里）。
   好处：索引块损坏仍能读单条（自愈）、成本与总量无关；但**版本门禁仍生效**（读取前校验 state 的 schema）。
5. **写入顺序**：先"规划块"（读取当前块；索引不可读时**在落盘前**失败）→ 写不可变记录 → 写索引块 → 写 state 入口。
   因此索引损坏时不会留下半提交数据（回归测试 `test_get_works_without_the_index_but_writes_refuse`）。
6. **同一 key 的更新**：块未满就地更新；块已满则封块并在新块写新条目；读取按"最新块优先"去重，消费方取首次出现即最新。
7. **游标格式** `<block 相对路径>#<块内偏移>`；**页满恰在块尾时游标必须指向下一块起点** —— 这是实现过程中被测试抓出的缺陷
   （原实现只在"块内还有剩"时设游标，页边界落在块尾时后续记录永久读不到），已修复并加了回归测试。
8. **`state.json` 升为 `aatp.workspace-state/2.0`**：1.0（内嵌式索引）一律拒绝并提示迁移；迁移器属第④片（见 ADR-003）。

实测（同规模 2001 条记录；口径见 `tests/performance/benchmark.py`）：

| 指标 | 改动前 | 改动后 |
| --- | --- | --- |
| `state.json` | 272,623 字节（超预算 66 倍） | **695 字节** |
| `put` p50 / p95 | 50.1 / 58.4 ms | **16.1 / 22.1 ms** |
| 页面查询读取文件数 | 402（一页 400 条） | **3**（一页 200 条） |
| `get` p95 | 8.79 ms | **1.54 ms** |
| tracemalloc 峰值 | 1.674 MB | **0.763 MB** |
| 生成 2001 条记录 | 54.4 s | **34.6 s** |

`AITEST_PERF=1` 的六条判据中，五条转绿（`state.json` 大小、页面查询读取文件数、一次提交只重写一个块、提交成本恒定、
全量迭代只解析一次 state）；第六条（第二写者返回 `WORKSPACE_IN_USE`）属 ADR-002，待第③片。

**本片未做（已挪出范围）**：事件/链路节点的**段式写入器与段索引**（`traces/seg-NNNNNN.jsonl`）。夹具目前按本文档
§3 的段格式直接写文件；实现层的段写入器与查询索引并入第③片（它与写入协调者同属"追加型数据"路径）。

**不变量 5（索引可重建）的状态**：本片只保证了"索引损坏不阻塞单条读取、写入在落盘前失败"；**索引重建/恢复流程**
（删除块文件后从记录文件重建、重建期间返回"恢复中"）仍在第④片，未实现。
