# ADR-003 结构版本门禁与迁移策略

- 状态：**已接受**；Stage 0 已落地工作空间级门禁（指针/状态 schema + 明确错误），记录级门禁与迁移器在 M1
- 依据：架构 §5.3:290-296、§5.1:268、§11.3；代码审查 SC05（记录级未校验版本）、P1-6（未知字段直接 `TypeError`、未知 schema 被静默接受）、SC11（记录最小字段）、P2-3（迁移/恢复未接线）

## 背景

基线要求版本门禁必须是**显式**的：

> 工作空间清单、记录、事件和外部交换格式分别带 schema_version。组件启动先读取最小清单并检查兼容范围：当前版本正常挂载；已知旧版本进入只读待迁移状态；**未知或更高版本拒绝挂载，不能按当前结构猜测读取**。（§5.3:292）
>
> 业务模块只处理当前内存模型，旧结构解析集中在 migrations.py，不把版本分支散落在流程、报告和缺陷逻辑中。（§5.3:292）

骨架现状：工作空间级**有**校验（`_load_state` 拒绝未知 state schema），但记录级**完全没有**——实测 `schema_version="aatp.project/9.9"` 被静默读入并当作正常对象返回；同时记录多出未知字段会直接 `TypeError`。也就是说"该拒的猜着读、该忍的崩掉"，两个方向都错。

## 决策

### 1. 三套版本族，各自独立演进

| 版本族 | 载体 | 当前值 | 拒绝策略 |
| --- | --- | --- | --- |
| 工作空间清单 | `current.json`、`generations/<gen>/state.json` | `aatp.workspace-pointer/1.0`、`aatp.workspace-state/1.0` | 未知/更高 → 拒绝挂载（`WORKSPACE_NOT_READY`） |
| 业务记录 | `records/<kind>/<id>/r*.json` | `aatp.project/1.0`，后续逐对象加入 | 已知旧版本 → 只读待迁移；未知/更高 → 拒绝；**新增可选字段 → 容忍** |
| 事件与外部交换 | 事件段、外部结果导入 | `aatp.external-result/1.0`（待实现） | 未知/更高 → 拒绝导入并报字段问题 |

### 2. 记录读取的两条规则（同时成立）

1. **版本严**：`schema_version` 必须在支持集合内；未知或更高版本抛 `WORKSPACE_NOT_READY`（`details.reason=STATE_SCHEMA_UNSUPPORTED` / `POINTER_SCHEMA_UNSUPPORTED`），不猜。
2. **字段宽**：同一版本内，未识别的字段**忽略并保留**（写入时不得丢字段），不得因为多了一个可选字段就崩。

> 为什么两条都要：`docs/formats.md:6` 已经预告"操作者和时间审计字段将在身份桥接落地时加入"。若只有"版本严"而无"字段宽"，加字段那天旧记录会全部读不出来；若只有"字段宽"而无"版本严"，则正式验收会读到无法解释的历史结构。

### 3. 迁移命令与流程

```
aitest migrate --check            # 只读：当前版本、支持范围、是否需迁移
aitest migrate --plan             # 列出源版本、目标版本、预计文件数、所需空间、不可自动转换字段、需人工决定项
aitest migrate --apply <新 generation>   # 分批写入新 generation，保存检查点
aitest migrate --resume           # 从检查点续传
```

- **不原地覆盖源记录**；迁移前保护原 generation，成功后由维护人员**原子切换 `current.json`**；失败继续使用原只读 generation 并从检查点重试。
- 空间预检：可用空间 ≥ 当前记录与索引大小的 **2 倍 + 20 GiB**，不足直接阻塞（附件对象不重复计算）。
- 迁移后核对：记录数量、引用完整性、附件哈希、权限、签名绑定、统计、固定验收样例；全部通过才允许切换。
- 相邻版本迁移器必须**确定性、幂等、可串联**；每个受支持旧版本保留 fixture 与相邻迁移测试（RV04）。
- 停止支持的迁移器作为独立归档工具保存，不留在主包。

### 4. 版本分支的归属

- 旧结构解析**只允许**出现在 `infrastructure/file_store/migrations.py`。
- `domain` 与 `application` 只处理当前内存模型；出现 `if schema_version == ...` 之类的分支即视为违规（架构测试后续可加静态检查）。
- 组件启动读取**最小清单**即可判断兼容范围，不需要加载全部记录。

## 已落地的部分（Stage 0）

- 指针与工作空间状态的校验从"抛裸 `ValueError`"改为结构化错误：`NOT_INITIALIZED` / `POINTER_UNREADABLE` / `POINTER_SCHEMA_UNSUPPORTED` / `STATE_MISSING` / `STATE_UNREADABLE` / `STATE_SCHEMA_UNSUPPORTED` / `STATE_INDEX_MISSING`，并带 `generation`、`expected`、`found` 等 `details`。
- `aitest doctor` 会把上述任一状态如实报为 `NOT_READY`（不再是常量 `ok`）。
- 指针新增 `writer_epoch` 字段（见 ADR-002），避免 M1 再改一次指针格式。
- 指针或状态缺失时**绝不重构**已有数据（ADR-002 的不变量 6）。

## 不变量（M1 必须用测试锁住）

1. 未知/更高版本的记录被读取时必须报错，且错误里包含 `found` 与支持集合。
2. 同版本内多出未知字段的记录仍可读、可写回，且未知字段不丢失。
3. `migrate --plan` 对同一输入产生相同输出（确定性）；`--apply` 中断后 `--resume` 结果与不中断一致（幂等）。
4. 迁移失败后源 generation 未被修改（字节级校验）。
5. 迁移后引用完整性、附件哈希、签名绑定逐项核对通过，否则不允许切换 `current.json`。
6. 空间不足时迁移不启动，并给出所需空间与实际可用空间。

## 后果

- 正面：正式验收读到的每个对象都有明确的版本来源；字段演进不再造成"加字段即崩"。
- 代价：需要为每个受支持旧版本维护 fixture；记录级 `from_dict` 需要"白名单 + 保留未识别字段"的实现（比现在的 `**record` 复杂）。
- 风险：迁移是数据操作，必须先在 T2 生成的固定数据集上演练（RV04/RV13），不能只在单元测试的小样本上验证。
