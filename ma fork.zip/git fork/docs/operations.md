# 运行维护

## 命令

```bash
aitest --workspace <path> init          # 初始化工作空间（幂等；已有数据时拒绝重建索引）
aitest --workspace <path> doctor        # 只读健康检查（不做任何修复）
aitest --workspace <path> capabilities  # 已实现 / 计划中的能力
aitest --workspace <path> project-create <id> <name>
aitest --workspace <path> project-get <id>
```

全局开关：`--verbose` 在失败时输出完整堆栈（默认只输出标准错误信封）。

## 工作空间结构

```
<workspace>/
├── current.json                        # 指针：schema_version / generation / writer_epoch
├── generations/<generation>/
│   ├── state.json                      # 只存：修订、writer_epoch、额度、每个 kind 的块入口
│   ├── blocks/<kind>/<NNNNNN>.json      # 索引块：≤200 条摘要，封块后不可变
│   ├── records/<kind>/<id>/r########.json
│   └── streams/<kind>/                  # 事件/链路：段文件 seg-NNNNNN.jsonl + index.json
├── objects/sha256/<xx>/<digest>
└── .locks/
    ├── writer.lock                     # OS 级写入租约（唯一权威）
    └── writer.json                     # 持有者诊断信息（instance/pid/host/取得时间/心跳/epoch）
```

`current.json` 保存当前 generation 与 `writer_epoch`（后者为 ADR-002 预留，语义在 M1 第③片生效）。
可信状态只在写路径提交，读路径不创建任何状态；索引方案见 [ADR-001](adr/ADR-001-record-index-chunking.md)。

**版本提示**：记录索引在 M1 第②片改为分块结构，`state.json` 的 `schema_version` 由 `aatp.workspace-state/1.0`
升为 `/2.0`。旧（1.0）工作空间会被**明确拒绝读取**（`WORKSPACE_NOT_READY`，`details.reason=STATE_SCHEMA_UNSUPPORTED`，
并提示迁移），不会按新结构猜测；迁移工具 `aitest migrate` 属 M1 第④片，届时按
[ADR-003](adr/ADR-003-schema-versioning-and-migration.md) 的流程处理（不原地覆盖、先预演）。

## doctor 输出

```json
{
  "workspace": "<绝对路径>",
  "status": "HEALTHY | DEGRADED | NOT_READY",
  "writable": true,
  "checks": [
    {"name": "workspace", "status": "HEALTHY", "detail": "workspace directory exists"},
    {"name": "layout", "status": "HEALTHY", "detail": "layout complete"},
    {"name": "writable", "status": "HEALTHY", "detail": "write probe succeeded"},
    {"name": "pointer", "status": "HEALTHY", "detail": "generation=gen-000001"},
    {"name": "state", "status": "HEALTHY", "detail": "revision=1, kinds=1"},
    {"name": "index", "status": "HEALTHY", "detail": "kinds=1, blocks_checked=1, entries=1"},
    {"name": "generations", "status": "HEALTHY", "detail": "generations=['gen-000001']"}
  ],
  "metrics": {"status": "ok", "counters": {}}
}
```

判定规则：任一检查为 `NOT_READY` → 总体 `NOT_READY`（退出码 5）；否则任一为 `DEGRADED` → `DEGRADED`（退出码 0）；
`writable` 只由真实写入探测（临时文件写入 + 删除）决定，不是常量。

检查项含义：

| 检查 | NOT_READY 的典型原因 |
| --- | --- |
| `workspace` | 目录不存在 |
| `layout` (`DEGRADED`) | 缺少 `objects/sha256`、`generations` 或 `.locks` |
| `writable` | 目录不可写（只读挂载、权限不足、磁盘满） |
| `pointer` | `NOT_INITIALIZED`、`POINTER_UNREADABLE`、`POINTER_SCHEMA_UNSUPPORTED`、`POINTER_MISSING_WITH_DATA` |
| `state` | `STATE_MISSING`、`STATE_UNREADABLE`、`STATE_SCHEMA_UNSUPPORTED`（含 1.0 旧结构）、`STATE_INDEX_MISSING` |
| `index` | 块文件缺失/损坏（`INDEX_BLOCK_MISSING`、`INDEX_BLOCK_UNREADABLE`、`INDEX_BLOCK_SCHEMA_UNSUPPORTED`）、已提交记录文件在磁盘上不存在（引用完整性） |
| `generations` (`DEGRADED`) | 同时存在多个 generation（迁移未完成或残留） |

> `index` 检查每个 kind 最多校验 50 个块（`MAX_DOCTOR_BLOCKS`），达到上限时在 detail 中标注"更早的块未校验"；这样诊断本身不会退化成全量扫描。

## 退出码

| 码 | 含义 | 对应错误码 |
| --- | --- | --- |
| 0 | 成功（`doctor` 仍可能是 `DEGRADED`） | — |
| 1 | 未预期的内部错误 | `INTERNAL` |
| 2 | 参数/领域校验失败（含 argparse 用法错误） | `INVALID_ARGUMENT` |
| 3 | 对象不存在 | `NOT_FOUND` |
| 4 | 并发冲突 / 陈旧修订 | `CONFLICT` / `STALE_REVISION` |
| 5 | 工作空间不可用或被占用 | `WORKSPACE_NOT_READY` / `WORKSPACE_IN_USE` |
| 6 | 能力尚未实现 | `CAPABILITY_UNAVAILABLE` |

失败一律输出同一信封，且**不含堆栈、绝对路径与凭据**（`--verbose` 时才输出堆栈）：

```json
{"error": {"code": "STALE_REVISION", "message": "expected revision 0, found 1",
           "retryable": false, "details": {"actual_revision": 1}}}
```

## 数据安全规则（必须遵守）

- **指针丢失不等于可以重建**：`current.json` 缺失而 generation 中已有数据时，`init`、写入与 `create_component(initialize=True)` 都会拒绝执行（`WORKSPACE_NOT_READY`，`details.reason=POINTER_MISSING_WITH_DATA`），不会用空状态覆盖索引。恢复方式见 §恢复。
- **读不建状态**：`aitest project-get`、`doctor` 与库的读取路径都不会创建 layout 或 state；对未初始化工作空间读取会返回 `WORKSPACE_NOT_READY` 并提示 `run: aitest init`。
- **单写者**：一个工作空间同时只有一个写入者（portalocker 排他租约 + `writer_epoch`）。团队模式必须单 worker；不要在网络盘/NFS/同步盘上共享工作空间（架构 §4.1:192）。
- **取不到租约**：第二写者会在超时后返回 `WORKSPACE_IN_USE`（退出码 5），并附带**脱敏**持有者诊断（进程号、主机、取得时间、心跳年龄、epoch；不含路径与凭据）。
- **队列饱和**：写入协调者的有界队列（普通意图上限 90，另 10 个保留给运行终态）满时返回 `RATE_LIMITED` 并给出 `retry_after_ms`，**不静默丢弃也不无限排队**。
- **心跳降级**：协调者心跳超过 30 秒未更新时标记 `NOT_READY` 并停止接收新写（`details.reason=COORDINATOR_STALE`）；`aitest doctor` 会把它反映为工作空间不可用。
- **原子写的重试预算**：Windows 上杀毒/索引服务可能短暂持有新建文件句柄，导致 `os.replace` 返回 `WinError 5/32`（Python 映射为 `errno.EACCES`）。写入路径按 errno 判定瞬时错误并做 14 次指数退避（约 7 秒预算，可用环境变量 `AITEST_REPLACE_ATTEMPTS` 调整），每次重试向 stderr 打一行说明；超预算则**明确报错**，不会出现"看似提交成功但未落盘"。

## 恢复（指针丢失或状态损坏）

当前版本的可用手段是"就地诊断 + 人工决定"，不允许静默自愈：

1. 先跑 `aitest doctor`，确认是哪一项 `NOT_READY`（`pointer` 还是 `state`）；
2. 若只是 `current.json` 丢失、`generations/<gen>/state.json` 完好：把指针内容按 `<gen>` 手工写回 `{"schema_version": "aatp.workspace-pointer/1.0", "generation": "<gen>", "writer_epoch": 0}`（或从备份恢复该文件）；
3. 若 `state.json` 损坏：从备份恢复，或在 M1 提供 `aitest migrate`/恢复工具后按其流程处理；
4. 恢复后重新跑 `doctor`，确认 `status=HEALTHY` 再继续使用。

记录文件本身是不可变的 `r########.json`，指针/索引损坏不会删除它们；在 M1 第④片提供索引重建前，请勿删除 generations 目录中的任何文件。

**索引块损坏/丢失的处理**：单条读取（`project-get` 等）不经过索引块，仍可正常工作（走 `records/<kind>/<id>/r########.json` 的文件名约定）；但写入与分页查询会在**落盘之前**失败（`INDEX_BLOCK_MISSING`，不留半提交数据），这是刻意的：先诊断为 `NOT_READY`，等 M1 第④片的索引重建/恢复流程处理，而不是静默重建。

**1.0 旧工作空间**：`state.json` 为 `aatp.workspace-state/1.0` 时，所有读写都会返回 `WORKSPACE_NOT_READY`（`reason=STATE_SCHEMA_UNSUPPORTED`，并提示迁移）。迁移器（`aitest migrate --check/--plan/--apply/--resume`）属 M1 第④片；迁移前请先用备份保留原目录。

## 尚未实现（不要按已实现对待）

`aitest migrate`（检查/预演/应用/续传）、`aitest backup`/`restore`、摘要重建、锁租约与 `writer_epoch` 语义、有界写入队列、`/metrics`、容量与保留期执行 —— 这些在 `IMPLEMENTATION_PLAN.md` 的 M1 第③④片与 M8 中，见 `docs/adr/` 的对应决策。
