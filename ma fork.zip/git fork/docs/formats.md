# 数据格式

已实现的项目记录包含：

- `schema_version`
- 稳定业务编号
- `revision`

当前骨架实现 `aatp.project/1.0`。操作者和时间审计字段将在身份桥接落地时加入；完整 Schema 将按领域对象逐项加入 `src/ai_test/resources/schemas`。

读取规则（见 [ADR-003](adr/ADR-003-schema-versioning-and-migration.md)）：**版本严、字段宽** —— 未知或更高版本的记录必须拒绝读取（不按当前结构猜测），同一版本内新增的可选字段必须被容忍并原样保留，避免"加字段即崩"。工作空间级门禁（`current.json` / `state.json` 的 `schema_version`）已实现；记录级门禁在 M1 落地。

工作空间指针 `current.json` 保存 `schema_version`、`generation` 与 `writer_epoch`（后者为 ADR-002 预留字段；递增与迟到提交拒绝的语义在 M1 第③片生效）。

## 工作空间状态与索引（M1 第②片，`aatp.workspace-state/2.0`）

`state.json` **只保存**：当前修订、`writer_epoch`、额度，以及每个 kind 的块入口——不再内嵌任何记录摘要（这是 ADR-001 的核心约束，也是把 `state.json` 从"随记录数增长"变成"与记录数无关"的原因）。

```json
{
  "schema_version": "aatp.workspace-state/2.0",
  "revision": 42,
  "writer_epoch": 0,
  "quotas": {},
  "blocks": {
    "tasks": {"file": "blocks/tasks/000003.json", "count": 57, "next": "blocks/tasks/000002.json"}
  }
}
```

索引块（`aatp.index-block/1.0`，位于 `generations/<generation>/blocks/<kind>/<NNNNNN>.json`）：

```json
{
  "schema_version": "aatp.index-block/1.0",
  "kind": "tasks",
  "created_revision": 380,
  "next": "blocks/tasks/000002.json",
  "entries": {
    "tasks/t000001": {"revision": 2, "path": "generations/gen-000001/records/tasks/t000001/r00000002.json"}
  }
}
```

规则：

- 单块 ≤200 条（`DEFAULT_BLOCK_SIZE`）；写满即封块，`state.json` 只替换块入口；**旧块保持不可变**；
- 页面查询用 `index_page(kind, limit≤200, cursor)`：只读"指针 + state + 命中块"，读取文件数不随总量增长；
- 全量迭调用 `list(kind)`：会遍历块链与记录正文（"全量扫描"口径）；
- 单条读取（`get`）走 `records/<kind>/<id>/r########.json` 的文件名约定定位最新修订，不遍历索引块；
- 同一 key 在封块后再次更新会在新块中产生新条目，读取按"最新块优先"去重，消费方取首次出现即最新。

**版本门禁**：`state.json` 为 `aatp.workspace-state/1.0`（旧的内嵌式索引）时，读写一律拒绝并提示迁移（`STATE_SCHEMA_UNSUPPORTED`），迁移器属 M1 第④片。

## 事件与链路：限长段（M1 第③片，`aatp.stream-index/1.0`）

事件与链路节点按段存储，段索引位于 `<generation>/streams/<kind>/index.json`：

```json
{
  "schema_version": "aatp.stream-index/1.0",
  "kind": "traces",
  "segment_lines": 10000,
  "segment_bytes": 8388608,
  "next_id": 100000,
  "segments": [
    {"file": "seg-000001.jsonl", "first_id": 0, "last_id": 9999, "lines": 10000,
     "bytes": 1832456, "sealed": true}
  ]
}
```

段文件为 JSONL，每行一条记录，**`event_id` 由写入器分配**（单个流内单调递增，从 0 开始）：

```json
{"event_id": 0, "node": "n000000000", "parent": null, "status": "OK"}
```

规则：

- 达到 `segment_lines`（默认 10,000）或 `segment_bytes`（默认 8 MiB）即**封段**，后续写入落新段；封段后旧段不再被写；
- 读取用 `read(after_id, limit)`：先读段索引定位命中段，再按 `event_id` 顺序读取；读取文件数 = 1（索引）+ 命中段数，**不随总量增长**；
- `event_id` 在流内连续且不重复；跨流（不同 kind）各自独立编号。
