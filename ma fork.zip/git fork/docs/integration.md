# 宿主接入

## Python API

```python
from ai_test import AITestAPI, create_component

api = AITestAPI(".aitest-data")          # 默认会初始化工作空间（幂等，且不会覆盖已有数据）
project = api.create_project("demo", "演示项目")
report = api.doctor()                    # 真实健康报告，见 docs/operations.md
```

`create_component(workspace, initialize=False)` 是底层装配入口：**默认不创建任何状态**，只读调用方与 `doctor` 用它检查一个新建或损坏的工作空间。需要显式初始化时传 `initialize=True`。
写入路径会按需初始化（首次 `put` 创建 generation 1），读取路径永不创建状态。

`Component` 暴露 `projects`（项目上下文用例）、`records`（记录仓库，含 `inspect()` 健康检查）、`objects`（附件对象存储）、`telemetry`。

## ASGI

`AitestASGIApp` 是 ASGI 3.0 子应用。骨架提供：

- `GET /capabilities`
- `GET /health`

尚未实现（M2 落地，见 `IMPLEMENTATION_PLAN.md` 与 `docs/adr/`）：`POST /queries/{name}`、`POST /actions/{name}`、`GET /events`、`POST /mcp`、`GET /metrics`，默认挂载前缀 `/plugins/ai-test`、统一错误信封与 13 个标准错误码、写请求的 `expected_revision` + `idempotency_key`、事件游标与 `SNAPSHOT_REQUIRED`。

团队宿主必须使用单 worker，并在后续实现中通过 `configure_host()` 注入身份、执行、凭据、维护和遥测 Bridge（架构 §4.1:190）。**当前代码中不存在 `configure_host()`**：`AitestASGIApp` 没有 lifespan 分支、没有 `host_capabilities` 握手，也无法拒绝"能力不足的团队模式"——接入方不能按团队模式的上限预期当前能力。

## MCP

安装 `mcp` 可选依赖后调用 `create_mcp_server(workspace)`。当前暴露两个只读工具：

- `capabilities`：本构建的能力发现；
- `doctor`：工作空间健康报告。

## 错误契约

库与 CLI 共用同一套错误类型（`ai_test.application.errors`）：

| 错误 | code | CLI 退出码 |
| --- | --- | --- |
| `InvalidArgument` | `INVALID_ARGUMENT` | 2 |
| `NotFound` | `NOT_FOUND` | 3 |
| `StaleRevision` | `STALE_REVISION` | 4 |
| `Conflict` | `CONFLICT` | 4 |
| `WorkspaceInUse` | `WORKSPACE_IN_USE` | 5 |
| `WorkspaceNotReady` | `WORKSPACE_NOT_READY` | 5 |
| `FeatureNotImplemented` | `CAPABILITY_UNAVAILABLE` | 6 |

每个错误带 `message`、`retryable` 与 `details`；`envelope()` 生成对外响应体，其中**不含堆栈、绝对路径与凭据**（架构 §4.1:188 的要求）。`StaleRevision` 同时保留旧名 `ConflictError`（`ai_test.infrastructure.file_store.records.ConflictError`）以兼容既有调用方。
