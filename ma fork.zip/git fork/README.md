# AI Test Component

一个轻量、可嵌入的 AI 辅助测试组件骨架。项目采用单个 Python 包和文件存储，提供 Python API、CLI、ASGI 子应用、可选 MCP 入口及 Web Component 面板资源。

当前版本是工程骨架：已实现项目记录的最小闭环、工作空间初始化、原子 JSON 写入、能力发现和**真实的工作空间健康检查**。测试执行、完整证据链、DeepSeek 调用、GitHub 同步、迁移和团队会签仍保留明确接口，尚未标记为完成。

## 运行要求

- Python 3.12+（CI 覆盖 3.12 / 3.13，Windows 与 Linux 双平台）
- 本地可写目录作为工作空间
- 团队模式使用一个 ASGI worker 挂载一个工作空间

## 安装

```bash
uv sync --extra dev
```

可选能力：

```bash
uv sync --extra mcp
uv sync --extra postgres-check
```

## 快速开始

```bash
uv run aitest --workspace .aitest-data init
uv run aitest --workspace .aitest-data doctor
uv run aitest --workspace .aitest-data capabilities
uv run aitest --workspace .aitest-data project-create demo "演示项目"
uv run aitest --workspace .aitest-data project-get demo
uv run pytest
```

CLI 失败时统一输出 `{"error": {"code", "message", "retryable", "details"}}` 并带固定退出码，详见 [运行维护](docs/operations.md)。

## 目录边界

- `domain`：业务状态和不变量，不访问文件或网络。
- `application`：用户用例和端口。
- `infrastructure`：文件、外部服务和遥测实现。
- `interfaces`：Python、CLI、MCP 和 ASGI 协议转换。
- `resources`：Schema、规则、提示、导出和面板静态资源。

依赖方向固定为 `interfaces → application → domain`。基础设施实现应用端口，通过 `composition.py` 装配。

## 文档

- 验收基线：[需求文档 v1.0](附件/AI辅助测试平台需求文档_v1.0.md)、[技术架构文档 v2.4](附件/AI辅助测试平台技术架构文档_v2.4.md)
- 实施计划：[IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md)（里程碑、出口判据、风险）
- 决策记录：[docs/adr/](docs/adr/README.md)（记录索引分块 / 写入协调者 / 结构版本与迁移）
- 代码审查：[CODE_REVIEW.md](CODE_REVIEW.md)（含基线冲突清单与修复跟踪）
- [接入说明](docs/integration.md)、[数据格式](docs/formats.md)、[运行维护](docs/operations.md)、[架构决策](docs/architecture.md)

## 状态

版本 `0.1.0` 仅代表骨架可运行，不代表需求文档中的首期业务验收已经完成。已完成与未完成的分界见 [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md) 的 Stage 0 执行记录：存储层的分块索引、写入协调者与迁移器（M1）尚未实现，`docs/adr/` 中的对应决策已定稿。

