# ai-test-component 0.1.0 代码审查报告

- 审查对象：`C:\Users\lenovo\Desktop\work files\ai-test-component-main`（`ai-test-component` v0.1.0，Python 3.13 / hatchling / src-layout）
- 审查基准：`附件/AI辅助测试平台需求文档_v1.0.md`（494 行，FR01–FR18 + AC01–AC15）、`附件/AI辅助测试平台技术架构文档_v2.4.md`（563 行，架构设计基线，含 §12 验证矩阵与 §13 轻量验收基线）+ 仓库自带 docs/
- 审查方式：全仓库逐文件阅读（`src/` 全部 48 个文件、`docs/` 4 篇、`tests/` 全部、`examples/`、`.github/workflows/ci.yml`、`pyproject.toml`、资源文件）+ 关键结论的实测复现（见 §8）+ 与两份基线文档的逐条对照（见 §9）
- 审查者视角：把它当作"要给外部宿主接入/要在此基础上做增量"的骨架来审，关注 **承诺与实现是否一致、数据是否会被写坏、错误是否可诊断、是否与架构基线冲突**
- 严重度定义：**P0** 数据损坏或安全问题（当前无）；**P1** 会误导使用者或造成契约/数据不可用；**P2** 并发、可靠性、安全防御缺口；**P3** 工程质量与一致性；**SC-n** 与架构基线 v2.4 的直接冲突（§9）
- ⚠️ **本次审查做过一次自我更正**：初稿漏读 `附件/` 目录（其中正是需求与架构文档），据此误判"需求文档不在仓库"，并高估了 docs/integration.md 的问题。两处更正见 §10。

## 1. 总体结论

骨架的质量高于"占位仓库"的平均水平：分层方向有 AST 测试强制守卫，落盘用了 `mkstemp + fsync + os.replace` 原子替换，证据对象是内容寻址，记录并发用 `expected_revision` 乐观校验，文档也明确声明"骨架可运行 ≠ 首期验收完成"。这些是正确的骨架决策，值得保留。

主要问题集中在四类：

1. **指针丢失会静默清空记录索引（数据可达性丢失）**：`current.json` 一旦缺失，下一次任意调用（连 `project-get` 也算）都会走 `initialize()` 把 `generations/gen-000001/state.json` **覆盖成空状态**，记录文件虽仍在磁盘上却再也读不到（§8-F 已复现：`records` 从 `['projects/demo']` 变 `[]`，`project-get` 变成 `PROJECT_NOT_FOUND`）。这是本次审查发现的最高危问题，且现有 9 条测试全覆盖不到。
2. **承诺与实现不一致**（次优先）：`doctor` 谎报可写、`docs/integration.md` 承诺的 `configure_host()` 根本不存在、`docs/architecture.md` 声称的"工作单元提交"路径未接线、规则/提示词/schema 资源无人加载。当前**没有任何测试会发现这类漂移**。
3. **反序列化无容错**：`ProjectContext.get()` 用 `**record` 构造领域对象，记录里多出任何未知字段即 `TypeError`（§8-B 已复现）；同时未知 `schema_version` 被静默接受（同一条探针已复现）。而 `docs/formats.md` 明确预告了要加"操作者/时间"审计字段 —— 一旦加，读写立刻互相崩。
4. **存储层的复杂度与自锁风险**：`state.json` 全量重写 + `list()` 每条重读 state（§8-J 实测 5 条记录触发 6 次 state 解析），属 O(N²) 级退化；`initialize()` 在持锁路径上会再次申请同一把非重入锁（§8-H 实测以锁错误收场）。

另有 20+ 个已定义但全仓库零引用的类型/函数（§6），作为"先固定接口"的骨架是有意的，报告里区分了**有意占位**与**文档承诺了但没实现的**两类，后者才是风险。

读完 `附件/` 里的需求与架构基线后，还多出一类更重的问题：**不是"还没做"，而是"已经写成与基线相反的样子"**（共 12 类，见 §9）。其中最关键的是 **SC01**：架构 §13:539-541 规定文件存储必须先通过"最小纵向原型"（写入队列 p95 ≤ 250ms、空闲内存 ≤ 200 MiB、10 会话 3 并行）才算准入，并明确"任一核心指标不达标时，停止在当前文件后端上扩展业务功能"；而仓库的第一块业务模块偏偏建立在一个基线明令禁止的索引结构上（§9 SC02：`state.json` 内嵌全部记录并整体重写）。因此本次审查对排期的建议是：**先把存储/写入模型修到基线，再挑 `FeatureNotImplemented` 里的用例实现**。

## 2. 做得好的部分（不建议改动方向）

| 项 | 证据 |
| --- | --- |
| 依赖方向有测试守卫，domain 零外部依赖 | `tests/architecture/test_dependency_direction.py`（AST 扫描 `domain/*.py`） |
| 落盘原子性正确：同目录临时文件 + `fsync` + `os.replace` | `src/ai_test/infrastructure/file_store/records.py:126-140`、`objects.py:18-31` |
| 内容寻址附件：SHA-256、两位分片、读取时校验摘要格式 | `objects.py:12-14`、`objects.py:34-37` |
| 并发写用修订号乐观校验，冲突显式抛错 | `records.py:80-84`，测试 `tests/integration/test_file_store.py:11-12` |
| 路径穿越双保险：段校验 + 工作空间包含校验 | `records.py:113-116`、`records.py:122-124` |
| "未实现要显式"：`FeatureNotImplemented` + ASGI 501 | `application/errors.py`、`interfaces/asgi_host.py:19-24` |
| CI 完整：ruff + mypy(strict) + pytest + `uv build` | `.github/workflows/ci.yml` |
| 文档诚实标注状态 | `README.md:5`、`docs/architecture.md:24` |

## 3. P1：会误导使用者或造成契约/数据不可用

### P1-1 `doctor` 命令谎报可写（无实际检查）

- 位置：`src/ai_test/interfaces/cli.py:40-41`
- 现象：`doctor` 直接输出 `{"status": "ok", "workspace": ..., "writable": True}`，**常量 `True`，没有任何写入探测**；同时 `application/use_cases/maintenance.py:6` 的 `doctor(telemetry)` 与 `infrastructure/telemetry.py` 的 `InMemoryTelemetry` 是**全仓库零引用**的死代码。
- 影响：`docs/operations.md:5` 把 `doctor` 作为运维检查手段；工作空间位于只读挂载、磁盘满、权限不足时仍报 `ok/writable:true`，运维据此放过故障。
- 建议：`doctor` 走 `maintenance.doctor(telemetry)`；真实探测方式为在 `workspace/.probe` 写入并删除临时文件 + 校验 `current.json`/`state.json` 可读且 schema 受支持；失败时返回非零退出码 + `{"error": ...}` JSON（与 `PROJECT_NOT_FOUND` 同样的风格，见 P1-5）。
- 实测佐证：§8-G（把 `state.json` 的 schema 改坏后 `doctor` 仍 `exit 0 / status ok / writable true`，而 `project-get` 直接抛 `ValueError`）。

### P1-2 文档承诺的 `configure_host()` 在代码中不存在（**已降级表述**）

- 位置：`docs/integration.md:14`
- 现象：文档写"团队宿主必须使用单 worker，**并在后续实现中**通过 `configure_host()` 注入身份、执行、凭据、维护和遥测 Bridge"——原句已声明这是"后续实现"，因此**不算虚假承诺**；架构基线 `附件/…架构文档_v2.4.md:190` 也明确要求"宿主在 ASGI lifespan 启动阶段通过 `configure_host()` 注入实现及 host_capabilities……缺少首期必需能力时拒绝启用团队模式"。
- 真正的问题是**能力缺口不可见**：`AitestASGIApp`（`interfaces/asgi_host.py`）没有 `configure_host`、没有 lifespan 分支、没有 host_capabilities 握手、没有"缺能力即拒绝团队模式"的判定，也没有任何地方集中列出"与基线相比还缺哪些 Bridge"。接入方只能靠读源码自己发现。
- 建议：在 `docs/integration.md` 顶部加一张"与基线 v2.4 §4.1 的能力对照表（已实现／未实现）"，并在 `AitestASGIApp` 里显式声明 `SUPPORTED_HOST_CAPABILITIES = frozenset()`（空），使其"未实现"可被程序化检查而不是靠文档措辞发现。

### P1-3 `docs/architecture.md` 声称的"工作单元提交"未接线

- 位置：`docs/architecture.md:20`（"可信状态只能通过工作单元提交"）vs `application/ports/storage.py:27-28`（`WorkspaceUnitOfWork` 无实现、无调用方）
- 现象：`ProjectContext.create()` 直接调 `FileRecordRepository.put()`（`application/use_cases/project_context.py:12-15`），写路径绕过了"工作单元"概念；`WriterLease` 只在 infrastructure 内部使用。
- 影响：文档描述的写入事务语义与实际不符；跨多条记录的原子提交（未来做计划/执行/证据链必需）没有落点。
- 建议：把 `WorkspaceUnitOfWork` 变成真实端口并在 `FileRecordRepository` 上实现（同一把锁内多次 put 后统一提交 `state.json`），或删除该文档句子。

### P1-4 所有未知路径都返回 501，且被测试固化为契约

- 位置：`interfaces/asgi_host.py:19-24`；测试 `tests/integration/test_asgi_host.py:29-32`（`/runs` → 501）
- 现象：`GET /healt`（拼错）、`POST /health`（方法不对）、`GET /runs`（能力未实现）三者返回同一个 501 `CAPABILITY_NOT_IMPLEMENTED`，响应里回显 `method`/`path`。
- 影响：接入方无法区分"路径写错"与"能力还没做"；监控无法据此告警。测试把该行为写死，后续修正需要同时改测试。
- 建议：路径不匹配 → 404 `{"error":"NOT_FOUND"}`；路径匹配但方法不对 → 405 + `allow` 头；已知能力未实现 → 501 `CAPABILITY_NOT_IMPLEMENTED`（可从 `describe_capabilities()["planned"]` 派生路径白名单）。

### P1-5 CLI 无异常边界，错误风格不统一

- 位置：`interfaces/cli.py:42-50`
- 现象：唯一被处理的错误是 `project-get` 找不到（输出 JSON + 退出码 2）。`project-create` 重复创建会抛 `ConflictError`（`records.py:82`）→ 裸 traceback；空 `project_id` 抛 `ValueError`（`domain/projects.py:29-32`）→ 裸 traceback；`FeatureNotImplemented` 同理。
- 影响：`aitest` 作为命令行契约不可用（脚本无法按退出码分支），且与既有 JSON 错误风格不一致；traceback 会把工作空间绝对路径暴露到日志/CI 输出。
- 建议：在 `main()` 外包一层异常映射：`ConflictError → 409 {"error":"REVISION_CONFLICT"}`、`ValueError → 400`、`FeatureNotImplemented → 501`、`OSError → 5xx`，各自退出码 2/3/4；用 `--verbose` 才打 traceback。

### P1-6 读记录无容错：未知字段直接 `TypeError`（与已公布的字段演进计划冲突）

- 位置：`application/use_cases/project_context.py:17-28`（`Project(modules=normalized, **record)`）
- 现象：`record` 中多出任何非 `Project` 字段即抛 `TypeError: unexpected keyword argument`；同时**读入的 `schema_version` 完全不被校验**（与 `records.py:109-110` 对工作空间 schema 的严格校验风格相反）。
- 影响：`docs/formats.md:6` 明确说"操作者和时间审计字段将在身份桥接落地时加入"。届时旧记录（无审计字段）与新记录（有）必须能互读；当前实现下两边都会炸。这是**最可能阻塞下一个增量**的问题。
- 建议：`get()` 显式白名单映射字段 + 校验 `schema_version`（不支持的版本抛一个明确的 `UnsupportedSchema` 而不是静默或 `TypeError`），并补一条"记录含未知字段仍可读"的测试。

### P1-7 双人会签判定依赖输入顺序（逻辑 bug）

- 位置：`domain/reports.py:14-23`
- 现象：函数只以 `signatures[0]` 的 `(report_id, content_revision, content_hash)` 为基准统计签署人。因此
  - `(B, bob), (A, alice), (A, carol)` → `False`（A 报告明明有两人签署）
  - `(A, alice), (A, carol), (B, bob)` → `True`
  同一集合因顺序不同结论不同。
- 影响：会签是"报告可被接受"的门槛，顺序依赖意味着结论不可复现（取决于存储/查询顺序），是审计性缺陷。
- 建议：按 key 分组、`any(len(users) >= 2 for users in groups.values())`；并补覆盖乱序/跨报告/同人重复签名的测试（当前只有一条理想顺序用例 `tests/unit/test_reports.py`）。
- 实测佐证：§8-A。

### P1-8 版本号多处硬编码（漂移必然发生）

- 位置：`pyproject.toml:7`、`src/ai_test/__init__.py:7`、`application/use_cases/capabilities.py:7`（另有 `uv.lock:7`、`README.md:55`）
- 现象：`describe_capabilities()` 返回的 `version` 是字面量 `"0.1.0"`，与包版本无程序化关联。
- 影响：`/capabilities`、MCP 工具、CLI `capabilities` 都可能报告与真实安装版本不同的版本，宿主据此做兼容判断会出错。
- 建议：`capabilities.py` 改为 `from ai_test import __version__`（或 `importlib.metadata.version("ai-test-component")`），单一真相；能力清单同样建议与真实实现绑定（至少加测试断言 `ready` 项与实现一致）。

## 4. P1（新增，严重度最高）：`current.json` 丢失会静默清空记录索引

### P1-9 指针丢失 → `initialize()` 用空状态覆盖已存在的 generation 索引

- 位置：`infrastructure/file_store/records.py:28-43`（`initialize()`）、`records.py:99-100`（`_load_state()` 无条件先调 `initialize()`）、`composition.py:20`（每次 `create_component()` 都调 `initialize()`）
- 现象（§8-F 实测）：
  1. `init` + `project-create demo` 后：`generations/gen-000001/state.json` 的 `records = ['projects/demo']`，磁盘上有 `records/projects/demo/r00000001.json`；
  2. 删除 `current.json`（模拟指针丢失：备份恢复不完整、误清理、外部工具清理）；
  3. 再执行 `project-get demo` → `{"error":"PROJECT_NOT_FOUND"}`（退出码 2）；
  4. 此时 `state.json` 已被**覆盖成空状态**（`records = []`、`revision = 0`），而 `r00000001.json` 仍在磁盘上成为孤儿。
- 影响：`initialize()` 里 `generation = "gen-000001"` 是硬编码的，且**无条件**用新建的空 state 覆盖该 generation 的 `state.json`。也就是说"自愈"逻辑不是"报错并要求恢复"，而是"把索引清零"——数据文件还在，但组件再也读不到它们；如果这个 generation 有多年数据，一次清理动作就足以让整个工作空间变成空库。注意 `_load_state()` 会先调 `initialize()`，所以**读操作也会触发覆盖**（不限于写操作）。
- 建议：
  1. `initialize()` 里若目标 generation 的 `state.json` 已存在而 `current.json` 缺失，必须**报错**（`WORKSPACE_POINTER_MISSING`）或走显式恢复流程，绝不能覆盖；
  2. 新建 state 前先检查 `generations/<gen>/` 是否非空；
  3. `_load_state()` 不要调用 `initialize()`（读写分离，见 P2-1），缺指针时抛明确错误；
  4. 补一条回归测试：`init` → 写入记录 → 删除 `current.json` → 断言读取报明确错误且 `state.json` 未被改写。

## 5. P2：并发、可靠性、安全防御

### P2-1 持锁路径上会再次申请同一把非重入锁（自锁风险）

- 位置：`records.py:76-77`（`put()` 持锁）→ `records.py:77` 调 `_load_state()` → `records.py:100` 调 `initialize()` → `records.py:32-36` 在 `current.json` 不存在时 `with self._lease.acquire()`
- 现象：`initialize()` 的早退检查是"`current.json` 存在就返回"，因此正常路径不会重入；但只要 `current.json` 缺失（被清理、半初始化、外部误删），`put()` 就会在**已持有独占锁**的情况下再申请同一把锁。
- 实测（§8-H，`lock_timeout_seconds=0.5`）：在持锁状态下调用 `_load_state()` → `AlreadyLocked: (1, '[Errno 13] Permission denied')`，耗时 0.50s（正好等于锁超时）。也就是说这种恢复场景下用户看到的是**锁错误**，而不是"工作空间未初始化"，排查方向被误导；默认超时 10s 时表现为"卡 10 秒然后报锁失败"。
- 建议：拆分职责——把"确保目录/初始 generation 存在"设为只在 `initialize()` 中的动作，`_load_state()` 只读取并在缺失时抛明确错误（`WORKSPACE_NOT_INITIALIZED`），避免在临界区内做可能加锁的懒初始化。（与 P1-9 同一处修复）

### P2-2 存储层复杂度：`state.json` 全量重写 + `list()` O(N²)

- 位置：`records.py:88-96`（每次 put 重写整个 `state.json`，写放大 O(N)）、`records.py:55-63`（`list()` 对每个 key 调 `self.get()`，而 `get()` 每次都重新读+解析 `state.json`）
- 影响：`list` 遍历 N 条记录要做 N 次 state 解析；N 大时面板/报告接口会明显变慢，且 `list()` 生成的游标快照与遍历期间的新写入语义未定义（`value` 也从未被校验连续）。
- 实测（§8-J）：5 条记录 `list()` 一次 → `_load_state()` 被调用 **6 次**（1 次遍历 + 5 次逐条 `get()`），确认为 1+N 而非 1 次。
- 建议：`list()` 复用同一次 `_load_state()` 结果（传入已解析 state 的内部读取路径）；中期把记录索引切成按 kind 分片的索引文件或 SQLite 单文件（`generations` 轮转 + `migrations.py` 本就是这个方向的铺垫）。
- 备注：`tests/performance/README.md` 已声明该基线待补，建议在补性能测试前先做 P2-2 的重构，否则基线测的是一次性实现。

### P2-3 崩溃恢复卫生缺失（与 `tests/recovery/README.md` 承诺对应）

- 现象：(a) `_atomic_json` 用 `tempfile.mkstemp(prefix=f".{path.name}.")` 产生临时文件，异常路径会清理，但**进程被 kill 的孤儿临时文件永不回收**；(b) `os.replace` 后**未 `fsync` 父目录**（POSIX 下掉电可能丢 rename）；(c) `WriterLease` 无租约/陈旧锁回收（`locks.py` 整体 24 行）；(d) 无 generation 轮转/压缩（`migrations.py` 未接线，`supported_workspace_schema()` 零引用）。
- 建议：启动时提供一个显式的 `recover()`（清理匹配 `.*\.json\..*` 的孤儿文件 + 校验 `current.json` 指向的 state 可解析，失败则回退到上一个可用 generation）；`_atomic_json` 增加父目录 `fsync`（Windows 上可只做 `os.replace`，需分支处理）。

### P2-4 `put()` 静默覆盖传入的 `revision`

- 位置：`records.py:86-87`（`document["revision"] = revision`）
- 现象：调用方 payload 里带的 `revision`（例如 `asdict(Project(...))` 的结果）会被无条件覆盖，且不提示；同时没有任何路径能"拒绝"一个携带陈旧 revision 的 payload（只能通过 `expected_revision` 参数，语义重复但不等价）。
- 实测（§8-I）：`put("projects","x",{"name":"n","revision":999})` → 返回 1，`get()` 得到 `{'name': 'n', 'revision': 1}`，**没有任何报错**。
- 建议：`put()` 里校验 `payload.get("revision", actual) == actual_revision`，不一致就报错；或干脆在 `payload` 中剥离 `revision` 字段并集中由存储层管理。

### P2-5 `asset_text()` 无路径校验（潜在的包资源穿越）

- 位置：`interfaces/panel.py:4-5`（`files("ai_test.resources.panel").joinpath(name).read_text()`）
- 现象：`name` 未做白名单校验，`..` 段会被透传。当前唯一调用方是测试，但该函数是将来做"面板静态资源服务"的天然入口——一旦接入 HTTP 端点就是任意文件读取。
- 实测（§8-C）：`asset_text('../../../../pyproject.toml')` **成功读出仓库根的 pyproject.toml（1247 字节，首行 `[build-system]`）**；`asset_text('../schemas/host-event.schema.json')` 也读到包内兄弟目录文件 —— 穿越成立，不是理论风险。
- 建议：现在就加白名单（只允许 `index.js` / `styles.css` 或校验 `Path(name).name == name and name in allowlist`），成本极低、消除未来回归。

### P2-6 `rules/`、`prompts/`、`templates/`、`schemas/` 资源无人加载

- 现象：全仓库 grep `rules/default`、`prompts/`、`host-event` 只命中资源文件自身。`resources/rules/default.md` 的三条红线（AI 不得伪造执行结果、证据需关联来源/时间/执行上下文、生产只读）、`prompts/evidence-review.md`、`templates/report.md`、`schemas/host-event.schema.json` 都没有加载器、没有版本绑定、没有校验点。
- 影响：这些是本项目"可信 AI 测试"的核心约束，但在代码层面目前是**装饰性资源**——将来"证据复核"用例完全可能绕过它们；`host-event.schema.json` 也没有任何生产者/消费者（ASGI 层没用它做事件校验）。
- 建议：为规则/提示词建立最小加载端口（返回版本化 `RuleSet`，与 `domain/rules.py` 的 `DRAFT/PUBLISHED/RETIRED` 对齐），并在"证据复核"用例里把 `rules/default.md` 的内容注入系统提示；`host-event.schema.json` 或接入 `validate` 调用，或删除以免误导。

### P2-7 Windows 平台未覆盖，段校验不足以挡住非法文件名的裸 `OSError`

- 位置：`records.py:113-116`（只拒绝空、`.`、`..`、`/`、`\`）
- 现象：Windows 上 `aux`/`con`/`prn`/`nul` 等保留设备名、以及 `:`、`*`、`?`、`"`、尾随空格/点都是非法文件名；这些 `record_id` 会一路走到 `mkstemp`/`os.replace`，抛**未包装的 `OSError`**（对 CLI 就是 traceback，见 P1-5）。
- 影响：本项目目标宿主含 Windows（当前开发机就是 Windows），且 CI 只跑 `ubuntu-latest`，此类缺陷不会被 CI 捕获。
- 建议：`_validate_segment` 增加 Windows 保留名/非法字符集合与端口禁用资产（`|`、`<`、`>`），并把 `OSError` 包装成领域错误；CI 增加 `windows-latest` 矩阵（成本低、收益直接）。

## 6. P3：工程质量与一致性

1. **`requires-python = ">=3.13,<3.14"`**（`pyproject.toml:10`）：把 3.14 排除在外，且不支持 3.12；团队环境若不是 3.13 直接无法安装。实测（§8-L）：wheel 元数据为 `Requires-Python: <3.14,>=3.13`，而本机**只装了 Python 3.14.7** → `pip install .` 会被拒。讽刺的是代码在 3.14 上跑得通（本次 9/9 测试就是在 3.14.7 上通过的），说明这个上界并非技术必需，而是刻意钉死。建议 `>=3.12,<4`（`StrEnum` 只需 3.11+）。
2. **`[project.optional-dependencies] team = []`**（`pyproject.toml:20`）：空 extra，无意义，删除或补内容（实测：wheel 的 METADATA 里确实没有 `team` 的 `Requires-Dist`）。
3. **sdist 被打包白名单截断（已实测确认）**：`[tool.hatch.build] include`（`pyproject.toml:37-40`）只列 `src/ai_test/**/*.py` 与 `resources/**/*`。实测（§8-N）`python -m build` 产出：
   - wheel（69 条目）：只有 `ai_test/`，资源齐全（`resources/panel/index.js`、`rules/default.md`、`schemas/host-event.schema.json` 都在）——✅ 运行所需资源没漏；
   - sdist `ai_test_component-0.1.0.tar.gz`（69 条目）：**`tests/`、`docs/`、`examples/`、`.github/`、`uv.lock` 全部为 0 项**，只剩 `pyproject.toml`、`README.md`、`src/`、`.gitignore`、`PKG-INFO`。
   - 影响：从 sdist 安装的消费者拿不到测试与文档，无法在本地复现 CI；`docs/`（接入说明）恰恰是接入方最需要的文件。建议把 `tests/`、`docs/` 加入 `include`（或改用 `[tool.hatch.build.targets.sdist] include`，wheel 仍只装 `src/`）。
4. **`examples/web-component/index.html` 只在源码树内可用**：它用相对路径 `../../src/ai_test/resources/panel/index.js` 引用 JS，安装后该路径不存在；且**没人引用 `styles.css`**，`<ai-test-panel>` 永远只有浏览器默认样式。建议示例改为从包资源取文本（或提供 `asset_text("styles.css")` 注入 `<style>` 的示例）。
5. **领域模型校验风格不一致、测试覆盖不均**：`Project`/`Module` 有强校验（`domain/projects.py:13-17,28-37`），但 `EvidenceReference.sha256` 不校验长度/十六进制（`domain/evidence.py:21-26`，而 `objects.read_bytes` 对摘要做了严格校验）、`Defect.defect_id` 无校验（`domain/defects.py:22-27`）、`Module.dependencies` 无存在性/环检测（`domain/projects.py:7-11`）。除 `has_two_distinct_signers` 外，`defects/evidence/runs/deliveries/plans/quotas/rules/access` 全部零测试。
6. **死代码/未接线清单**（全仓库仅定义处命中）：`maintenance.doctor`、`InMemoryTelemetry`、`write_markdown`、`MigrationPlan`/`supported_workspace_schema`、`Page`、`WorkspaceUnitOfWork`、`QuotaPolicy`、`Revision`/`SourceControlPort`、`VerificationResult`/`VerificationPort`、`Identity`/`IdentityPort`/`SecretPort`、`Delivery`、`Defect`、`Checkpoint`、`RuleSet`、`TestCase`/`AcceptanceItem`、`EvidenceReference`、`host-event.schema.json`、`styles.css`，以及 `adapters/github.py`、`adapters/http.py`、`adapters/database_check.py`、`adapters/agent.py`（4 个只有 docstring 的空文件）。**其中"有意占位"应当在文件头写明"未接线（unwired）"，避免下游误以为可用。**
7. **无 logging、无 Clock 实现**：`application/ports/system.py` 的 `Clock`/`WorkspaceLocator` 无任何 infrastructure 实现，全包无 `logging`。而"来源 + 时间"恰好是 `rules/default.md` 与 `docs/formats.md` 对证据/审计的要求 → 时间来源缺失会在做审计字段时立刻成为阻塞。
8. **应用层无法表达冲突**：`ConflictError` 定义在 `infrastructure/file_store/records.py:13`，`application` 若要映射成"重试/409"就必须反向 import infrastructure（违反 `interfaces → application → domain` 的声明方向）。建议把 `Conflict`/`NotFound`/`UnsupportedSchema` 上移到 `application/errors.py`，由 infrastructure 抛出应用层错误。
9. **MCP 入口丢弃组件实例**：`interfaces/mcp_server.py:16` 调用 `create_component(workspace)` 却不使用返回值（只为初始化副作用），后续要暴露真实工具时必须改签名；建议显式 `_ = ` 加注释或先存起来。
10. **README 与 CLI 默认工作空间不一致**：README 用 `.aitest-data`，CLI 默认 `.aitest`（`interfaces/cli.py:19`）；`.gitignore` 只忽略 `.aitest-data/`，默认路径会产生未忽略的 `.aitest/` 工作空间。
11. **需求/架构文档在 `附件/` 目录中（初稿误判为缺失，已更正）**：`附件/AI辅助测试平台需求文档_v1.0.md`、`附件/AI辅助测试平台技术架构文档_v2.4.md` 就是 `README.md:55` 与 `tests/acceptance/README.md:3` 引用的"需求文档"。两点仍值得处理：(a) README 引用时没给路径，读者容易以为文档在仓库外（本次审查自己就踩了）；(b) 目录名"附件"暗示它是外部材料，但它实际是**验收基准**，建议移到 `docs/spec/` 或在 README 里写明确路径；(c) 这两份文档不会进 sdist（见 §6-3），从包安装的消费者拿不到验收基准。
12. **测试基建限制**：`tests/integration/test_asgi_host.py:7-20` 的 `request()` 硬编码 GET、忽略请求体、每个用例自建事件循环 —— 无法覆盖 405/404/请求体/并发场景；`tests/conftest.py:4` 手动 `sys.path.insert` 与 `uv sync` 的可编辑安装重复。
13. **`WriterLease` 函数内 import `portalocker`**（`locks.py:15`）：`portalocker` 是**必需**依赖（`pyproject.toml:15`），延迟导入只增加噪音；若意图是"可选的锁后端"，应做成真正的可选 extra 并给出退化策略。
14. **依赖上界没有任何验证证据**：`httpx<1`、`portalocker<4`、`pydantic<3`、`mcp<3` 等上界在 CI 里从不测试（CI 只跑 `uv sync --locked` 的锁定版本），锁 API 又恰是 `locks.py` 直接调用的部分，一旦放宽上界没有任何防线。建议至少加一条"用最新可用版本跑一次测试"的定期任务。**本次审查未能验证 portalocker 4.x 是否兼容**（沙箱把本地安装截断过一次，导致一次 `AttributeError` 是环境残缺而非项目问题——故不作为结论）。

## 7. 建议的修复顺序（按性价比）

1. **SC01 + SC02（排期决策，先做）**：按架构 §13 补齐"最小纵向原型"所需的分块索引 + 写入协调者，把 `state.json` 从"全量记录表"改成"当前修订 + 分块入口"；在完成前不再新增业务用例实现
2. **P1-9 / P2-1（同一处）**：`initialize()` 不得覆盖已存在的 generation state；`_load_state()` 只读、缺指针时报明确错误；补回归测试
3. **P1-1 / SC07 `doctor` 别撒谎**（把常量换成真实检查：指针、state schema、可写探测、备份年龄占位）+ **P1-5 CLI 错误映射**（半天内可完成，直接消除"运维被误导"与"命令行不可用"）
4. **SC05 / P1-6 版本门禁与反序列化容错**（该拒的版本拒、该忍的字段忍；不做这个，下一步加审计字段就会踩）
5. **P1-7 会签判定顺序无关化** + 补参数化测试（并顺带补"授权用户/不能自签"校验，对齐需求 §9:401）
6. **SC09 DeepSeek 默认模型改回基线批准的 `deepseek-v4-pro`、禁用 `deepseek-chat`**
7. **SC06 ASGI 错误信封 + 路由前缀 + 404/405/501 分离**
8. **P2-5 `asset_text` 白名单**（已实测可穿越仓库文件）、**SC12 sdist 补 tests/docs**
9. **SC03/SC04/SC08/SC10/SC11 数据与端口对齐**（`writer_epoch`、`WORKSPACE_IN_USE` 诊断、`IdGenerator`、状态枚举补全、保留期常量）
10. **SC13 `.aitest` 语义与 `.gitignore` 修正**、**P2-7 Windows 段校验 + CI 加 windows-latest**
11. **P2-6 规则/提示词加载端口**（与"证据复核"增量一起做，并对齐 SC12 的 `exports/`、五类 prompt 模板）

## 8. 实测证据（本次审查真实执行）

环境：Windows 10/11 + Python **3.14.7**（本机唯一解释器）、pytest 9.1.1、portalocker **3.2.0**（项目声明区间内 `>=3.2,<4`）、hatchling 1.32.0、`build` 1.6.1。
复现脚本（可直接重跑，只读写 `.review-probe/`）：`review_probe.py`、`review_archive_check.py`。

| 编号 | 被验证的发现 | 实际命令 | 结果 |
| --- | --- | --- | --- |
| A | P1-7 会签判定顺序依赖 | `python review_probe.py`（A 段） | `[(B,bob),(A,alice),(A,carol)] → False`；`[(A,alice),(A,carol),(B,bob)] → True` —— **同一集合，结论随顺序翻转，确认是 bug** |
| B | P1-6 未知字段崩溃 / 未知 schema 静默接受 | 同上（B 段） | `TypeError: Project.__init__() got an unexpected keyword argument 'operator'`；`schema_version='aatp.project/9.9'` 被**静默接受**（读出 `'aatp.project/9.9'`）——两项均确认 |
| C | P2-5 `asset_text` 路径穿越 | 同上（C 段） | `asset_text('../../../../pyproject.toml')` → **1247 字节，首行 `[build-system]`**（读到仓库根文件）；`../schemas/host-event.schema.json` → 470 字节。**穿越成立** |
| D | P1-8 版本三处硬编码 | 同上（D 段） | `pyproject.toml=0.1.0`、`__version__=0.1.0`、`capabilities.version=0.1.0`——当前一致，但三处独立维护 |
| E | P1-5 CLI 无异常边界 | 同上（E 段，进程内调 `cli.main`） | `init`/`project-create`/`project-get`/`capabilities`/`doctor` → exit 0；**重复 `project-create` → 未捕获 `ConflictError: expected revision 0, found 1`**；**空 `project_id` → 未捕获 `ValueError: project_id must not be empty`**；只有 `project-get 不存在` 被处理（exit 2 + `PROJECT_NOT_FOUND`） |
| F | **P1-9 指针丢失静默清空索引（新发现）** | 同上（F 段） | 删 `current.json` 前：`state.records=['projects/demo']`、`state.revision=1`、磁盘有 `r00000001.json`；删除后执行 `project-get demo` → `PROJECT_NOT_FOUND`（exit 2），且 `state.json` 被覆盖为 `records=[]`、`revision=0`，而 `r00000001.json` 仍留在磁盘上 —— **索引被静默清零，数据不可达** |
| G | P1-1 `doctor` 不做任何检查 | 同上（G 段） | 把 `state.json` 的 `schema_version` 改成 `aatp.workspace-state/0.0-broken` 后：`doctor` 仍 `exit 0 / {"status":"ok","writable":true}`；而 `project-get` 抛 `ValueError: unsupported workspace state schema` —— **doctor 报告与实际健康状态无关** |
| H | P2-1 持锁路径再次加锁 | 同上（H 段，`lock_timeout_seconds=0.5`） | 持锁状态下调 `_load_state()` → `AlreadyLocked: (1, '[Errno 13] Permission denied')`，耗时 **0.50s**（= 设定超时）——错误是锁失败而非"工作空间未初始化" |
| I | P2-4 `put()` 静默覆盖 payload revision | 同上（I 段） | `put("projects","x",{"name":"n","revision":999})` → 返回 1；`get()` = `{'name': 'n', 'revision': 1}`，**无任何提示** |
| J | P2-2 `list()` 的 state 重读次数 | 同上（J 段，包一层计数器） | 5 条记录 `list()` 一次 → `_load_state()` 调用 **6 次**（1+N），确认 O(N²) 解析 |
| K | 冲突错误所在层 | 同上（K 段） | `ConflictError.__module__ = ai_test.infrastructure.file_store.records`；陈旧 `expected_revision` 正确抛错（这层逻辑本身是好的） |
| L | P3-1 `requires-python` 钉死 3.14 | 读 wheel METADATA | `Requires-Python: <3.14,>=3.13`；本机只有 3.14.7 → `pip install .` 必被拒；但源码在 3.14.7 上跑测试全通过（见 M） |
| M | 基线：现有测试是否通过 | `python -m pytest -q`（TEMP 指向工作空间内） | **`......... [100%]`，9 条全部通过，exit 0**（3.14.7 + portalocker 3.2.0） |
| N | P3-3 打包内容 | `python -m build --sdist --wheel` + `review_archive_check.py` | wheel 69 条目、`ai_test/resources/**` 齐全；**sdist 69 条目但 `tests/`、`docs/`、`examples/`、`.github/`、`uv.lock` 各 0 项**——白名单截断确认 |

测量说明：
- `uv` 未安装，本机只有 Python 3.14（项目要求 3.13），因此用「源码树直接跑 + 用户级 site-packages 装 pytest/portalocker/build/hatchling」的方式取证，未使用项目的 `uv sync`。**本次未能验证 `uv sync --extra dev --locked` 与 CI 步骤本身。**
- 本机沙箱多次拒绝子进程写临时目录，曾导致一次 `pip --target` 安装被截断（portalocker 变成空目录 → 一次 `AttributeError: module 'portalocker' has no attribute 'Lock'`）。**该 `AttributeError` 是环境残缺所致，不作为 portalocker 4.x 不兼容的证据**；最终取证全部在 portalocker 3.2.0（声明区间内）完成。
- §8-B/H/I/J 的复现是"直接调用被测代码路径"（含构造持锁状态），不是端到端用户操作；§8-E/F/G/M/N 为真实端到端执行。

## 9. 与架构基线 v2.4 的冲突清单（新增）

> 依据：`附件/AI辅助测试平台技术架构文档_v2.4.md`（下称"架构"）与 `附件/AI辅助测试平台需求文档_v1.0.md`（下称"需求"）。这一节的价值在于区分两类问题：**「还没做」（可接受的骨架状态）** 与 **「已经写成与基线相反的样子」（必须改，否则越写越贵）**。下表只列后者与关键前置项。

### SC01 §13 的架构准入条件尚未满足，且当前存储方向与基线相反（**最高优先**）

- 架构 §13:539-541 明确规定：**"文件存储、ASGI 宿主挂载和 Bridge 契约必须先完成一条最小纵向原型，再进入其余业务模块开发"**，原型要求 10 个真实会话、3 个并行测试、写入队列等待 p95 ≤ 250ms、文件提交 p95 ≤ 500ms、空闲内存 ≤ 200 MiB、固定数据集（1,000 任务 / 10,000 运行 / 1,000,000 链路节点 / 50 GiB 证据）；**"任一核心指标不达标时，停止在当前文件后端上扩展业务功能"**。
- 现状：仓库实现的第一块业务是 `project-context`（属于业务模块），而 §13 要求先做的三件事（写入协调者队列、分块索引、宿主 Bridge 契约）全部缺失；同时存储层采用的是架构 §5.2:284 明令禁止的"state.json 内嵌全部记录"方案。
- 影响：按基线口径，**当前不应该继续在此文件后端上加"交付/计划/执行/证据"等业务模块**，否则每个新模块都会绑死在待重构的索引结构上。
- 建议：把下一步排期定为"最小纵向原型 + 存储层按分块索引重做"，而不是挑一个 `FeatureNotImplemented` 用例去实现。

### SC02 `state.json` 内嵌全部记录并整体重写（与架构 §5.2 直接冲突）

- 基线（架构 §5.2:284、§13:537）：**"state.json 只保存当前修订、分块入口及全局额度，不内嵌所有历史记录或链路节点。每次提交仅生成受影响块及新的入口……一次业务提交只重写受影响的索引块，不随工作空间总记录数线性增长。"**
- 现状：`records.py:38` 的 `state = {"schema_version":…, "revision":0, "records":{}}` 把每条记录的 `{revision, path}` 全塞进 `state.json`，`records.py:91-96` 每次 `put()` 重写整个文件；`records.py:55-63` 的 `list()` 还逐条重读（§8-J 实测 6 次/5 条）。
- 影响：写入与读取成本都随总记录数线性增长，正好是基线的准入红线；`indexes.py` 的 `Page`（分页游标）与 `migrations.py` 的 generation 轮转都是为此准备的，但都未接线。
- 建议：先落地 `RecordRepository` 的分块索引契约（`摘要页 ≤ 200 条`、按 kind/项目分块入口），再迁移现有 `aatp.workspace-state/1.0`。

### SC03 `current.json` 缺 `writer_epoch`（架构 §5.1:252）

- 基线：`current.json` 保存**"当前 generation 与 writer_epoch"**，且 §5.2:280 要求"每次提交把 writer_epoch 写入 current.json 与状态，提交前再次核对，拒绝旧协调者的迟到提交"。
- 现状：`records.py:40-43` 写出的指针只有 `{"schema_version": "aatp.workspace-pointer/1.0", "generation": "gen-000001"}` —— 没有 epoch 字段，也没有任何 epoch 递增/核对逻辑。
- 影响：RV01（写入恢复：只有当前 writer_epoch 能提交）在当前数据结构下**无法实现**，且旧写入者迟到提交无从拒绝。
- 建议：`current.json` 现在就加 `writer_epoch`（默认 0），即使暂时不用也避免后续改格式。

### SC04 锁语义与基线不符：无协调者队列、无租约诊断、无 WORKSPACE_IN_USE、无心跳降级

- 基线（架构 §5.2:276-280）：有界优先队列（100 个已验证提交意图，其中 10 个专供终态，普通达到 90 → `RATE_LIMITED` + `retry_after_ms`）；第二写进程 10 秒内取不到租约 → 返回 `WORKSPACE_IN_USE` **及脱敏持有者诊断**；锁旁记录 instance_id/PID/进程启动时间/主机编号/取得时间 + 每 5 秒心跳；心跳 > 30 秒 → `NOT_READY` 且停止接收新写动作。
- 现状：`locks.py` 全文 24 行，只有一个 `portalocker.Lock(LOCK_EX|LOCK_NB, timeout=10)` 上下文管理器；没有队列、没有 epoch、没有侧车元数据、没有心跳、没有 `WORKSPACE_IN_USE` 映射（§8-H 实测失败时抛裸 `AlreadyLocked`）。
- 影响：RV01/RV02 与 §13"写入队列等待 p95 ≤ 250ms"都没有落点；错误语义也与需求 §4.1 的 13 个标准错误码不一致。

### SC05 记录未做结构版本门禁（架构 §5.3:292）

- 基线：**"已知旧版本进入只读待迁移状态；未知或更高版本拒绝挂载，不能按当前结构猜测读取。"**
- 现状：工作空间级 schema 有校验（`records.py:109-110` 抛 `unsupported workspace state schema`，符合基线），但**记录级完全没有**：§8-B 实测 `schema_version="aatp.project/9.9"` 被静默读入并当成正常对象返回；同时多出未知字段直接 `TypeError`（同一探针）。
- 影响：一个"该拒绝的版本猜着读"、一个"该容忍的演进字段直接崩"，两个方向都错。
- 建议：`ProjectContext.get()` 增加版本白名单 + 未知字段显式忽略（或按 §5.3 抛 `WORKSPACE_SCHEMA_UNSUPPORTED`）。

### SC06 ASGI 面与基线的路由/错误契约不一致（架构 §1.1:24、§4.1:186-188）

- 基线：挂载前缀默认 `/plugins/ai-test`（宿主可改）；路由为 `GET /capabilities`、`POST /queries/{name}`、`POST /actions/{name}`、`GET /events`、`POST /mcp`、`GET /health`、`GET /metrics`；错误码固定 13 个（`INVALID_ARGUMENT`/`UNAUTHENTICATED`/`FORBIDDEN`/`NOT_FOUND`/`CONFLICT`/`STALE_REVISION`/`CAPABILITY_UNAVAILABLE`/…），错误体含 `message`、`retryable`、`retry_after_ms`、`correlation_id` 与字段问题，**不返回堆栈、文件绝对路径或凭据**；`/metrics` 仅宿主监控身份可访问。
- 现状：`asgi_host.py` 只处理裸 `/health`、`/capabilities`，其余**一律 501** + `{"error": "CAPABILITY_NOT_IMPLEMENTED", "method": …, "path": …}`（拼错路径、方法不对、能力未实现三者无法区分）；无前缀协商、无 `correlation_id`、无 `retryable`，错误码词表与基线不一致（基线是 `CAPABILITY_UNAVAILABLE`）；`tests/integration/test_asgi_host.py:29-32` 把这个行为固化成了契约。
- 建议：先按基线实现"错误信封 + 路由前缀 + 404/405/501 分离"，再让测试断言基线的错误码。

### SC07 `doctor` / `health` / `metrics` / `diagnostics` 未按基线实现（架构 §4.5:236-240）

- 基线：对外提供 `health()`、`metrics()`、`diagnostics()` 与 `aitest status`、`aitest doctor`；健康分 `HEALTHY/DEGRADED/NOT_READY`，检查项含"工作空间能否读取、当前结构版本、写入协调者状态、摘要恢复、活动运行、容量与预算、最近完整备份年龄"。
- 现状：`aitest doctor` 打印**常量** `{"status": "ok", "writable": true}`（§8-G 实测：state.json 已损坏仍报 ok）；`maintenance.doctor(telemetry)` 与 `InMemoryTelemetry` 零引用；`health()`/`metrics()`/`diagnostics()` 不存在。
- 建议：这是投入产出比最高的一处——把 `doctor` 接到真实检查（读指针、校验 state schema、探测可写、报告备份年龄占位）即可让运维命令不再撒谎。

### SC08 端口清单与基线不一致（架构 §3:164）

- 基线首期端口固定为：`WorkspaceUnitOfWork`、`RecordRepository`、`EvidenceObjectStore`、`ExecutionPort`、`IdentityPort`、`SecretPort`、`ModelProvider`、`Clock`、**`IdGenerator`**、`TelemetryPort`。
- 现状：`application/ports/system.py` 声明的是 `Clock` + `WorkspaceLocator`——**缺 `IdGenerator`，多 `WorkspaceLocator`**；`IdGenerator`（编号生成）在基线里是记录编号的来源，缺失会导致"编号/幂等键"无处生成。
- 建议：补 `IdGenerator` 端口（`next_id(kind) -> str`），把 `WorkspaceLocator` 要么并入 composition 配置、要么在文档里说明它替代了哪个基线概念。

### SC09 DeepSeek 默认模型使用了基线**明令禁止**的名称（架构 §8.1:371-373）

- 基线：批准配置为 `provider=deepseek`、`base_url=https://api.deepseek.com`、`requested_model=deepseek-v4-pro`、`thinking=disabled`，且**"不得使用已经停止服务的 `deepseek-chat` 或 `deepseek-reasoner` 兼容名称"**；模型配置必须落在版本化的 model profile（含 provider_release、价格版本、上限、超时、启用状态），不硬编码在业务/适配器代码里。
- 现状：`infrastructure/adapters/deepseek.py:9` 写着 `default_model = "deepseek-chat"` —— 正是基线点名禁用的名称；且没有 model profile 结构，`ModelProvider` 端口（`model_provider.py`）只有 `complete()`，缺基线要求的 `validate_profile`/`estimate_cost`/`invoke`/`normalize_usage`/`health`。
- 建议：改默认值并按基线补齐 profile 相关方法签名；这一条改动很小，但**留着就是把一个已停服的模型名作为项目默认**。

### SC10 领域枚举不足以表达基线要求的状态（架构 §6:306,316；需求 §7.2、§8）

- `RunStatus`（`domain/runs.py:7-14`）：QUEUED/RUNNING/PAUSED/COMPLETED/BLOCKED/CANCELLED/ERROR。基线要求 10 态：未执行、排队、执行中、**暂停中**、已暂停、完成、阻塞、**取消中**、已取消、执行异常；其中"取消中"是刚性要求——架构 §6:316 规定"取消必须取得执行环境的进程停止确认，未确认时维持取消中"。当前枚举**无法表达"暂停中/取消中/未执行"**，即基线要求的中间态在模型上不存在。
- `DefectStatus`（`domain/defects.py:14-19`）：DRAFT/CONFIRMED/IN_PROGRESS/READY_FOR_RETEST/CLOSED。需求 §8:397-405 要求 6 态（草稿、待确认、已确认、处理中、待复测、已关闭）**外加**"不属于缺陷、重复、暂缓"三种结论（均需原因）。当前缺"待确认"与那三种分类。
- `AssertionStatus`（未判定/通过/失败/不适用）与 `Authenticity`（REAL/MOCK/MIXED/UNKNOWN）**与基线完全一致** ✅；`AcceptanceSignature` 的 `(report_id, content_revision, content_hash, user_id)` 字段也与需求 §9:403 的签署绑定要求一致 ✅——问题只在判定函数（P1-7）与"授权用户/不能自签"缺失。

### SC11 记录最小字段与保留期规则缺模型（架构 §5.1:268、§11.2:440；需求 §11.3:455）

- 基线：**"每条记录至少有编号、类型、结构版本、内容修订、创建人、时间及来源引用"**；保留期为"普通证据 90 天、已签署报告 365 天、未关闭缺陷证据持续保护（关闭后 ≥180 天）、业务元数据与审计 3 年，重叠取最长"。
- 现状：`Project` 有编号/结构版本/内容修订，**没有创建人、时间、来源引用**（`docs/formats.md:6` 承认要等身份桥接）；`domain/quotas.py` 的 `QuotaPolicy` 只有 5 个数字（预算/容量，且与架构 §11.1:428 完全一致 ✅），**没有任何保留期字段**，保留规则在代码里无表示。
- 建议：`QuotaPolicy` 增加 `retention_*` 字段（值直接取需求 §11.3），即使暂不执行也把规则固化成常量，避免各处各写一份。

### SC12 目录与资源布局与基线 §3 的声明不一致（架构 §3:139-160、§4.3:218）

| 基线声明 | 仓库实际 | 说明 |
| --- | --- | --- |
| `tests/unit/domain/`、`tests/unit/application/` | `tests/unit/`（扁平 3 个文件） | 无分层归属 |
| `tests/contracts/`（端口、Host Protocol、适配器契约） | **不存在** | §3:166 要求"端口契约以测试替身验证业务用例，再用同一组契约测试验证实现"，当前零契约测试 |
| `tests/reliability/` | `tests/recovery/` | 名称不符（内容同为 README 占位） |
| `tests/architecture/` 需检查"依赖方向**与循环导入**" | 只有依赖方向 | 缺循环导入检查（§3:166） |
| `examples/host-integration/`、`examples/ticket-demo/` | `examples/web-component/`、`examples/embedded-python/` | 基线要求的是宿主接入示例与工单示例，两者都缺 |
| `resources/exports/`（标准 Markdown 模板）、`prompts/`（**五类** AI 任务模板） | `resources/templates/report.md`、`prompts/evidence-review.md`（**1 个**） | 目录名与文件数都不符 |
| `resources/panel/`（JS、CSS 与 **HTML 模板**） | `panel/index.js`、`panel/styles.css` | 缺 HTML 模板，且 CSS 无人引用（P3-4） |

### SC13 `.aitest` 的语义与基线相反，且 `.gitignore` 恰好忽略错了对象（架构 §5.1:246）

- 基线：**"项目内的 `.aitest/` 只放可编辑配置、待审核规则和模板。可信运行记录放在宿主控制的数据目录，正式团队模式下普通开发用户不能直接写该目录。"**
- 现状：CLI 默认 `--workspace` 就是 `.aitest`（`interfaces/cli.py:19`），即**把可信记录写进"只应放配置"的目录**；而 `.gitignore:16` 忽略的是 `.aitest-data/`（README 用的示例路径），**不忽略 CLI 默认的 `.aitest/`**。
- 影响：默认用法下产生的项目/修订记录（未来还有证据与审计）位于**可被 git 提交**的目录里，与"可信记录不能由普通开发用户直接写/不应随源码流转"的基线意图冲突。
- 建议：默认工作空间改为明确的数据目录（如 `.aitest-data`），`.aitest/` 仅留给配置；`.gitignore` 同步忽略默认数据目录，并加注释说明区别。

### SC14 骨架已符合基线的点（值得保持）

- 零数据库、零消息队列、零专用 API/Worker/Runner 服务（架构 §1:13、§13:545）——仓库里没有任何此类痕迹 ✅
- 一个 Python 包 + src 布局，资源随包安装（§2:71）：§8-N 实测 wheel 中 `ai_test/resources/**` 齐全 ✅
- 依赖方向与架构测试（§3:162,166）：`domain` 零外部依赖，AST 测试守卫反向导入 ✅（缺循环导入检查）
- 配额数字与架构 §11.1:425-428 完全一致：日 30 元 / 月 500 元 / 单附件 20 MiB / 单运行 200 MiB / 活动证据 100 GiB ✅
- 断言与真实性状态词汇、签署绑定字段、报告双签规则字段与需求 §7.2/§9 一致 ✅
- 首期只接隔离环境、不开放生产入口（需求 §11.2:448）——骨架连执行适配器都未实现，无越界风险 ✅
- 基线明确说"上述目标是建设验收指标，不代表当前已经实现"（架构 §13:561），与 README 的诚实声明一致 ✅

## 10. 更正与自我纠错（审查过程留痕）

| # | 初稿结论 | 事实 | 处理 |
| --- | --- | --- | --- |
| C1 | "需求文档被引用但不在仓库"（原 P3-11） | **错**：`附件/AI辅助测试平台需求文档_v1.0.md`（494 行）与 `附件/AI辅助测试平台技术架构文档_v2.4.md`（563 行）都在仓库内，且正是完整验收基准 | 已重写 P3-11（改为"引用未标注路径 + 不进 sdist"），并在开头声明更正。漏读原因：初轮只用按文件匹配的 glob（`*`、`**/*.md`）而没有枚举目录；随后用 `Get-ChildItem` 逐层核对目录，确认**只有 `附件/` 被漏掉**（内含恰好这 2 个文件），仓库其余目录无遗漏 |
| C2 | "文档承诺的 `configure_host()` 不存在"（原 P1-2） | **表述过度**：文档原句是"**在后续实现中**通过 `configure_host()` 注入"，本身已标注未完成；架构基线 §4.1:190 正是如此设计 | 已重写 P1-2（降级为"能力缺口不可见"，并建议加 `SUPPORTED_HOST_CAPABILITIES` 使其可程序化检查） |
| C3 | 一次 `AttributeError: module 'portalocker' has no attribute 'Lock'` 曾被怀疑为 "portalocker 4.x 不兼容" | **环境问题**：沙箱截断了 `pip --target` 安装，`portalocker/` 只剩空目录（`__file__ = None`），属本地依赖残缺 | 未写入任何结论；§8 已标注该异常不作为证据，最终取证全部使用声明区间内的 portalocker 3.2.0 |
| C4 | —— | 初稿只审"代码内部一致性"，未对照基线文档；补读后发现 P1-9/P2-1/P2-2/P1-6 同时是**基线冲突**，并新增 12 类 SC 项 | 新增 §9 专节，并把修复顺序按"基线准入优先"重排（§7 第 1 项） |

**方法论教训（可复用）**：

1. 只要任务是"了解/审查一个项目"，**先找并读完仓库内的规范类文档**再下结论——`附件/` 这种目录名不会出现在文件级 glob 的结果里；
2. 凡是"某文件/某文档不存在"的结论，必须用**目录级枚举**复核一次再写进报告；
3. 沙箱/本地环境造成的异常必须先隔离原因，再决定它是不是项目缺陷（本次 C3 差点误报）；
4. 代码审查的严重度分级应结合**验收基线**：同一段代码"还没写"（可接受）与"写成与基线相反"（必须改）价值完全不同，§9 的 SC01–SC13 都是后者。

## 11. 修复跟踪（Stage 0 完成后更新）

状态说明：**已修** = 本仓库已有代码改动与回归测试；**部分** = 已缩小或已定决策但实现未完成；**待做** = 按 §7 顺序归属到具体里程碑。

| 发现 | 状态 | 证据 / 归属 |
| --- | --- | --- |
| P1-1 `doctor` 谎报 | **已修** | `maintenance.doctor` + `records.inspect()`；`tests/integration/test_doctor.py`（6 例，含"损坏 state 时写入探测仍正常"这个最关键的对抗用例） |
| P1-2 `configure_host()` 表述 | **已修（文档）** | `docs/integration.md` 现明确写出"当前代码中不存在 `configure_host()`、没有 lifespan 分支与 host_capabilities 握手"；实现仍在 M2 |
| P1-3 工作单元未接线 | 待做 | M1（ADR-002） |
| P1-4 ASGI 全 501 | 待做 | M2（SC06） |
| P1-5 CLI 无异常边界 | **已修** | `cli.py` 统一错误信封 + 退出码；`tests/unit/test_cli_contract.py`（9 例，含"错误体不泄漏工作空间路径"） |
| P1-6 反序列化无容错 | 部分 | 工作空间级门禁已结构化（ADR-003 已落地部分）；记录级"版本严 + 字段宽"在 M1 |
| P1-7 会签顺序依赖 | 待做 | M6（VC12，需同时补"授权用户且不能自签"） |
| P1-8 版本硬编码 | **已修** | 新增 `src/ai_test/version.py`；`capabilities.version == ai_test.__version__` 有测试断言 |
| P1-9 指针丢失清空索引 | **已修** | `initialize()` 拒绝覆盖；`test_missing_pointer_with_existing_data_is_refused` 断言 state.json 字节不变 |
| P2-1 锁重入自锁 | **已修** | `_load_state()` 纯只读；写入路径在锁内创建 generation |
| P2-2 `list()` O(N²) | 部分 | `list()` 现只解析一次 state（有计数测试）；分块索引在 M1（ADR-001） |
| P2-3 恢复卫生 | 待做 | M1（孤儿清理、父目录 fsync、锁租约） |
| P2-4 payload revision 静默覆盖 | 待做 | M1 |
| P2-5 `asset_text` 穿越 | 待做 | M2/M7 前必须封堵（架构 §4.4:232 明确拒绝目录穿越） |
| P2-6 规则/提示词/schema 无人加载 | 待做 | M3（规则）/ M5（五类 prompt 模板） |
| P2-7 Windows 段校验 | 部分 | CI 已加 windows-latest 矩阵；`_validate_segment` 的保留名/非法字符补全在 M1 |
| P2-8 冲突错误层级 | **已修** | 错误类型上移到 `application/errors.py`，infrastructure 抛出应用层错误；新增"infrastructure 不得导入 interfaces"架构测试 |
| P3-1 Python 版本钉死 3.14 外 | **已修** | `requires-python = ">=3.12,<4"`，mypy 目标 3.12，CI 矩阵 3.12/3.13 |
| P3-2 空 `team` extra | 部分 | 保留并在 `pyproject.toml` 注明"M2 落地后填充"，避免接入方误以为可用 |
| P3-3 sdist 截断 | **已修** | 新增 `[tool.hatch.build.targets.sdist] include`（tests/docs/examples/附件/计划/审查/uv.lock） |
| P3-4 示例与 CSS | 待做 | M7 |
| P3-5 领域校验不一致 | 待做 | M1/M4（EvidenceReference/Defect 等） |
| P3-6 死代码清单 | 部分 | `InMemoryTelemetry` 已接入 `Component` 与 `doctor`；`maintenance.doctor` 已被 CLI/API/MCP 调用；其余待各自里程碑 |
| P3-7 无 logging / Clock 实现 | 待做 | M2/M4 |
| P3-8 应用层无法表达冲突 | **已修** | 同 P2-8 |
| P3-9 MCP 丢弃组件实例 | **已修** | `create_mcp_server` 保存组件并新增只读 `doctor` 工具 |
| P3-10 默认工作空间与 .gitignore | 部分 | `.gitignore` 已覆盖 `.aitest/`；默认路径调整在 M1（SC13） |
| P3-11 需求文档路径不可见 | **已修** | README 直接给出 `附件/` 两份文档链接；sdist 也纳入 |
| P3-12 测试基建限制 | 部分 | 新增 CLI/doctor/恢复/架构测试；ASGI 请求构造器限制在 M2 |
| P3-13 WriterLease 延迟 import | 待做 | M1（与租约实现一起收） |
| P3-14 依赖上界无验证 | **已修** | CI 新增每周 `latest-dependencies` 任务（`uv sync --upgrade` + pytest） |
| SC01/SC02 架构准入与索引方案 | 部分 | 决策已成文（ADR-001/002）；实现与 §13 指标在 M1（本阶段刻意未动业务模块） |
| SC03 `writer_epoch` | 部分 | 指针已写入 `writer_epoch: 0`（字段预留，避免二次改格式）；语义在 M1 |
| SC04 锁队列/诊断/心跳 | 部分 | ADR-002 定稿；实现 M1 |
| SC05 记录版本门禁 | 部分 | 工作空间级已结构化并纳入 doctor；记录级 M1 |
| SC07 健康/指标/诊断 | 部分 | `doctor` 真实化 + `writable` 真探测；`metrics()`/`diagnostics()` 与阈值告警在 M2/M8 |
| SC08–SC13 | 待做 | §9 映射表逐项归属（IdGenerator M1、路由与错误码 M2、模型名 M0/M5、状态枚举 M4/M6、保留期 M8、布局 M1–M3、`.aitest` 语义 M1） |

**本阶段验证方式**：项目自带门禁（与 CI 同一条命令链），运行环境 Python 3.14.7 / portalocker 3.2.0 / ruff 0.16.7 / mypy 2.3.1 / uv 0.12.13，工作目录 = 本仓库根目录：

| 门禁 | 命令 | 结果 |
| --- | --- | --- |
| 静态检查 | `python -m ruff check .` | **All checks passed**（0 问题；首轮 11 处告警，源码 1 处超长行 + 探针脚本 10 处，均已修） |
| 类型检查 | `python -m mypy` | **Success: no issues found in 64 source files**（strict） |
| 测试 | `python -m pytest --basetemp=.uv-tmp/pytest-base2 -p no:cacheprovider` | **39 passed**（改动前 9 条；新增 3 个测试文件 + 架构测试扩展） |
| 打包 | `python -m build` | sdist **100 条目**（tests 15、docs 8、examples 2、附件 2、uv.lock 1、README 6、审查报告与实施计划各 1）；wheel 70 条目且 `ai_test/resources/**` 齐全。改动前 sdist 69 条目、tests/docs 均 0 |
| 锁文件 | `uv lock --check` | exit 0（锁文件与 `pyproject.toml` 一致，CI 的 `uv sync --locked` 可用） |
| 探针复测 | `python review_probe.py` | E/F/G/H/J/K 六段翻转：重复创建由裸异常 → `exit 4 + STALE_REVISION`；空 id → `exit 2 + INVALID_ARGUMENT`；`doctor` 由常量 ok → 真实 `HEALTHY`，状态损坏时 `exit 5 NOT_READY`；指针丢失后 `project-get` → `exit 5 + WORKSPACE_NOT_READY` 且 `state.records` 保持 `['projects/demo']`（不再被清空）；持锁调用 `_load_state()` 由 0.50 秒锁超时 → 0.00 秒明确报错；`list()` 的 state 解析由 6 次 → 1 次；`StaleRevision` 归属层 → `ai_test.application.errors` |
| 未翻转项（有意保留） | 同上 | A 会签顺序依赖（M6）、B 未知字段 `TypeError` 与未知 schema 静默接受（M1）、C `asset_text` 穿越（M2/M7）、I payload revision 被静默覆盖（M1）—— 四项仍可复现，与本表"待做"状态一致 |

**过程留痕**：一次后台任务因未指定工作目录而在**父目录**运行，其 ruff/mypy/pytest 结果无效（扫到了同级其他项目），已作废并在正确目录重跑；它在父目录留下的 `.ruff_cache/.uv-cache/.uv-tmp/dist` 已清理。上表结果全部来自工作目录 = 本仓库根目录的运行。
