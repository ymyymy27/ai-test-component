"""M1 基准：测量当前存储实现的写入成本、读取成本与"读取文件数"。

用法（仓库根目录）::

    python tests/performance/benchmark.py                       # 默认小规模
    python tests/performance/benchmark.py --runs 2000 --label before-m1
    python tests/performance/benchmark.py --trace-nodes 100000  # 含链路段

输出：控制台表格 + ``.bench/<label>.json``（含全部原始数字，便于改动前后对比）。

口径说明（对应架构 v2.4 §13 的四项指标）：

===================  ==========================================================
指标                  本脚本如何度量
===================  ==========================================================
文件提交 p95         连续 ``put`` 的端到端耗时（含原子替换），取 p95
写队列等待            **暂不适用**：协调者队列属 M1 实现，落地后在此补测
查询读取文件数        monkeypatch ``Path.open`` 计数（页面查询与全量迭代各测一次）
空闲内存              ``tracemalloc`` 峰值（仅存储层；进程 RSS 属 M8 验收项）
===================  ==========================================================
"""

from __future__ import annotations

import argparse
import contextlib
import json
import os
import pathlib
import shutil
import sys
import tempfile
import time
import tracemalloc
from collections.abc import Iterator
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src"))

from ai_test.infrastructure.file_store.coordinator import (  # noqa: E402
    WriteCoordinator,
    WriteIntent,
)
from ai_test.infrastructure.file_store.records import FileRecordRepository  # noqa: E402
from tests.performance.fixture import (  # noqa: E402
    DatasetSpec,
    disk_usage,
    generate,
    generation_of,
    write_trace_segments,
)

STATE_SIZE_BUDGET = 4096  # ADR-001：state.json 的大小应与记录总数无关


@contextlib.contextmanager
def counting_opens() -> Iterator[dict[str, Any]]:
    """统计 ``Path.open`` 调用次数与路径（覆盖 read_text）。"""
    counter: dict[str, Any] = {"count": 0, "paths": []}
    original = pathlib.Path.open

    def wrapper(self: Path, *args: Any, **kwargs: Any) -> Any:
        counter["count"] += 1
        counter["paths"].append(self.name)
        return original(self, *args, **kwargs)

    pathlib.Path.open = wrapper  # type: ignore[method-assign]
    try:
        yield counter
    finally:
        pathlib.Path.open = original  # type: ignore[method-assign]


@contextlib.contextmanager
def counting_replaces() -> Iterator[dict[str, int]]:
    """统计原子替换次数（写放大的直接度量）。"""
    counter = {"count": 0}
    original = os.replace

    def wrapper(src: Any, dst: Any, *args: Any, **kwargs: Any) -> Any:
        counter["count"] += 1
        return original(src, dst, *args, **kwargs)

    os.replace = wrapper  # type: ignore[assignment]
    try:
        yield counter
    finally:
        os.replace = original  # type: ignore[assignment]


def percentile(values: list[float], fraction: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, int(round(fraction * (len(ordered) - 1))))
    return ordered[index]


def measure_writes(
    repository: FileRecordRepository,
    count: int,
    *,
    hold_ms: float = 50.0,
) -> dict[str, Any]:
    """经写入协调者提交，测量提交耗时与**写队列等待**（§13 指标）。

    分两段：
    1. 直接提交 ``count`` 次（本地模式：准入后立即执行），记录提交耗时与原子替换次数；
    2. 积压场景：入队到接近普通上限后等待 ``hold_ms``，再统一执行——此时测得的
       排队等待才是真实等待，用于核对"写队列等待 p95 ≤ 250ms"。
    """
    replaces: list[int] = []
    coordinator = WriteCoordinator(repository, auto_heartbeat=False)
    coordinator.open()
    try:
        for index in range(count):
            intent = WriteIntent("bench", f"bench{index:06d}", {"value": index})
            with counting_replaces() as counter:
                coordinator.submit(intent)
            replaces.append(counter["count"])
        direct = coordinator.metrics()

        backlog = coordinator.queue.capacity - coordinator.queue.terminal_slots - 5
        for index in range(backlog):
            coordinator.enqueue(WriteIntent("bench", f"backlog{index:06d}", {"value": index}))
        time.sleep(hold_ms / 1000.0)
        served = coordinator.drain()
        backlog_metrics = coordinator.metrics()
    finally:
        coordinator.close()
    return {
        "count": count,
        "replaces_per_put_max": max(replaces) if replaces else 0,
        "direct": direct,
        "backlog_queued": backlog,
        "backlog_served": served,
        "backlog": backlog_metrics,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="M1 存储基准")
    parser.add_argument("--projects", type=int, default=1)
    parser.add_argument("--tasks", type=int, default=200)
    parser.add_argument("--cases", type=int, default=200)
    parser.add_argument("--runs", type=int, default=400)
    parser.add_argument("--attempts", type=int, default=3)
    parser.add_argument("--trace-nodes", type=int, default=0)
    parser.add_argument("--puts", type=int, default=300, help="写延迟测量样本数")
    parser.add_argument("--workspace", type=Path, default=None)
    parser.add_argument("--label", default="current")
    args = parser.parse_args()

    spec = DatasetSpec(
        projects=args.projects,
        tasks=args.tasks,
        cases=args.cases,
        runs=args.runs,
        attempts_per_run=args.attempts,
        trace_nodes=args.trace_nodes,
    )
    workspace = args.workspace or Path(
        tempfile.mkdtemp(prefix="aitest-bench-", dir=ROOT / ".bench")
    )
    if workspace.exists():
        shutil.rmtree(workspace)
    workspace.mkdir(parents=True, exist_ok=True)

    repository = FileRecordRepository(workspace)
    repository.initialize()

    tracemalloc.start()
    started = time.perf_counter()
    counts = generate(repository, spec)
    generate_seconds = time.perf_counter() - started
    segments = write_trace_segments(repository, spec.trace_nodes)
    generation = generation_of(repository)
    state_file = repository.generations / generation / "state.json"
    state_bytes = state_file.stat().st_size

    writes = measure_writes(repository, args.puts)

    with counting_opens() as page_opens:
        started = time.perf_counter()
        page = repository.index_page("runs", limit=200)
        page_seconds = time.perf_counter() - started

    with counting_opens() as scan_opens:
        started = time.perf_counter()
        scanned = sum(1 for _ in repository.list("attempts"))
        scan_seconds = time.perf_counter() - started

    gets: list[float] = []
    with counting_opens() as get_opens:
        for index in range(min(200, spec.runs)):
            started = time.perf_counter()
            repository.get("runs", f"r{index:06d}")
            gets.append((time.perf_counter() - started) * 1000)

    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()

    result: dict[str, Any] = {
        "label": args.label,
        "workspace": str(workspace),
        "spec": spec.as_dict(),
        "generated": counts,
        "trace_segments": segments,
        "generate_seconds": round(generate_seconds, 3),
        "state_json_bytes": state_bytes,
        "state_json_bytes_budget": STATE_SIZE_BUDGET,
        "state_json_bytes_over_budget": state_bytes > STATE_SIZE_BUDGET,
        "put": writes,
        "index_page": {
            "kind": "runs",
            "items": len(page.items),
            "seconds": round(page_seconds, 3),
            "files_opened": page_opens["count"],
        },
        "list_attempts_all": {
            "records": scanned,
            "seconds": round(scan_seconds, 3),
            "files_opened": scan_opens["count"],
        },        "get": {
            "samples": len(gets),
            "ms_p95": round(percentile(gets, 0.95), 3),
            "files_opened": get_opens["count"],
        },
        "tracemalloc": {
            "current_mb": round(current / 1024 / 1024, 3),
            "peak_mb": round(peak / 1024 / 1024, 3),
        },
        "disk": disk_usage(workspace),
    }

    results_dir = ROOT / ".bench"
    results_dir.mkdir(exist_ok=True)
    (results_dir / f"{args.label}.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    over_budget = "超预算" if result["state_json_bytes_over_budget"] else "在预算内"
    page_ms = page_seconds * 1000
    scan_ms = scan_seconds * 1000
    direct = writes["direct"]
    backlog = writes["backlog"]
    commit_stats = direct["commit_ms"]
    wait_stats = backlog["queue_wait_ms"]
    print(f"\n=== M1 基准 · {args.label} ===")
    print(f"数据集      : {spec.as_dict()}")
    print(f"记录数      : {sum(counts.values())} 条")
    print(f"链路段      : {segments['segments']} 段 / {segments['nodes']} 节点")
    print(f"生成耗时    : {generate_seconds:.2f}s")
    print(f"state.json  : {state_bytes} 字节（预算 {STATE_SIZE_BUDGET}，{over_budget}）")
    print(f"提交 p50/p95: {commit_stats['p50']} / {commit_stats['p95']} ms（n={writes['count']}）")
    print(f"原子替换    : 每次提交最多 {writes['replaces_per_put_max']} 次")
    print(f"队列等待p95 : {wait_stats['p95']} ms（积压 {writes['backlog_queued']} 条）")
    print(f"index_page  : {len(page.items)} 条 / {page_ms:.1f}ms / 读文件 {page_opens['count']}")
    print(f"list(全部)  : {scanned} 条 / {scan_ms:.1f}ms / 读文件 {scan_opens['count']}")
    print(f"get         : p95={result['get']['ms_p95']}ms / 读文件 {get_opens['count']}")
    print(f"内存峰值    : {result['tracemalloc']['peak_mb']}MB（tracemalloc，仅存储层）")
    print(f"磁盘        : {result['disk']['files']} 文件 / {result['disk']['bytes'] / 1024:.0f} KB")
    print(f"结果写入    : .bench/{args.label}.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
