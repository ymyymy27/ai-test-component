"""M1 性能夹具：按架构 v2.4 §13 的固定数据集形状生成一个工作空间（T2 的最小版）。

设计约束：

* 记录一律走**公开 API**（``FileRecordRepository.put``），因此夹具在 M1 前后都能用，
  改动实现不需要改夹具；
* 链路节点按 ADR-001 的段格式直接写 JSONL（每段 ≤ ``segment_lines`` 行），
  因为 100 万节点不可能一个节点一个文件；M1 落地段写入器后由实现接管这一层；
* 夹具只负责"造数据"，不做任何断言 —— 断言属于基准脚本与不变量测试。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ai_test.infrastructure.file_store.records import FileRecordRepository
from ai_test.infrastructure.file_store.segments import SegmentedLog

#: §13 的固定数据集（全量基准用；单元测试与 CI 用不到）
FULL_SCALE = {
    "tasks": 1_000,
    "cases": 1_000,
    "runs": 10_000,
    "attempts_per_run": 10,
    "trace_nodes": 1_000_000,
}


@dataclass(frozen=True, slots=True)
class DatasetSpec:
    """一次夹具运行的规模。默认值是"秒级"的小规模，适合本地反复跑。"""

    projects: int = 1
    tasks: int = 200
    cases: int = 200
    runs: int = 400
    attempts_per_run: int = 3
    trace_nodes: int = 0
    segment_lines: int = 10_000

    @property
    def record_count(self) -> int:
        return self.projects + self.tasks + self.cases + self.runs + (
            self.runs * self.attempts_per_run
        )

    def as_dict(self) -> dict[str, int]:
        return {
            "projects": self.projects,
            "tasks": self.tasks,
            "cases": self.cases,
            "runs": self.runs,
            "attempts_per_run": self.attempts_per_run,
            "trace_nodes": self.trace_nodes,
            "segment_lines": self.segment_lines,
            "record_count": self.record_count,
        }


def generation_of(repository: FileRecordRepository) -> str:
    """当前 generation 名（未初始化时返回初始 generation 名）。"""
    if repository.current_file.exists():
        pointer = json.loads(repository.current_file.read_text(encoding="utf-8"))
        return str(pointer["generation"])
    return repository.INITIAL_GENERATION


def generate(repository: FileRecordRepository, spec: DatasetSpec) -> dict[str, int]:
    """写入记录集合，返回各类型的实际数量。"""
    counts: dict[str, int] = {}
    for index in range(spec.projects):
        repository.put("projects", f"p{index:06d}", _project(index))
    counts["projects"] = spec.projects

    for index in range(spec.tasks):
        repository.put("tasks", f"t{index:06d}", _task(index))
    counts["tasks"] = spec.tasks

    for index in range(spec.cases):
        repository.put("cases", f"c{index:06d}", _case(index))
    counts["cases"] = spec.cases

    attempts = 0
    for index in range(spec.runs):
        repository.put("runs", f"r{index:06d}", _run(index))
        for attempt in range(spec.attempts_per_run):
            repository.put("attempts", f"r{index:06d}-a{attempt:03d}", _attempt(index, attempt))
            attempts += 1
    counts["runs"] = spec.runs
    counts["attempts"] = attempts
    return counts


def write_trace_segments(
    repository: FileRecordRepository,
    nodes: int,
    *,
    lines_per_segment: int = 10_000,
) -> dict[str, int]:
    """用真实的段式写入器写链路节点（ADR-001 §3），返回段数与总行数。"""
    if nodes <= 0:
        return {"segments": 0, "nodes": 0}
    log = SegmentedLog(
        repository.generations / generation_of(repository),
        "traces",
        segment_lines=lines_per_segment,
    )
    result = log.append(
        {
            "node": f"n{index:09d}",
            "parent": None if index == 0 else index - 1,
            "status": "OK" if index % 17 else "FAILED",
        }
        for index in range(nodes)
    )
    return {"segments": int(result["segments"]), "nodes": int(result["appended"])}


def disk_usage(workspace: Path) -> dict[str, int]:
    """工作空间的物理规模：文件数、字节数、以及按目录分类的计数。"""
    files = [path for path in workspace.rglob("*") if path.is_file()]
    by_directory: dict[str, int] = {}
    for path in files:
        top = path.relative_to(workspace).parts[0]
        by_directory[top] = by_directory.get(top, 0) + 1
    return {
        "files": len(files),
        "bytes": sum(path.stat().st_size for path in files),
        "files_by_top_directory": by_directory,  # type: ignore[dict-item]
    }


def _project(index: int) -> dict[str, Any]:
    return {"project_id": f"p{index:06d}", "name": f"项目 {index}", "modules": []}


def _task(index: int) -> dict[str, Any]:
    return {"task_id": f"t{index:06d}", "title": f"任务 {index}", "acceptance_items": 3}


def _case(index: int) -> dict[str, Any]:
    return {"case_id": f"c{index:06d}", "layer": "module", "mock_allowed": index % 5 == 0}


def _run(index: int) -> dict[str, Any]:
    return {"run_id": f"r{index:06d}", "case_id": f"c{index:06d}", "status": "COMPLETED"}


def _attempt(run_index: int, attempt: int) -> dict[str, Any]:
    return {
        "attempt_id": f"r{run_index:06d}-a{attempt:03d}",
        "run_id": f"r{run_index:06d}",
        "status": "PASSED" if attempt % 3 else "FAILED",
    }
