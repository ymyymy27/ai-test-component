# 性能与规模测试（架构 v2.4 §13）

M1 的出口判据在此目录，分两部分。

## 1. 基准脚本（测数字，不做断言）

```bash
python tests/performance/benchmark.py                          # 默认小规模，秒级
python tests/performance/benchmark.py --runs 2000 --label before-m1
python tests/performance/benchmark.py --trace-nodes 1000000 --label full-scale
```

输出：控制台表格 + `.bench/<label>.json`（全部原始数字，便于改动前后对比）。度量口径见脚本头部注释：
文件提交 p95、查询读取文件数、`state.json` 大小、tracemalloc 峰值；**写队列等待**要等 M1 的协调者落地后补测。

规模参考（架构 §13 的固定数据集）：1,000 任务 / 1,000 用例 / 10,000 运行 / 100,000 尝试 / 1,000,000 链路节点 / 50 GiB 证据。
夹具提供 `FULL_SCALE` 常量与该形状；50 GiB 证据属 M1b/M8 的独立验收项，不在本目录生成。

## 2. 不变量测试（M1 出口判据，默认跳过）

```bash
AITEST_PERF=1 python -m pytest tests/performance/test_index_invariants.py -v
```

这些用例描述的是 **M1 完成后的行为**，因此默认跳过（CI 保持绿色）。它们对应：

| 用例 | 出处 | M1 开工前 | 第③片后 |
| --- | --- | --- | --- |
| `state.json` 大小与记录总数无关 | ADR-001 不变量 1 | 红 | **绿** |
| 页面查询读取文件数恒定 | ADR-001 不变量 3 | 红 | **绿** |
| 一次提交只重写 1 个索引块 | ADR-001 不变量 2 | 红 | **绿** |
| 单次提交成本不随总量增长 | ADR-002 补充 | 绿 | 绿 |
| 全量迭代只解析一次 state.json | ADR-001 不变量 3 回归项 | 绿 | 绿 |
| 第二写者返回 `WORKSPACE_IN_USE` 且带脱敏诊断 | ADR-002 不变量 1 | 红 | **绿** |

M1 的验收方式：这条命令 **6 条全绿**，且 `benchmark.py` 的数字满足 §13 阈值。
基准脚本现在也测量**写队列等待**：队列元素自带受理时刻，因此"排队多久"是实测值而非估算。
1001 条记录规模下：提交 p95 = 22.9 ms、页面查询 2.1 ms / 3 个文件、`get` p95 = 1.8 ms；
**稳态队列等待纯排队 0.008 ms**（端到端 22.9 ms），**饱和（人为积压 85 条）587 ms** ——
批量提交（工作单元）已把饱和值从 1399 ms 降下来；§13 的 250 ms 口径与饱和保护见
`docs/adr/ADR-002-write-coordinator-and-writer-epoch.md` 的"未达标项的处置"。

## 3. 单元/集成层

日常回归不依赖本目录：功能正确性由 `tests/unit/`、`tests/integration/`、`tests/architecture/` 覆盖；
本目录只回答"规模上是否撑得住"。
