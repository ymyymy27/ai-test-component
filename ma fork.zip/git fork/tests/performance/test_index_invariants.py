"""M1 出口判据（可执行）：ADR-001 / ADR-002 的不变量。

这些用例**默认跳过**，因为它们描述的是 M1 完成后的行为；用环境变量显式开启：

    AITEST_PERF=1 python -m pytest tests/performance/test_index_invariants.py -v

M1 的验收方式就是这条命令由红转绿。第一次运行（M1 开工前）应当是**全红**——
如果它们本来是绿的，说明判据是空的、约束不到任何东西。
"""

from __future__ import annotations

import json
import os
import pathlib
from typing import Any

import pytest

from ai_test.application.errors import WorkspaceInUse
from ai_test.infrastructure.file_store.coordinator import WriteCoordinator
from ai_test.infrastructure.file_store.records import FileRecordRepository

pytestmark = pytest.mark.skipif(
    os.environ.get("AITEST_PERF") != "1",
    reason="M1 出口判据：设置 AITEST_PERF=1 运行（CI 默认不跑）",
)

#: ADR-001：state.json 只保存"当前修订 + 分块入口 + 额度"，大小与记录总数无关
STATE_SIZE_BUDGET = 4096
#: ADR-001：一页查询（≤200 条）允许读取的文件数上界（指针 + 入口 + 1 个块 + 余量）
PAGE_FILE_BUDGET = 4


def _fill(repository: FileRecordRepository, kind: str, count: int) -> None:
    for index in range(count):
        repository.put(kind, f"{kind}{index:06d}", {"kind": kind, "index": index})


def _state_file(repository: FileRecordRepository) -> pathlib.Path:
    pointer = json.loads(repository.current_file.read_text(encoding="utf-8"))
    return repository.generations / str(pointer["generation"]) / "state.json"


class _OpenCounter:
    """统计一次操作里 ``Path.open`` 的次数与文件名。"""

    def __enter__(self) -> _OpenCounter:
        self.count = 0
        self.names: list[str] = []
        self._original = pathlib.Path.open

        def wrapper(inner_self: pathlib.Path, *args: Any, **kwargs: Any) -> Any:
            self.count += 1
            self.names.append(inner_self.name)
            return self._original(inner_self, *args, **kwargs)

        pathlib.Path.open = wrapper  # type: ignore[method-assign]
        return self

    def __exit__(self, *exc: object) -> None:
        pathlib.Path.open = self._original  # type: ignore[method-assign]


def test_state_json_size_is_independent_of_record_count(tmp_path) -> None:
    """ADR-001 不变量 1：记录从 200 增到 1000，state.json 不得线性增长。"""
    repository = FileRecordRepository(tmp_path / "workspace")
    _fill(repository, "tasks", 200)
    small = _state_file(repository).stat().st_size
    _fill(repository, "tasks", 800)
    large = _state_file(repository).stat().st_size

    assert large <= STATE_SIZE_BUDGET, (
        f"state.json 随记录数增长：200 条 = {small} 字节，1000 条 = {large} 字节"
    )
    # 只允许因修订号位数增加带来的极小增长，不允许随记录数增长
    assert large - small <= 64, f"state.json 增长 {large - small} 字节（应仅随位数微增）"


def test_page_query_reads_a_constant_number_of_files(tmp_path) -> None:
    """ADR-001 不变量 3：页面查询读取文件数与记录总数无关。"""
    opened: list[int] = []
    for size in (200, 2000):
        repository = FileRecordRepository(tmp_path / f"ws{size}")
        _fill(repository, "runs", size)
        with _OpenCounter() as counter:
            page = repository.index_page("runs", limit=200)
        assert len(page.items) == 200
        opened.append(counter.count)

    assert opened[0] <= PAGE_FILE_BUDGET, (
        f"取一页打开了 {opened[0]} 个文件（预算 {PAGE_FILE_BUDGET}）"
    )
    assert opened[0] == opened[1], (
        f"读取文件数随总量变化：200 条时 {opened[0]} 个、2000 条时 {opened[1]} 个"
    )


def test_put_rewrites_exactly_one_index_block(tmp_path) -> None:
    """ADR-001 不变量 2：一次提交只重写 1 个索引块（外加不可变记录与 state 入口）。"""
    repository = FileRecordRepository(tmp_path / "workspace")
    _fill(repository, "tasks", 300)

    pointer = json.loads(repository.current_file.read_text(encoding="utf-8"))
    blocks_dir = repository.generations / str(pointer["generation"]) / "blocks"
    assert blocks_dir.is_dir(), "ADR-001 要求分块索引位于 <generation>/blocks/"

    before = {path: path.stat().st_mtime_ns for path in blocks_dir.rglob("*.json")}
    repository.put("tasks", "tasks999999", {"kind": "tasks", "index": 999999})
    after = {path: path.stat().st_mtime_ns for path in blocks_dir.rglob("*.json")}

    changed = [path.name for path, stamp in after.items() if before.get(path) != stamp]
    created = [path.name for path in after if path not in before]
    assert len(changed) + len(created) == 1, f"重写了 {changed + created} 个索引块（应为 1 个）"


def test_put_cost_does_not_grow_with_record_count(tmp_path) -> None:
    """ADR-002 补充：单次提交的原子替换次数与工作空间总量无关。"""
    repository = FileRecordRepository(tmp_path / "workspace")
    _fill(repository, "tasks", 100)
    small = _replaces_for_one_put(repository, "tasks", "tasks-after-small")
    _fill(repository, "tasks", 900)
    large = _replaces_for_one_put(repository, "tasks", "tasks-after-large")

    assert small == large, f"提交成本随总量增长：100 条时 {small} 次、1000 条时 {large} 次"


def test_full_scan_parses_the_index_once(tmp_path) -> None:
    """ADR-001 不变量 3 的回归项：全量迭代过程中 state.json 只被解析一次。"""
    repository = FileRecordRepository(tmp_path / "workspace")
    _fill(repository, "attempts", 300)

    with _OpenCounter() as counter:
        scanned = sum(1 for _ in repository.list("attempts"))

    assert scanned == 300
    assert counter.names.count("state.json") == 1, (
        f"state.json 被解析 {counter.names.count('state.json')} 次（应为 1 次）"
    )


def test_second_writer_reports_workspace_in_use(tmp_path) -> None:
    """ADR-002 不变量 1：第二写进程取不到租约时返回 WORKSPACE_IN_USE（而非裸锁异常）。"""
    workspace = tmp_path / "workspace"
    holder = WriteCoordinator(
        FileRecordRepository(workspace, lock_timeout_seconds=0.2), auto_heartbeat=False
    )
    holder.open()
    try:
        intruder = FileRecordRepository(workspace, lock_timeout_seconds=0.2)
        with pytest.raises(WorkspaceInUse) as error:
            intruder.put("tasks", "t1", {"kind": "tasks"})

        assert error.value.code == "WORKSPACE_IN_USE"
        assert error.value.retryable is True
        diagnostics = error.value.details.get("holder")
        assert isinstance(diagnostics, dict), "应带脱敏持有者诊断"
        assert diagnostics["writer_epoch"] == holder.epoch
        assert "pid" in diagnostics and "acquired_at" in diagnostics
        assert str(workspace) not in json.dumps(error.value.details)
    finally:
        holder.close()


def _replaces_for_one_put(repository: FileRecordRepository, kind: str, record_id: str) -> int:
    calls = {"count": 0}
    original = os.replace

    def wrapper(src: Any, dst: Any, *args: Any, **kwargs: Any) -> Any:
        calls["count"] += 1
        return original(src, dst, *args, **kwargs)

    os.replace = wrapper  # type: ignore[assignment]
    try:
        repository.put(kind, record_id, {"kind": kind})
    finally:
        os.replace = original  # type: ignore[assignment]
    return calls["count"]
