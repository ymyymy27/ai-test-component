"""Doctor must report real health (review finding P1-1)."""

import json

from ai_test.application.ports.system import DEGRADED, HEALTHY, NOT_READY
from ai_test.application.use_cases.maintenance import doctor
from ai_test.infrastructure.file_store.records import FileRecordRepository


def _status(report: dict) -> str:
    return str(report["status"])


def _check(report: dict, name: str) -> dict:
    return next(item for item in report["checks"] if item["name"] == name)


def test_healthy_workspace_is_reported_as_ready(tmp_path) -> None:
    repository = FileRecordRepository(tmp_path / "workspace")
    repository.put("projects", "demo", {"name": "演示项目"})

    report = doctor(repository)

    assert _status(report) == HEALTHY
    assert report["writable"] is True
    assert _check(report, "pointer")["status"] == HEALTHY
    assert _check(report, "state")["status"] == HEALTHY


def test_missing_workspace_is_not_ready(tmp_path) -> None:
    report = doctor(FileRecordRepository(tmp_path / "absent"))

    assert _status(report) == NOT_READY
    assert report["writable"] is False


def test_corrupted_state_is_reported_as_not_ready(tmp_path) -> None:
    """The old doctor printed {"status": "ok", "writable": true} here."""
    workspace = tmp_path / "workspace"
    repository = FileRecordRepository(workspace)
    repository.put("projects", "demo", {"name": "演示项目"})
    state_file = workspace / "generations" / "gen-000001" / "state.json"
    state = json.loads(state_file.read_text(encoding="utf-8"))
    state["schema_version"] = "aatp.workspace-state/0.0-broken"
    state_file.write_text(json.dumps(state), encoding="utf-8")

    report = doctor(repository)

    assert _status(report) == NOT_READY
    assert _check(report, "state")["status"] == NOT_READY
    # The write probe still succeeds, so "writable" alone would have looked fine.
    assert _check(report, "writable")["status"] == HEALTHY


def test_missing_pointer_is_reported_as_not_ready(tmp_path) -> None:
    workspace = tmp_path / "workspace"
    repository = FileRecordRepository(workspace)
    repository.put("projects", "demo", {"name": "演示项目"})
    (workspace / "current.json").unlink()

    report = doctor(repository)

    assert _status(report) == NOT_READY
    assert _check(report, "pointer")["status"] == NOT_READY


def test_dangling_record_reference_is_not_ready(tmp_path) -> None:
    workspace = tmp_path / "workspace"
    repository = FileRecordRepository(workspace)
    repository.put("projects", "demo", {"name": "演示项目"})
    record = workspace / "generations" / "gen-000001" / "records" / "projects" / "demo"
    next(record.glob("r*.json")).unlink()

    report = doctor(repository)

    assert _status(report) == NOT_READY
    # 引用完整性归 index 检查；state 只报告修订与 kind 数量
    assert "missing on disk" in _check(report, "index")["detail"]


def test_index_check_reports_kinds_and_entries(tmp_path) -> None:
    repository = FileRecordRepository(tmp_path / "workspace")
    repository.put("projects", "demo", {"name": "演示项目"})
    repository.put("tasks", "t1", {"title": "任务"})

    report = doctor(repository)

    detail = _check(report, "index")["detail"]
    assert "kinds=2" in detail
    assert "entries=2" in detail


def test_incomplete_layout_is_degraded(tmp_path) -> None:
    workspace = tmp_path / "workspace"
    repository = FileRecordRepository(workspace)
    repository.put("projects", "demo", {"name": "演示项目"})
    (workspace / "objects" / "sha256").rmdir()

    report = doctor(repository)

    assert _status(report) == DEGRADED
    assert _check(report, "layout")["status"] == DEGRADED


def test_doctor_never_mutates_the_workspace(tmp_path) -> None:
    workspace = tmp_path / "workspace"
    repository = FileRecordRepository(workspace)
    repository.put("projects", "demo", {"name": "演示项目"})
    before = sorted(path.relative_to(workspace).as_posix() for path in workspace.rglob("*"))

    doctor(repository)

    after = sorted(path.relative_to(workspace).as_posix() for path in workspace.rglob("*"))
    assert before == after
