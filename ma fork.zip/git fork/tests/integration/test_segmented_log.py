"""限长段式日志（ADR-001 §3）行为测试。"""

import json

import pytest

from ai_test.infrastructure.file_store.segments import STREAM_INDEX_SCHEMA, SegmentedLog
from tests.support import OpenCounter


def _log(tmp_path, **kwargs) -> SegmentedLog:
    return SegmentedLog(tmp_path / "generations" / "gen-000001", "traces", **kwargs)


def _nodes(count: int) -> list[dict]:
    return [{"node": f"n{index:05d}"} for index in range(count)]


def test_segments_seal_and_ids_are_monotonic(tmp_path) -> None:
    log = _log(tmp_path, segment_lines=10)

    result = log.append(_nodes(25))

    assert result["appended"] == 25
    assert result["last_id"] == 24
    assert result["segments"] == 3
    segments = log.segments()
    assert [segment["lines"] for segment in segments] == [10, 10, 5]
    assert [(s["first_id"], s["last_id"]) for s in segments] == [(0, 9), (10, 19), (20, 24)]
    assert [s["sealed"] for s in segments] == [True, True, False]
    assert log.stats()["lines"] == 25


def test_index_file_declares_schema_and_segment_metadata(tmp_path) -> None:
    log = _log(tmp_path, segment_lines=10)
    log.append(_nodes(12))

    index = json.loads((log.directory / "index.json").read_text(encoding="utf-8"))
    assert index["schema_version"] == STREAM_INDEX_SCHEMA
    assert index["kind"] == "traces"
    assert index["next_id"] == 12
    assert index["segments"][0]["file"] == "seg-000001.jsonl"
    assert index["segments"][0]["bytes"] > 0


def test_append_continues_after_reopen(tmp_path) -> None:
    _log(tmp_path, segment_lines=10).append(_nodes(12))
    reopened = _log(tmp_path, segment_lines=10)

    reopened.append(_nodes(3))

    assert reopened.stats()["next_id"] == 15
    assert [entry["event_id"] for entry in reopened.read(after_id=11, limit=10)] == [12, 13, 14]


def test_read_page_opens_bounded_files(tmp_path) -> None:
    log = _log(tmp_path, segment_lines=10)
    log.append(_nodes(100))

    with OpenCounter() as counter:
        page = log.read(after_id=44, limit=5)

    assert [entry["event_id"] for entry in page] == [45, 46, 47, 48, 49]
    assert counter.count <= 2, f"读取一页打开了 {counter.count} 个文件（应为索引 + 1 段）"


def test_read_across_segment_boundary(tmp_path) -> None:
    log = _log(tmp_path, segment_lines=10)
    log.append(_nodes(25))

    page = log.read(after_id=7, limit=6)

    assert [entry["event_id"] for entry in page] == [8, 9, 10, 11, 12, 13]
    assert all("node" in entry for entry in page)


def test_read_at_the_end_returns_empty(tmp_path) -> None:
    log = _log(tmp_path, segment_lines=10)
    log.append(_nodes(5))

    assert log.read(after_id=4, limit=10) == ()
    assert log.read(after_id=999, limit=10) == ()


def test_byte_limit_seals_a_segment(tmp_path) -> None:
    log = _log(tmp_path, segment_lines=10_000, segment_bytes=256)

    log.append([{"blob": "x" * 100} for _ in range(6)])

    segments = log.segments()
    assert len(segments) >= 3, "达到字节上限应封段"
    assert all(segment["bytes"] <= 1024 for segment in segments[:-1])


def test_unknown_index_schema_is_rejected(tmp_path) -> None:
    log = _log(tmp_path)
    log.append(_nodes(1))
    index_file = log.directory / "index.json"
    index = json.loads(index_file.read_text(encoding="utf-8"))
    index["schema_version"] = "aatp.stream-index/0.0"
    index_file.write_text(json.dumps(index), encoding="utf-8")

    with pytest.raises(ValueError):
        log.read(after_id=-1, limit=1)
