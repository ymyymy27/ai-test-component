"""工作单元（批量提交）行为测试：ADR-002 §4 的事务边界 + ADR-001 不变量 2。"""

import json
import os
from typing import Any

import pytest

from ai_test.application.errors import StaleRevision, WorkspaceNotReady
from ai_test.infrastructure.file_store.records import FileRecordRepository


def _repository(tmp_path, *, block_size: int = 200) -> FileRecordRepository:
    return FileRecordRepository(tmp_path / "workspace", block_size=block_size)


def _state(repository: FileRecordRepository) -> dict[str, Any]:
    pointer = json.loads(repository.current_file.read_text(encoding="utf-8"))
    path = repository.generations / str(pointer["generation"]) / "state.json"
    return json.loads(path.read_text(encoding="utf-8"))


def _replace_count(during: Any) -> int:
    calls = {"count": 0}
    original = os.replace

    def wrapper(src: Any, dst: Any, *args: Any, **kwargs: Any) -> Any:
        calls["count"] += 1
        return original(src, dst, *args, **kwargs)

    os.replace = wrapper  # type: ignore[assignment]
    try:
        during()
    finally:
        os.replace = original  # type: ignore[assignment]
    return calls["count"]


def test_batch_commit_writes_state_once(tmp_path) -> None:
    """N 条记录只写一次 state：5 条同 kind = 5 记录 + 1 块 + 1 state。"""
    repository = _repository(tmp_path)
    repository.initialize()  # 先建好工作空间，计数只反映本次提交

    def commit() -> None:
        with repository.unit_of_work() as unit:
            for index in range(5):
                unit.put("tasks", f"t{index}", {"value": index})
            assert unit.pending == 5
            assert unit.flush() == [1, 1, 1, 1, 1]

    assert _replace_count(commit) == 7
    assert _state(repository)["revision"] == 5


def test_individual_puts_write_state_per_record(tmp_path) -> None:
    """对照：逐条 put = 5 条 × 3 次替换，说明批量提交省下的是提交次数。"""
    repository = _repository(tmp_path)
    repository.initialize()

    def commit() -> None:
        for index in range(5):
            repository.put("tasks", f"t{index}", {"value": index})

    assert _replace_count(commit) == 15


def test_staged_records_are_visible_after_flush(tmp_path) -> None:
    repository = _repository(tmp_path)
    with repository.unit_of_work() as unit:
        unit.put("tasks", "t1", {"value": 1})
        unit.put("tasks", "t2", {"value": 2})
        unit.flush()

    assert repository.get("tasks", "t1") == {"value": 1, "revision": 1}
    assert repository.get("tasks", "t2") == {"value": 2, "revision": 1}
    assert len(list(repository.list("tasks"))) == 2


def test_discarding_a_unit_writes_nothing(tmp_path) -> None:
    repository = _repository(tmp_path)
    repository.put("tasks", "existing", {"value": 0})
    before = sorted(path.name for path in repository.workspace.rglob("*") if path.is_file())

    with repository.unit_of_work() as unit:
        unit.put("tasks", "t1", {"value": 1})
        unit.put("tasks", "t2", {"value": 2})
        # 不调用 flush：单位工作等于放弃

    after = sorted(path.name for path in repository.workspace.rglob("*") if path.is_file())
    assert before == after
    assert repository.get("tasks", "t1") is None


def test_conflict_aborts_before_writing_anything(tmp_path) -> None:
    repository = _repository(tmp_path)
    repository.put("tasks", "t1", {"value": 1})

    with pytest.raises(StaleRevision) as error, repository.unit_of_work() as unit:
        unit.put("tasks", "t2", {"value": 2})
        unit.put("tasks", "t1", {"value": 9}, expected_revision=99)
    assert error.value.details["actual_revision"] == 1

    assert repository.get("tasks", "t2") is None
    assert _state(repository)["revision"] == 1


def test_epoch_mismatch_is_refused_at_flush(tmp_path) -> None:
    repository = _repository(tmp_path)
    repository.put("tasks", "seed", {"value": 0})
    repository.set_writer_epoch(3)

    unit = repository.unit_of_work(lease_held=False, epoch=3).__enter__()
    unit.put("tasks", "t1", {"value": 1})
    repository.set_writer_epoch(4)  # 模拟被他人接管

    with pytest.raises(StaleRevision) as error:
        unit.flush()
    assert error.value.details["reason"] == "OLD_WRITER_EPOCH"
    assert repository.get("tasks", "t1") is None


def test_same_key_twice_in_one_batch_gets_sequential_revisions(tmp_path) -> None:
    repository = _repository(tmp_path)
    with repository.unit_of_work() as unit:
        assert unit.put("tasks", "t1", {"value": 1}) == 1
        assert unit.put("tasks", "t1", {"value": 2}) == 2
        unit.flush()

    assert repository.get("tasks", "t1") == {"value": 2, "revision": 2}
    assert len(list(repository.list("tasks"))) == 1


def test_block_seals_within_a_batch(tmp_path) -> None:
    repository = _repository(tmp_path, block_size=3)
    with repository.unit_of_work() as unit:
        for index in range(7):
            unit.put("tasks", f"t{index}", {"value": index})
        unit.flush()

    state = _state(repository)
    assert state["blocks"]["tasks"]["count"] == 1
    pointer = json.loads(repository.current_file.read_text(encoding="utf-8"))
    blocks = repository.generations / str(pointer["generation"]) / "blocks" / "tasks"
    assert sorted(path.name for path in blocks.iterdir()) == [
        "000001.json",
        "000002.json",
        "000003.json",
    ]
    assert len(list(repository.list("tasks"))) == 7


def test_flush_is_not_repeatable(tmp_path) -> None:
    repository = _repository(tmp_path)
    with repository.unit_of_work() as unit:
        unit.put("tasks", "t1", {"value": 1})
        unit.flush()
        with pytest.raises(WorkspaceNotReady) as error:
            unit.flush()
    assert error.value.details["reason"] == "UNIT_CLOSED"


def test_unit_works_on_lease_held_by_caller(tmp_path) -> None:
    """协调者场景：调用方已持锁时不应重复加锁。"""
    repository = _repository(tmp_path, block_size=3)
    with repository._lease.acquire(), repository.unit_of_work(lease_held=True) as unit:  # noqa: SLF001
        unit.put("tasks", "t1", {"value": 1})
        unit.flush()

    assert repository.get("tasks", "t1") == {"value": 1, "revision": 1}
