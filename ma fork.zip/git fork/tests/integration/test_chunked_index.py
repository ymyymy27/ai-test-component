"""分块索引的行为测试（ADR-001 实现）。性能口径的判据在 tests/performance/。"""

import json
from pathlib import Path

import pytest

from ai_test.application.errors import WorkspaceNotReady
from ai_test.infrastructure.file_store.records import FileRecordRepository


def _repo(tmp_path: Path, block_size: int = 5) -> FileRecordRepository:
    return FileRecordRepository(tmp_path / "workspace", block_size=block_size)


def _fill(repository: FileRecordRepository, kind: str, count: int) -> None:
    for index in range(count):
        repository.put(kind, f"{kind}{index:04d}", {"kind": kind, "index": index})


def _state_path(repository: FileRecordRepository) -> Path:
    pointer = json.loads(repository.current_file.read_text(encoding="utf-8"))
    return repository.generations / str(pointer["generation"]) / "state.json"


def _blocks(repository: FileRecordRepository) -> list[Path]:
    return sorted(_state_path(repository).parent.joinpath("blocks").rglob("*.json"))


def _load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def test_blocks_seal_at_block_size(tmp_path) -> None:
    repository = _repo(tmp_path, block_size=5)
    _fill(repository, "tasks", 12)

    blocks = _blocks(repository)
    assert [len(_load(path)["entries"]) for path in blocks] == [5, 5, 2]
    assert [_load(path)["next"] for path in blocks] == [
        None,
        "blocks/tasks/000001.json",
        "blocks/tasks/000002.json",
    ]


def test_state_json_holds_only_block_entries(tmp_path) -> None:
    repository = _repo(tmp_path, block_size=10)
    _fill(repository, "tasks", 100)

    state_path = _state_path(repository)
    state = _load(state_path)
    assert state["schema_version"] == FileRecordRepository.STATE_SCHEMA
    assert list(state["blocks"]) == ["tasks"]
    assert set(state["blocks"]["tasks"]) == {"file", "count", "next"}
    assert state_path.stat().st_size < 1024, "state.json 不应内嵌任何记录摘要"


def test_page_pagination_walks_the_block_chain(tmp_path) -> None:
    repository = _repo(tmp_path, block_size=5)
    _fill(repository, "tasks", 12)

    first = repository.index_page("tasks", limit=7)
    assert len(first.items) == 7
    assert first.next_cursor is not None

    second = repository.index_page("tasks", limit=7, cursor=first.next_cursor)
    assert len(second.items) == 5
    assert second.next_cursor is None

    keys = [item.key for item in (*first.items, *second.items)]
    assert len(set(keys)) == 12
    assert all(item.path.startswith("generations/") for item in first.items)


def test_updated_record_has_one_visible_entry_with_newest_revision(tmp_path) -> None:
    repository = _repo(tmp_path, block_size=2)
    repository.put("tasks", "t1", {"value": 1})
    repository.put("tasks", "t2", {"value": 1})
    repository.put("tasks", "t1", {"value": 2})  # 更新：新条目落在新块

    page = repository.index_page("tasks", limit=10)
    assert {item.record_id: item.revision for item in page.items} == {"t1": 2, "t2": 1}

    records = list(repository.list("tasks"))
    assert len(records) == 2
    assert max(record["revision"] for record in records) == 2
    assert next(record for record in records if record["revision"] == 2)["value"] == 2


def test_get_works_without_the_index_but_writes_refuse(tmp_path) -> None:
    """单条读取走文件名约定（自愈）；索引损坏时写入必须在落盘前失败。"""
    repository = _repo(tmp_path, block_size=5)
    _fill(repository, "tasks", 3)
    record_dir = repository.workspace / "generations" / "gen-000001" / "records"
    for path in _blocks(repository):
        path.unlink()

    assert repository.get("tasks", "tasks0001") == {
        "kind": "tasks",
        "index": 1,
        "revision": 1,
    }

    with pytest.raises(WorkspaceNotReady) as error:
        repository.put("tasks", "tasks0001", {"index": 9}, expected_revision=1)
    assert error.value.details["reason"] == "INDEX_BLOCK_MISSING"

    # 索引不可读时不得留下任何新记录文件（先校验、后落盘）
    assert sorted(path.name for path in record_dir.rglob("r*.json")) == [
        "r00000001.json",
        "r00000001.json",
        "r00000001.json",
    ]

    with pytest.raises(WorkspaceNotReady):
        repository.index_page("tasks")


def test_invalid_cursor_is_rejected(tmp_path) -> None:
    repository = _repo(tmp_path)
    _fill(repository, "tasks", 3)

    with pytest.raises(ValueError):
        repository.index_page("tasks", cursor="bogus")


def test_empty_page_for_unknown_kind(tmp_path) -> None:
    repository = _repo(tmp_path)
    _fill(repository, "tasks", 1)

    page = repository.index_page("runs")

    assert page.items == ()
    assert page.next_cursor is None


def test_legacy_v1_state_is_refused_with_migration_hint(tmp_path) -> None:
    repository = _repo(tmp_path)
    _fill(repository, "tasks", 1)
    state_path = _state_path(repository)
    state = _load(state_path)
    state["schema_version"] = "aatp.workspace-state/1.0"
    state_path.write_text(json.dumps(state), encoding="utf-8")

    with pytest.raises(WorkspaceNotReady) as error:
        repository.get("tasks", "tasks0000")

    assert error.value.details["reason"] == "STATE_SCHEMA_UNSUPPORTED"
    assert "migrate" in str(error.value.details.get("hint", ""))
