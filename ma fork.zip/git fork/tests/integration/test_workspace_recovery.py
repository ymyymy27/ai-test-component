"""Regression tests for review finding P1-9 (silent index reset)."""

import json

import pytest

from ai_test.application.errors import StaleRevision, WorkspaceNotReady
from ai_test.infrastructure.file_store.records import FileRecordRepository


def test_missing_pointer_with_existing_data_is_refused(tmp_path) -> None:
    """Losing current.json must never overwrite the committed record index."""
    workspace = tmp_path / "workspace"
    repository = FileRecordRepository(workspace)
    repository.put("projects", "demo", {"name": "演示项目"})

    state_file = workspace / "generations" / "gen-000001" / "state.json"
    before = state_file.read_bytes()
    (workspace / "current.json").unlink()

    with pytest.raises(WorkspaceNotReady) as error:
        repository.put("projects", "demo2", {"name": "另一个项目"})
    assert error.value.details["reason"] == "POINTER_MISSING_WITH_DATA"

    with pytest.raises(WorkspaceNotReady):
        repository.get("projects", "demo")

    # The index on disk is untouched, and the record file is still there.
    assert state_file.read_bytes() == before
    record = workspace / "generations" / "gen-000001" / "records" / "projects" / "demo"
    assert list(record.glob("r*.json"))


def test_init_refuses_to_clobber_existing_generation(tmp_path) -> None:
    workspace = tmp_path / "workspace"
    repository = FileRecordRepository(workspace)
    repository.put("projects", "demo", {"name": "演示项目"})
    state_file = workspace / "generations" / "gen-000001" / "state.json"
    before = json.loads(state_file.read_text(encoding="utf-8"))
    (workspace / "current.json").unlink()

    with pytest.raises(WorkspaceNotReady):
        repository.initialize()

    assert json.loads(state_file.read_text(encoding="utf-8")) == before


def test_read_on_fresh_workspace_creates_nothing(tmp_path) -> None:
    workspace = tmp_path / "workspace"
    repository = FileRecordRepository(workspace)

    with pytest.raises(WorkspaceNotReady) as error:
        repository.get("projects", "demo")
    assert error.value.details["reason"] == "NOT_INITIALIZED"
    assert not workspace.exists()


def test_put_initializes_once_and_keeps_revision_contract(tmp_path) -> None:
    workspace = tmp_path / "workspace"
    repository = FileRecordRepository(workspace)
    assert repository.put("projects", "p1", {"name": "one"}, expected_revision=0) == 1
    assert repository.put("projects", "p1", {"name": "two"}, expected_revision=1) == 2
    with pytest.raises(StaleRevision):
        repository.put("projects", "p1", {"name": "stale"}, expected_revision=1)


def test_list_reads_state_once(tmp_path, monkeypatch) -> None:
    """Review finding P2-2: list() must not re-parse state.json per record."""
    workspace = tmp_path / "workspace"
    repository = FileRecordRepository(workspace)
    for index in range(5):
        repository.put("projects", f"p{index}", {"name": f"n{index}"})

    calls = {"count": 0}
    original = repository._load_state

    def counting_load_state():  # type: ignore[no-untyped-def]
        calls["count"] += 1
        return original()

    monkeypatch.setattr(repository, "_load_state", counting_load_state)
    assert len(list(repository.list("projects"))) == 5
    assert calls["count"] == 1


def test_state_with_unsupported_schema_is_refused(tmp_path) -> None:
    workspace = tmp_path / "workspace"
    repository = FileRecordRepository(workspace)
    repository.put("projects", "demo", {"name": "演示项目"})
    state_file = workspace / "generations" / "gen-000001" / "state.json"
    state = json.loads(state_file.read_text(encoding="utf-8"))
    state["schema_version"] = "aatp.workspace-state/0.0-broken"
    state_file.write_text(json.dumps(state), encoding="utf-8")

    with pytest.raises(WorkspaceNotReady) as error:
        repository.get("projects", "demo")
    assert error.value.details["reason"] == "STATE_SCHEMA_UNSUPPORTED"
