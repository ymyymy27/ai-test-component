"""写入协调者（ADR-002）行为测试。"""

import json
import os
import time

import pytest

from ai_test.application.errors import (
    RateLimited,
    StaleRevision,
    WorkspaceInUse,
    WorkspaceNotReady,
)
from ai_test.infrastructure.file_store.coordinator import (
    NORMAL,
    TERMINAL,
    WriteCoordinator,
    WriteIntent,
    WriteQueue,
)
from ai_test.infrastructure.file_store.locks import WriterHolder, read_holder, utc_now, write_holder
from ai_test.infrastructure.file_store.records import FileRecordRepository


def _repository(tmp_path) -> FileRecordRepository:
    return FileRecordRepository(tmp_path / "workspace", lock_timeout_seconds=0.2)


def _coordinator(tmp_path, **kwargs) -> WriteCoordinator:
    kwargs.setdefault("auto_heartbeat", False)
    return WriteCoordinator(_repository(tmp_path), **kwargs)


def test_open_bumps_epoch_and_writes_holder_metadata(tmp_path) -> None:
    coordinator = _coordinator(tmp_path)
    # 读路径不建状态：未初始化时读 epoch 会明确报未初始化
    with pytest.raises(WorkspaceNotReady):
        coordinator.repository.read_writer_epoch()

    coordinator.open()
    try:
        assert coordinator.repository.read_writer_epoch() == 1
        holder = read_holder(coordinator.lease.path)
        assert holder is not None
        assert holder.writer_epoch == 1
        assert holder.pid == os.getpid()
        assert holder.host
        assert holder.acquired_at
        # 提交走协调者：不再重复加锁（锁非重入），且能正常落盘
        assert coordinator.submit(WriteIntent("tasks", "t1", {"value": 1})) == 1
        assert coordinator.repository.get("tasks", "t1") == {"value": 1, "revision": 1}
    finally:
        coordinator.close()

    # 关闭后释放租约并清理侧车元数据；再次 open 继续递增 epoch
    assert read_holder(coordinator.lease.path) is None
    coordinator.open()
    try:
        assert coordinator.repository.read_writer_epoch() == 2
    finally:
        coordinator.close()


def test_second_writer_reports_workspace_in_use_with_diagnostics(tmp_path) -> None:
    holder = _coordinator(tmp_path)
    holder.open()
    try:
        intruder = _coordinator(tmp_path)
        with pytest.raises(WorkspaceInUse) as error:
            intruder.open()
        details = error.value.details
        assert error.value.retryable is True
        assert details["holder"]["pid"] == os.getpid()
        assert details["holder"]["writer_epoch"] == holder.epoch
        assert "acquired_at" in details["holder"]
        # 诊断信息不含工作空间路径
        assert str(tmp_path) not in json.dumps(details)
    finally:
        holder.close()


def test_stale_writer_cannot_commit(tmp_path) -> None:
    """RV01 的核心：旧协调者的迟到提交必须被拒，且不落盘。"""
    coordinator = _coordinator(tmp_path)
    coordinator.open()
    try:
        # 模拟"另一个协调者接管"：epoch 被外部递增
        coordinator.repository.set_writer_epoch(coordinator.epoch + 1)

        with pytest.raises(StaleRevision) as error:
            coordinator.submit(WriteIntent("tasks", "t1", {"value": 1}))
        assert error.value.details["reason"] == "OLD_WRITER_EPOCH"
        assert coordinator.repository.get("tasks", "t1") is None
        assert coordinator.metrics()["counts"]["stale_rejected"] == 1
    finally:
        coordinator.close()


def test_heartbeat_verifies_epoch_ownership(tmp_path) -> None:
    coordinator = _coordinator(tmp_path)
    coordinator.open()
    try:
        coordinator.heartbeat()  # 自己仍是所有者，正常刷新
        coordinator.repository.set_writer_epoch(coordinator.epoch + 1)
        with pytest.raises(StaleRevision):
            coordinator.heartbeat()
    finally:
        coordinator.close()


def test_stale_heartbeat_stops_writes_until_refreshed(tmp_path) -> None:
    coordinator = _coordinator(tmp_path, stale_after_seconds=30.0)
    coordinator.open()
    try:
        stale = WriterHolder(
            instance_id="someone-else",
            pid=os.getpid(),
            host="probe",
            process_started_at=utc_now(),
            acquired_at=utc_now(),
            heartbeat_at="2020-01-01T00:00:00+00:00",
            writer_epoch=coordinator.epoch,
        )
        write_holder(coordinator.lease.path, stale)

        with pytest.raises(WorkspaceNotReady) as error:
            coordinator.submit(WriteIntent("tasks", "t1", {"value": 1}))
        assert error.value.details["reason"] == "COORDINATOR_STALE"

        coordinator.heartbeat()  # 恢复心跳后可以继续服务
        assert coordinator.submit(WriteIntent("tasks", "t1", {"value": 1})) == 1
    finally:
        coordinator.close()


def test_queue_admission_limits_and_terminal_priority() -> None:
    queue = WriteQueue()
    for index in range(90):
        queue.admit(WriteIntent("tasks", f"t{index:03d}", {}, priority=NORMAL))
    assert queue.counts() == {"normal": 90, "terminal": 0}

    with pytest.raises(RateLimited) as error:
        queue.admit(WriteIntent("tasks", "overflow", {}, priority=NORMAL))
    assert error.value.details["retry_after_ms"] == 250
    assert error.value.retryable is True

    # 终态仍可使用 10 个保留位
    for index in range(10):
        queue.admit(WriteIntent("runs", f"r{index:03d}", {}, priority=TERMINAL))
    assert queue.counts() == {"normal": 90, "terminal": 10}
    with pytest.raises(RateLimited):
        queue.admit(WriteIntent("runs", "overflow", {}, priority=TERMINAL))

    # 终态优先出队，同级 FIFO
    first = queue.take()
    second = queue.take()
    assert first is not None and second is not None
    assert first[1].priority == TERMINAL
    assert second[1].record_id == "r001"
    assert len(queue) == 98


def test_queue_wait_is_measured(tmp_path) -> None:
    coordinator = _coordinator(tmp_path)
    coordinator.open()
    try:
        coordinator.enqueue(WriteIntent("tasks", "t1", {"value": 1}))
        time.sleep(0.05)
        assert coordinator.serve_once() == 1

        metrics = coordinator.metrics()
        assert metrics["counts"]["commits"] == 1
        assert metrics["queue_wait_ms"]["samples"] == 1
        assert metrics["queue_wait_ms"]["p95"] >= 40.0  # 排队约 50ms
        assert metrics["commit_ms"]["p95"] > 0
        assert coordinator.serve_once() is None
    finally:
        coordinator.close()


def test_submit_requires_an_open_coordinator(tmp_path) -> None:
    coordinator = _coordinator(tmp_path)
    with pytest.raises(WorkspaceNotReady) as error:
        coordinator.submit(WriteIntent("tasks", "t1", {"value": 1}))
    assert error.value.details["reason"] == "COORDINATOR_CLOSED"
