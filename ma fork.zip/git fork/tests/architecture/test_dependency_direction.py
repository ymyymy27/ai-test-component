import ast
from pathlib import Path

ROOT = Path(__file__).parents[2] / "src" / "ai_test"


def _modules() -> dict[str, Path]:
    modules: dict[str, Path] = {}
    for source in ROOT.rglob("*.py"):
        relative = source.relative_to(ROOT).with_suffix("")
        parts = list(relative.parts)
        if parts[-1] == "__init__":
            parts.pop()
        modules[".".join(["ai_test", *parts])] = source
    return modules


def _imports(source: Path) -> set[str]:
    targets: set[str] = set()
    tree = ast.parse(source.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            targets.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            base = node.module or ""
            targets.add(base)
            targets.update(f"{base}.{alias.name}" for alias in node.names if base)
    return {target for target in targets if target.startswith("ai_test")}


def test_domain_has_no_outward_dependencies() -> None:
    root = ROOT / "domain"
    forbidden = ("ai_test.application", "ai_test.infrastructure", "ai_test.interfaces")
    violations: list[str] = []
    for source in root.glob("*.py"):
        tree = ast.parse(source.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                names = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom):
                names = [node.module or ""]
            else:
                continue
            for name in names:
                if name.startswith(forbidden):
                    violations.append(f"{source.name}: {name}")
    assert violations == []


def test_no_internal_import_cycles() -> None:
    """架构文档 v2.4 §3:166 requires cyclic imports to fail CI."""
    modules = _modules()
    known = set(modules)
    graph = {
        name: {target for target in _imports(source) if target in known}
        for name, source in modules.items()
    }

    # Depth first search keeping the current path: any edge back onto the path
    # is a cycle.
    finished: set[str] = set()
    cycles: list[list[str]] = []

    def visit(node: str, path: list[str]) -> None:
        if node in path:
            cycles.append([*path[path.index(node) :], node])
            return
        if node in finished:
            return
        for target in sorted(graph.get(node, ())):
            visit(target, [*path, node])
        finished.add(node)

    for name in sorted(graph):
        visit(name, [])

    assert cycles == [], f"import cycles detected: {cycles}"


def test_infrastructure_does_not_import_interfaces() -> None:
    violations: list[str] = []
    for source in (ROOT / "infrastructure").rglob("*.py"):
        for target in _imports(source):
            if target.startswith("ai_test.interfaces"):
                violations.append(f"{source.name}: {target}")
    assert violations == []
