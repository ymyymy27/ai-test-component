"""测试用的小工具（被多个测试目录复用）。"""

from __future__ import annotations

import pathlib
from typing import Any


class OpenCounter:
    """统计一次操作里 ``Path.open`` 的次数与被打开的路径（含 ``read_text``）。"""

    def __enter__(self) -> OpenCounter:
        self.count = 0
        self.paths: list[str] = []
        self._original = pathlib.Path.open

        def wrapper(inner_self: pathlib.Path, *args: Any, **kwargs: Any) -> Any:
            self.count += 1
            self.paths.append(inner_self.name)
            return self._original(inner_self, *args, **kwargs)

        pathlib.Path.open = wrapper  # type: ignore[method-assign]
        return self

    def __exit__(self, *exc: object) -> None:
        pathlib.Path.open = self._original  # type: ignore[method-assign]
