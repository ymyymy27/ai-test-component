"""原子写重试的回归测试——重点是踩过的那个坑：Windows 的 WinError 5 会被 Python
映射成 ``errno.EACCES``(13)，因此判断瞬时错误必须按 errno（或 winerror 属性），
比较 ``errno in {5, 32}`` **永远不会命中**、重试形同虚设。
"""

import errno
import os
from pathlib import Path
from typing import Any

import pytest

from ai_test.infrastructure.file_store import atomic


def _denied(winerror: int | None = None, errno_value: int = errno.EACCES) -> PermissionError:
    error = PermissionError(errno_value, "denied")
    if winerror is not None:
        error.winerror = winerror  # type: ignore[attr-defined]
    return error


@pytest.mark.parametrize(
    ("errno_value", "winerror", "expected"),
    [
        (errno.EACCES, 5, True),
        (errno.EACCES, 32, True),
        (errno.EACCES, None, True),
        (errno.EPERM, None, True),
        (errno.ENOENT, None, False),
        (errno.EINVAL, None, False),
    ],
)
def test_is_transient_classification(
    errno_value: int, winerror: int | None, expected: bool
) -> None:
    assert atomic.is_transient(_denied(winerror, errno_value)) is expected


def test_replace_retries_transient_denial(monkeypatch, tmp_path: Path) -> None:
    """关键回归：前两次 WinError 5（errno 13）之后应重试成功。"""
    calls = {"count": 0}
    original = os.replace

    def flaky(src: Any, dst: Any, *args: Any, **kwargs: Any) -> Any:
        calls["count"] += 1
        if calls["count"] <= 2:
            raise _denied(5)
        return original(src, dst, *args, **kwargs)

    monkeypatch.setattr(os, "replace", flaky)

    atomic.write_json(tmp_path / "target.json", {"ok": True}, base_delay=0.001)

    assert calls["count"] == 3
    assert (tmp_path / "target.json").exists()


def test_shared_conflict_is_retried(monkeypatch, tmp_path: Path) -> None:
    calls = {"count": 0}
    original = os.replace

    def flaky(src: Any, dst: Any, *args: Any, **kwargs: Any) -> Any:
        calls["count"] += 1
        if calls["count"] == 1:
            raise _denied(32)
        return original(src, dst, *args, **kwargs)

    monkeypatch.setattr(os, "replace", flaky)

    atomic.write_json(tmp_path / "target.json", {"ok": True}, base_delay=0.001)

    assert calls["count"] == 2


def test_non_transient_error_propagates_immediately(monkeypatch, tmp_path: Path) -> None:
    calls = {"count": 0}

    def failing(src: Any, dst: Any, *args: Any, **kwargs: Any) -> Any:
        calls["count"] += 1
        raise FileNotFoundError(errno.ENOENT, "no such file")

    monkeypatch.setattr(os, "replace", failing)

    with pytest.raises(FileNotFoundError):
        atomic.write_json(tmp_path / "target.json", {"ok": True})

    assert calls["count"] == 1, "非瞬时错误不得重试"
    assert not (tmp_path / "target.json").exists()


def test_retry_budget_is_bounded_and_raises(monkeypatch) -> None:
    calls = {"count": 0}

    def always_denied(src: Any, dst: Any, *args: Any, **kwargs: Any) -> Any:
        calls["count"] += 1
        raise _denied(32)

    monkeypatch.setattr(os, "replace", always_denied)

    with pytest.raises(PermissionError):
        atomic.replace_with_retry("a", "b", attempts=3, base_delay=0.001)

    assert calls["count"] == 3


def test_attempts_can_be_overridden_by_env(monkeypatch) -> None:
    monkeypatch.setenv("AITEST_REPLACE_ATTEMPTS", "5")
    assert atomic.configured_attempts() == 5

    monkeypatch.setenv("AITEST_REPLACE_ATTEMPTS", "bogus")
    assert atomic.configured_attempts() == atomic.DEFAULT_ATTEMPTS

    monkeypatch.delenv("AITEST_REPLACE_ATTEMPTS")
    assert atomic.configured_attempts() == atomic.DEFAULT_ATTEMPTS
