"""CLI contract: standard error envelope, stable exit codes (review finding P1-5)."""

import json

import ai_test
from ai_test.interfaces.cli import main


def _run(capsys, argv: list[str]) -> tuple[int, dict]:
    code = main(argv)
    captured = capsys.readouterr()
    return code, json.loads(captured.out)


def test_capabilities_reports_the_package_version(capsys) -> None:
    code, payload = _run(capsys, ["capabilities"])
    assert code == 0
    assert payload["version"] == ai_test.__version__
    assert "doctor" in payload["ready"]


def test_happy_path_round_trip(capsys, tmp_path) -> None:
    workspace = str(tmp_path / "workspace")
    assert _run(capsys, ["--workspace", workspace, "init"])[0] == 0
    code, created = _run(
        capsys, ["--workspace", workspace, "project-create", "demo", "演示项目"]
    )
    assert code == 0
    assert created["revision"] == 1
    code, loaded = _run(capsys, ["--workspace", workspace, "project-get", "demo"])
    assert code == 0
    assert loaded == created


def test_duplicate_project_reports_stale_revision(capsys, tmp_path) -> None:
    workspace = str(tmp_path / "workspace")
    assert _run(capsys, ["--workspace", workspace, "project-create", "demo", "甲"])[0] == 0
    code, payload = _run(capsys, ["--workspace", workspace, "project-create", "demo", "乙"])
    assert code == 4
    assert payload["error"]["code"] == "STALE_REVISION"
    assert payload["error"]["retryable"] is False
    assert payload["error"]["details"]["actual_revision"] == 1


def test_empty_project_id_is_invalid_argument(capsys, tmp_path) -> None:
    workspace = str(tmp_path / "workspace")
    code, payload = _run(capsys, ["--workspace", workspace, "project-create", "", "甲"])
    assert code == 2
    assert payload["error"]["code"] == "INVALID_ARGUMENT"
    assert "project_id" in payload["error"]["message"]


def test_missing_project_is_not_found_without_path_leak(capsys, tmp_path) -> None:
    workspace = tmp_path / "workspace"
    # 先初始化：未初始化的工作空间会先返回 WORKSPACE_NOT_READY，
    # 而本用例要验证的是"工作空间正常但对象不存在"这条路径。
    assert _run(capsys, ["--workspace", str(workspace), "init"])[0] == 0
    code, payload = _run(capsys, ["--workspace", str(workspace), "project-get", "nope"])
    assert code == 3
    assert payload["error"]["code"] == "NOT_FOUND"
    assert payload["error"]["details"] == {"project_id": "nope"}
    assert str(workspace) not in json.dumps(payload)


def test_reading_a_fresh_workspace_is_workspace_not_ready(capsys, tmp_path) -> None:
    workspace = tmp_path / "workspace"
    code, payload = _run(capsys, ["--workspace", str(workspace), "project-get", "demo"])
    assert code == 5
    assert payload["error"]["code"] == "WORKSPACE_NOT_READY"
    assert payload["error"]["details"]["reason"] == "NOT_INITIALIZED"
    assert not workspace.exists()


def test_doctor_on_missing_workspace_exits_not_ready(capsys, tmp_path) -> None:
    code, payload = _run(capsys, ["--workspace", str(tmp_path / "absent"), "doctor"])
    assert code == 5
    assert payload["status"] == "NOT_READY"
    assert payload["writable"] is False


def test_doctor_on_healthy_workspace_exits_zero(capsys, tmp_path) -> None:
    workspace = str(tmp_path / "workspace")
    assert _run(capsys, ["--workspace", workspace, "init"])[0] == 0
    assert (
        _run(capsys, ["--workspace", workspace, "project-create", "demo", "演示项目"])[0] == 0
    )
    code, payload = _run(capsys, ["--workspace", workspace, "doctor"])
    assert code == 0
    assert payload["status"] == "HEALTHY"
    assert payload["writable"] is True
    names = {check["name"] for check in payload["checks"]}
    assert {"workspace", "layout", "writable", "pointer", "state", "generations"} <= names
