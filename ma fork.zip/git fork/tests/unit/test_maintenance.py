"""Doctor status aggregation (pure use case, no filesystem)."""

from ai_test.application.ports.system import DEGRADED, HEALTHY, NOT_READY, WorkspaceCheck
from ai_test.application.use_cases.maintenance import doctor


class _StubInspector:
    def __init__(self, *checks: WorkspaceCheck) -> None:
        self._checks = checks

    def inspect(self) -> tuple[WorkspaceCheck, ...]:
        return self._checks


class _StubTelemetry:
    def increment(self, metric: str, value: int = 1) -> None:
        pass

    def health(self) -> dict[str, object]:
        return {"status": "ok", "counters": {"probe": 1}}


def test_all_healthy_is_healthy_and_writable() -> None:
    report = doctor(
        _StubInspector(
            WorkspaceCheck("workspace", HEALTHY),
            WorkspaceCheck("writable", HEALTHY),
        )
    )
    assert report["status"] == HEALTHY
    assert report["writable"] is True


def test_degraded_does_not_clear_writability() -> None:
    report = doctor(
        _StubInspector(
            WorkspaceCheck("layout", DEGRADED, "missing: objects/sha256"),
            WorkspaceCheck("writable", HEALTHY),
        )
    )
    assert report["status"] == DEGRADED
    assert report["writable"] is True


def test_not_ready_dominates_and_disables_writable() -> None:
    report = doctor(
        _StubInspector(
            WorkspaceCheck("layout", DEGRADED),
            WorkspaceCheck("writable", NOT_READY, "workspace is not writable"),
            WorkspaceCheck("state", HEALTHY),
        )
    )
    assert report["status"] == NOT_READY
    assert report["writable"] is False


def test_no_checks_is_not_ready() -> None:
    report = doctor(_StubInspector())
    assert report["status"] == NOT_READY
    assert report["writable"] is False
    assert report["checks"] == []


def test_unknown_check_status_is_treated_as_not_ready() -> None:
    report = doctor(_StubInspector(WorkspaceCheck("mystery", "SOMETHING_ELSE")))
    assert report["status"] == NOT_READY


def test_metrics_are_attached_when_telemetry_is_provided() -> None:
    report = doctor(_StubInspector(WorkspaceCheck("writable", HEALTHY)), _StubTelemetry())
    assert report["metrics"] == {"status": "ok", "counters": {"probe": 1}}


def test_metrics_are_omitted_without_telemetry() -> None:
    report = doctor(_StubInspector(WorkspaceCheck("writable", HEALTHY)))
    assert "metrics" not in report
