"""统计 `python -m build` 产出的 sdist / wheel 内容，用于核对打包白名单。"""

from __future__ import annotations

import sys
import tarfile
import zipfile
from pathlib import Path

dist = Path(__file__).resolve().parent / ".review-probe" / "dist"
PROBES = (
    "pyproject.toml",
    "README.md",
    "tests/",
    "docs/",
    "examples/",
    "附件/",
    "uv.lock",
    "ai_test/resources/panel/index.js",
    "ai_test/resources/rules/default.md",
    "ai_test/resources/schemas/host-event.schema.json",
)


def names_of(archive: Path) -> list[str]:
    if archive.suffix == ".whl":
        with zipfile.ZipFile(archive) as handle:
            return handle.namelist()
    with tarfile.open(archive) as handle:
        return handle.getnames()


found_any = False
for archive in sorted(dist.glob("*")):
    if not archive.name.endswith((".whl", ".tar.gz", ".tgz")):
        continue
    found_any = True
    names = names_of(archive)
    print(f"\n### {archive.name}  ({len(names)} 个条目)")
    for probe in PROBES:
        hits = [name for name in names if probe.rstrip("/") in name]
        print(f"  [{'有' if hits else '缺'}] {probe:<45} {len(hits)} 项")
    tops = sorted(
        {name.split("/")[1] if "/" in name else name for name in names if not name.endswith("/")}
    )[:12]
    print(f"  条目示例: {tops}")

if not found_any:
    print("未找到构建产物：", dist, file=sys.stderr)
    raise SystemExit(1)
