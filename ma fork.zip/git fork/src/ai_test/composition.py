from dataclasses import dataclass
from pathlib import Path

from ai_test.application.use_cases.project_context import ProjectContext
from ai_test.infrastructure.file_store.objects import FileObjectStore
from ai_test.infrastructure.file_store.records import FileRecordRepository
from ai_test.infrastructure.telemetry import InMemoryTelemetry


@dataclass(frozen=True, slots=True)
class Component:
    workspace: Path
    projects: ProjectContext
    records: FileRecordRepository
    objects: FileObjectStore
    telemetry: InMemoryTelemetry


def create_component(workspace: str | Path, *, initialize: bool = False) -> Component:
    """Assemble the component for one workspace.

    ``initialize=False`` (the default) builds no state: read-only callers and
    ``aitest doctor`` must be able to inspect a fresh or damaged workspace
    without mutating it, so creating the layout is an explicit choice. Writes
    still initialize on demand inside the repository (``put``).
    """
    root = Path(workspace).expanduser().resolve()
    records = FileRecordRepository(root)
    if initialize:
        records.initialize()
    return Component(
        workspace=root,
        projects=ProjectContext(records),
        records=records,
        objects=FileObjectStore(root),
        telemetry=InMemoryTelemetry(),
    )
