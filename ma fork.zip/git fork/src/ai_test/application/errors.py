"""Application-level error types.

Every error carries a stable ``code`` drawn from the AATP error vocabulary
(架构文档 v2.4 §4.1:188: INVALID_ARGUMENT, UNAUTHENTICATED, FORBIDDEN, NOT_FOUND,
CONFLICT, STALE_REVISION, CAPABILITY_UNAVAILABLE, DEADLINE_EXCEEDED,
RATE_LIMITED, WORKSPACE_IN_USE, WORKSPACE_NOT_READY, SNAPSHOT_REQUIRED, INTERNAL)
plus ``retryable`` and ``details`` so interfaces can emit one consistent envelope.

``details`` never contains absolute paths, credentials or stacks: the envelope is
handed to hosts and users as-is.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

INVALID_ARGUMENT = "INVALID_ARGUMENT"
NOT_FOUND = "NOT_FOUND"
CONFLICT = "CONFLICT"
STALE_REVISION = "STALE_REVISION"
CAPABILITY_UNAVAILABLE = "CAPABILITY_UNAVAILABLE"
WORKSPACE_IN_USE = "WORKSPACE_IN_USE"
WORKSPACE_NOT_READY = "WORKSPACE_NOT_READY"
RATE_LIMITED = "RATE_LIMITED"
INTERNAL = "INTERNAL"


class ComponentError(RuntimeError):
    """Base class for errors that map onto the standard AATP envelope."""

    code = INTERNAL
    retryable = False
    exit_code = 1

    def __init__(self, message: str, *, details: Mapping[str, Any] | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details: dict[str, Any] = dict(details or {})

    def envelope(self) -> dict[str, Any]:
        """Return the standard error body (no stack, no paths, no credentials)."""
        return {
            "error": {
                "code": self.code,
                "message": self.message,
                "retryable": self.retryable,
                "details": dict(self.details),
            }
        }


class InvalidArgument(ComponentError):
    """The request itself is malformed or violates a domain invariant."""

    code = INVALID_ARGUMENT
    exit_code = 2


class NotFound(ComponentError):
    """The addressed object does not exist."""

    code = NOT_FOUND
    exit_code = 3


class StaleRevision(ComponentError):
    """The caller wrote against a revision that is no longer current."""

    code = STALE_REVISION
    exit_code = 4


class Conflict(ComponentError):
    """A concurrent or duplicate change prevents the request."""

    code = CONFLICT
    retryable = True
    exit_code = 4


class WorkspaceInUse(ComponentError):
    """Another writer holds the workspace lease."""

    code = WORKSPACE_IN_USE
    retryable = True
    exit_code = 5


class WorkspaceNotReady(ComponentError):
    """The workspace exists but cannot be used (uninitialized, damaged, ...)."""

    code = WORKSPACE_NOT_READY
    exit_code = 5


class RateLimited(ComponentError):
    """The write coordinator queue is full; retry after ``retry_after_ms``."""

    code = RATE_LIMITED
    retryable = True
    exit_code = 4


class FeatureNotImplemented(ComponentError):
    """Raised when a capability is intentionally outside the current skeleton."""

    code = CAPABILITY_UNAVAILABLE
    exit_code = 6
