"""Workspace health and diagnostics use case (架构文档 v2.4 §4.5)."""

from __future__ import annotations

from typing import Any

from ai_test.application.ports.system import (
    DEGRADED,
    HEALTHY,
    NOT_READY,
    WorkspaceCheck,
    WorkspaceInspector,
)
from ai_test.application.ports.telemetry import TelemetryPort

WRITABLE_CHECK = "writable"

_STATUS_ORDER = {NOT_READY: 2, DEGRADED: 1, HEALTHY: 0}


def _overall(checks: tuple[WorkspaceCheck, ...]) -> str:
    if not checks:
        return NOT_READY
    worst = max(checks, key=lambda check: _STATUS_ORDER.get(check.status, 2))
    return worst.status if worst.status in _STATUS_ORDER else NOT_READY


def doctor(
    inspector: WorkspaceInspector,
    telemetry: TelemetryPort | None = None,
) -> dict[str, Any]:
    """Return the health report for one workspace.

    Unlike the previous skeleton, ``writable`` is derived from a real write
    probe and ``status`` from the checks actually performed, so a damaged
    workspace can no longer be reported as ``ok``.
    """
    checks = inspector.inspect()
    status = _overall(checks)
    report: dict[str, Any] = {
        "status": status,
        "writable": any(
            check.name == WRITABLE_CHECK and check.status == HEALTHY for check in checks
        ),
        "checks": [
            {"name": check.name, "status": check.status, "detail": check.detail}
            for check in checks
        ],
    }
    if telemetry is not None:
        report["metrics"] = telemetry.health()
    return report
