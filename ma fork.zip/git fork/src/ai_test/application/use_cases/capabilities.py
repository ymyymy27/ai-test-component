from typing import Any

from ai_test.version import __version__


def describe_capabilities() -> dict[str, Any]:
    return {
        "component": "ai-test-component",
        "version": __version__,
        "ready": [
            "workspace",
            "project-context",
            "python-api",
            "cli",
            "asgi-health",
            "doctor",
        ],
        "planned": [
            "delivery-intake",
            "test-planning",
            "execution",
            "evidence-review",
            "defect-management",
            "reporting",
            "ai-assistance",
            "mcp-tools",
        ],
    }
