from collections.abc import Iterator
from contextlib import AbstractContextManager
from dataclasses import dataclass
from typing import Any, Protocol


@dataclass(frozen=True, slots=True)
class IndexEntry:
    """索引块里的一条摘要（不含记录正文）。"""

    key: str
    kind: str
    record_id: str
    revision: int
    path: str


@dataclass(frozen=True, slots=True)
class IndexPage:
    """一页索引摘要 + 续读游标（ADR-001：查询只读入口与命中块）。"""

    kind: str
    items: tuple[IndexEntry, ...]
    next_cursor: str | None = None


class RecordRepository(Protocol):
    def get(self, kind: str, record_id: str) -> dict[str, Any] | None: ...

    def put(
        self,
        kind: str,
        record_id: str,
        payload: dict[str, Any],
        *,
        expected_revision: int | None = None,
    ) -> int: ...

    def list(self, kind: str) -> Iterator[dict[str, Any]]: ...

    def index_page(
        self,
        kind: str,
        *,
        limit: int = 200,
        cursor: str | None = None,
    ) -> IndexPage: ...


class EvidenceObjectStore(Protocol):
    def put_bytes(self, content: bytes) -> str: ...

    def read_bytes(self, digest: str) -> bytes: ...


class WorkspaceUnitOfWork(Protocol):
    """一次工作单元：在同一租约与同一 ``writer_epoch`` 下批量提交多条记录。

    实现必须保证（ADR-002 §4）：提交前核对 epoch、失败时不留下半提交状态、
    且"一次提交只重写受影响的索引块与一次 state 入口"（ADR-001 不变量）。
    """

    def unit_of_work(
        self,
        *,
        lease_held: bool = False,
        epoch: int | None = None,
    ) -> AbstractContextManager[Any]: ...
