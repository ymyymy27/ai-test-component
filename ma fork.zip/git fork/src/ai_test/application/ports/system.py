from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

HEALTHY = "HEALTHY"
DEGRADED = "DEGRADED"
NOT_READY = "NOT_READY"


class Clock(Protocol):
    def iso_now(self) -> str: ...


class WorkspaceLocator(Protocol):
    def locate(self) -> Path: ...


@dataclass(frozen=True, slots=True)
class WorkspaceCheck:
    """One diagnostic check result (架构文档 v2.4 §4.5:238)."""

    name: str
    status: str
    detail: str = ""


class WorkspaceInspector(Protocol):
    """Read-only inspection used by ``aitest doctor`` / ``health()``.

    Implementations must never create, migrate or repair state: diagnosing a
    damaged workspace is the point, so inspection has to stay side-effect free.
    """

    def inspect(self) -> tuple[WorkspaceCheck, ...]: ...
