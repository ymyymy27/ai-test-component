from pathlib import Path
from typing import Any

from ai_test.application.use_cases.capabilities import describe_capabilities
from ai_test.application.use_cases.maintenance import doctor
from ai_test.composition import Component, create_component
from ai_test.domain.projects import Project


class AITestAPI:
    """Narrow, stable Python entry point for local (single operator) use."""

    def __init__(self, workspace: str | Path, *, initialize: bool = True) -> None:
        self.component: Component = create_component(workspace, initialize=initialize)

    def create_project(self, project_id: str, name: str) -> Project:
        return self.component.projects.create(Project(project_id=project_id, name=name))

    def get_project(self, project_id: str) -> Project | None:
        return self.component.projects.get(project_id)

    def doctor(self) -> dict[str, Any]:
        """Return the real workspace health report (never a constant)."""
        return doctor(self.component.records, self.component.telemetry)

    def capabilities(self) -> dict[str, Any]:
        return describe_capabilities()
