"""Command line interface.

Error contract (aligned with 架构文档 v2.4 §4.1:188): every failure prints one JSON
envelope ``{"error": {"code", "message", "retryable", "details"}}`` using the
standard codes, exits with the code below, and never prints a stack trace or an
absolute path unless ``--verbose`` is given.

===== ==========================================
exit  meaning
===== ==========================================
0     success (``doctor`` may still report DEGRADED)
1     unexpected internal error
2     INVALID_ARGUMENT (also argparse usage errors)
3     NOT_FOUND
4     CONFLICT / STALE_REVISION
5     WORKSPACE_NOT_READY / WORKSPACE_IN_USE
6     CAPABILITY_UNAVAILABLE (not implemented yet)
===== ==========================================
"""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from dataclasses import asdict
from pathlib import Path
from typing import Any

from ai_test.application.errors import (
    INTERNAL,
    ComponentError,
    InvalidArgument,
    NotFound,
    WorkspaceNotReady,
)
from ai_test.application.ports.system import NOT_READY
from ai_test.application.use_cases.capabilities import describe_capabilities
from ai_test.application.use_cases.maintenance import doctor
from ai_test.composition import create_component
from ai_test.domain.projects import Project


def _emit(value: Any) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="aitest", description="AI 辅助测试组件")
    parser.add_argument("--workspace", type=Path, default=Path(".aitest"))
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="失败时输出完整堆栈（调试用，不加则只输出标准错误信封）",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("init", help="初始化工作空间")
    commands.add_parser("doctor", help="检查工作空间健康状态（只读，不做修复）")
    commands.add_parser("capabilities", help="列出已实现及计划能力")
    create = commands.add_parser("project-create", help="创建项目上下文")
    create.add_argument("project_id")
    create.add_argument("name")
    get = commands.add_parser("project-get", help="读取项目上下文")
    get.add_argument("project_id")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return _dispatch(args)
    except ComponentError as error:
        _emit(error.envelope())
        return error.exit_code
    except ValueError as error:
        invalid = InvalidArgument(str(error))
        _emit(invalid.envelope())
        return invalid.exit_code
    except OSError as error:
        if args.verbose:
            raise
        _emit(
            {
                "error": {
                    "code": INTERNAL,
                    "message": f"filesystem operation failed: {type(error).__name__} "
                    f"(errno={error.errno})",
                    "retryable": False,
                    "details": {},
                }
            }
        )
        return 1
    except Exception as error:  # noqa: BLE001 - last resort for the CLI contract
        if args.verbose:
            raise
        _emit(
            {
                "error": {
                    "code": INTERNAL,
                    "message": f"unexpected failure: {type(error).__name__}",
                    "retryable": False,
                    "details": {},
                }
            }
        )
        return 1


def _dispatch(args: argparse.Namespace) -> int:
    if args.command == "capabilities":
        _emit(describe_capabilities())
        return 0
    if args.command == "init":
        component = create_component(args.workspace, initialize=True)
        _emit({"status": "initialized", "workspace": str(component.workspace)})
        return 0
    if args.command == "doctor":
        component = create_component(args.workspace)
        report = doctor(component.records, component.telemetry)
        _emit({"workspace": str(component.workspace), **report})
        return 0 if report["status"] != NOT_READY else WorkspaceNotReady.exit_code

    component = create_component(args.workspace)
    if args.command == "project-create":
        created = component.projects.create(Project(args.project_id, args.name))
        _emit(asdict(created))
        return 0
    if args.command == "project-get":
        loaded = component.projects.get(args.project_id)
        if loaded is None:
            raise NotFound(
                f"project {args.project_id!r} does not exist",
                details={"project_id": args.project_id},
            )
        _emit(asdict(loaded))
        return 0
    raise InvalidArgument(f"unknown command {args.command!r}")


if __name__ == "__main__":
    raise SystemExit(main())
