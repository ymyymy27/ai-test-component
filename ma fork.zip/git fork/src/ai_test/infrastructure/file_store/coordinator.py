"""写入协调者（ADR-002）：单写者 + writer_epoch + 有界队列 + 心跳与降级。

职责边界（对应 ADR-002 的四条决定）：

1. **租约与侧车诊断**：取得 ``.locks/writer.lock`` 后写 ``.locks/writer.json``（实例/进程/主机/
   取得时间/心跳/epoch）；判活以 OS 锁为准，元数据只作诊断。
2. **epoch**：取得租约确认旧写入者离去后 ``writer_epoch += 1`` 并写入指针；每次提交核对 epoch，
   不一致即拒（``STALE_REVISION``，``details.reason=OLD_WRITER_EPOCH``）。
3. **有界队列**：最多 100 个已验证的提交意图，其中 10 个保留给运行终态；普通意图达到 90 个后
   立即返回 ``RATE_LIMITED`` + ``retry_after_ms``（不排队等待）。
4. **心跳**：默认每 5 秒刷新；心跳超过 30 秒未更新 → ``NOT_READY`` 且停止接收新写
   （``details.reason=COORDINATOR_STALE``）。

本地模式（CLI）与团队模式的差异只在"谁驱动执行"：CLI 用 ``submit`` 同步执行，
团队模式由常驻协调者循环调用 ``serve_once``；两者对同一意图的提交路径完全相同
（架构 §2:58"核心只有一套"）。
"""

from __future__ import annotations

import os
import threading
import time
import uuid
from collections import deque
from contextlib import ExitStack
from dataclasses import dataclass, field
from typing import Any

from ai_test.application.errors import RateLimited, StaleRevision, WorkspaceNotReady
from ai_test.infrastructure.file_store.locks import (
    PROCESS_STARTED_AT,
    WriterHolder,
    WriterLease,
    age_seconds,
    clear_holder,
    current_host,
    utc_now,
    write_holder,
)
from ai_test.infrastructure.file_store.records import FileRecordRepository

NORMAL = "NORMAL"
TERMINAL = "TERMINAL"
QUEUE_CAPACITY = 100
TERMINAL_SLOTS = 10
NORMAL_LIMIT = QUEUE_CAPACITY - TERMINAL_SLOTS
RETRY_AFTER_MS = 250
HEARTBEAT_SECONDS = 5.0
STALE_AFTER_SECONDS = 30.0
LEASE_TIMEOUT_SECONDS = 10.0


@dataclass(frozen=True, slots=True)
class WriteIntent:
    """一次已经过校验、等待提交的写入意图。"""

    kind: str
    record_id: str
    payload: dict[str, Any]
    expected_revision: int | None = None
    priority: str = NORMAL


class WriteQueue:
    """有界准入队列：普通意图上限 ``NORMAL_LIMIT``，终态可使用保留位。"""

    def __init__(
        self,
        capacity: int = QUEUE_CAPACITY,
        terminal_slots: int = TERMINAL_SLOTS,
    ) -> None:
        self.capacity = max(1, int(capacity))
        self.terminal_slots = max(0, min(int(terminal_slots), self.capacity))
        # 入队时记录受理时刻，使"写队列等待"成为真实可测指标（§13）
        self._normal: deque[tuple[float, WriteIntent]] = deque()
        self._terminal: deque[tuple[float, WriteIntent]] = deque()
        self._lock = threading.Lock()

    def admit(self, intent: WriteIntent) -> None:
        with self._lock:
            depth = len(self._normal) + len(self._terminal)
            terminal = intent.priority == TERMINAL
            limit = self.capacity if terminal else self.capacity - self.terminal_slots
            if depth >= self.capacity or len(self._normal) >= limit:
                raise RateLimited(
                    "write coordinator queue is full",
                    details={
                        "queue_depth": depth,
                        "capacity": self.capacity,
                        "normal_limit": self.capacity - self.terminal_slots,
                        "priority": intent.priority,
                        "retry_after_ms": RETRY_AFTER_MS,
                    },
                )
            entry = (time.perf_counter(), intent)
            if terminal:
                self._terminal.append(entry)
            else:
                self._normal.append(entry)

    def take(self) -> tuple[float, WriteIntent] | None:
        """按优先级取一个意图（附受理时刻）：终态优先，同级 FIFO。"""
        with self._lock:
            if self._terminal:
                return self._terminal.popleft()
            if self._normal:
                return self._normal.popleft()
            return None

    def __len__(self) -> int:
        with self._lock:
            return len(self._normal) + len(self._terminal)

    def counts(self) -> dict[str, int]:
        with self._lock:
            return {"normal": len(self._normal), "terminal": len(self._terminal)}


@dataclass
class _Samples:
    """写入指标样本（有界，避免长期运行无限增长）。"""

    limit: int = 1000
    queue_wait_ms: list[float] = field(default_factory=list)
    commit_ms: list[float] = field(default_factory=list)

    def add(self, wait_ms: float, commit_ms: float) -> None:
        self.queue_wait_ms.append(wait_ms)
        self.commit_ms.append(commit_ms)
        if len(self.queue_wait_ms) > self.limit:
            del self.queue_wait_ms[: -self.limit]
        if len(self.commit_ms) > self.limit:
            del self.commit_ms[: -self.limit]


class WriteCoordinator:
    """一个工作空间的写入协调者。"""

    def __init__(
        self,
        repository: FileRecordRepository,
        *,
        lease_timeout_seconds: float = LEASE_TIMEOUT_SECONDS,
        queue: WriteQueue | None = None,
        heartbeat_seconds: float = HEARTBEAT_SECONDS,
        stale_after_seconds: float = STALE_AFTER_SECONDS,
        auto_heartbeat: bool = True,
        instance_id: str | None = None,
    ) -> None:
        self.repository = repository
        self.lease = WriterLease(
            repository.workspace / ".locks" / "writer.lock", lease_timeout_seconds
        )
        self.queue = queue if queue is not None else WriteQueue()
        self.heartbeat_seconds = heartbeat_seconds
        self.stale_after_seconds = stale_after_seconds
        self.auto_heartbeat = auto_heartbeat
        self.instance_id = instance_id or f"{os.getpid()}-{uuid.uuid4().hex[:8]}"
        self._stack: ExitStack | None = None
        self._epoch = 0
        self._opened = False
        self._stop = threading.Event()
        self._heartbeat_thread: threading.Thread | None = None
        self._samples = _Samples()
        self._counters = {"commits": 0, "rate_limited": 0, "stale_rejected": 0}

    # -------------------------------------------------------------- lifecycle

    def open(self) -> None:
        """取得租约、递增 epoch、写侧车元数据；失败时不留半开状态。"""
        if self._opened:
            return
        self.repository.initialize()
        stack = ExitStack()
        stack.enter_context(self.lease.acquire())
        try:
            self._epoch = self.repository.read_writer_epoch() + 1
            self.repository.set_writer_epoch(self._epoch)
            write_holder(self.lease.path, self._holder())
        except BaseException:
            stack.close()
            raise
        self._stack = stack
        self._opened = True
        if self.auto_heartbeat:
            self._heartbeat_thread = threading.Thread(
                target=self._heartbeat_loop, name="aitest-heartbeat", daemon=True
            )
            self._heartbeat_thread.start()

    def close(self) -> None:
        self._stop.set()
        thread = self._heartbeat_thread
        if thread is not None:
            thread.join(timeout=2.0)
            self._heartbeat_thread = None
        if self._stack is not None:
            self._stack.close()
            self._stack = None
        clear_holder(self.lease.path)
        self._opened = False

    def __enter__(self) -> WriteCoordinator:
        self.open()
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    def _holder(self) -> WriterHolder:
        return WriterHolder(
            instance_id=self.instance_id,
            pid=os.getpid(),
            host=current_host(),
            process_started_at=PROCESS_STARTED_AT,
            acquired_at=utc_now(),
            heartbeat_at=utc_now(),
            writer_epoch=self._epoch,
        )

    @property
    def epoch(self) -> int:
        return self._epoch

    # -------------------------------------------------------------- heartbeat

    def heartbeat(self) -> None:
        """刷新心跳，并核对 epoch 仍属于自己（失去所有权即抛错、停止服务）。"""
        if not self._opened:
            raise WorkspaceNotReady(
                "writer coordinator is not open",
                details={"reason": "COORDINATOR_CLOSED"},
            )
        current = self.repository.read_writer_epoch()
        if current != self._epoch:
            self._counters["stale_rejected"] += 1
            raise StaleRevision(
                "writer coordinator lost workspace ownership",
                details={
                    "reason": "OLD_WRITER_EPOCH",
                    "writer_epoch": self._epoch,
                    "current_epoch": current,
                },
            )
        holder = self._holder()
        write_holder(self.lease.path, holder)

    def _heartbeat_loop(self) -> None:
        while not self._stop.wait(self.heartbeat_seconds):
            try:
                self.heartbeat()
            except Exception:  # noqa: BLE001 - 心跳失败即停止服务（ADR-002）
                self._stop.set()
                return

    def ensure_serving(self) -> None:
        """服务前自检：必须已持有租约，且自己的心跳未过期。"""
        if not self._opened:
            raise WorkspaceNotReady(
                "writer coordinator is not open",
                details={"reason": "COORDINATOR_CLOSED"},
            )
        from ai_test.infrastructure.file_store.locks import read_holder

        holder = read_holder(self.lease.path)
        age = age_seconds(holder.heartbeat_at) if holder is not None else None
        if age is None or age > self.stale_after_seconds:
            raise WorkspaceNotReady(
                "write coordinator heartbeat is stale; refusing new writes",
                details={
                    "reason": "COORDINATOR_STALE",
                    "heartbeat_age_seconds": None if age is None else round(age, 1),
                    "stale_after_seconds": self.stale_after_seconds,
                },
            )

    # ------------------------------------------------------------------ write

    def submit(self, intent: WriteIntent) -> int:
        """准入并立即执行（本地模式）。队列满时抛 ``RateLimited``。"""
        self.ensure_serving()
        try:
            self.queue.admit(intent)
        except RateLimited:
            self._counters["rate_limited"] += 1
            raise
        revisions = self._serve_batch(max_intents=1)
        if not revisions:  # pragma: no cover - admit 后立即执行，理论不可达
            raise RateLimited("write coordinator queue drained unexpectedly")
        return revisions[0]

    def enqueue(self, intent: WriteIntent) -> None:
        """只入队（团队模式由常驻循环执行）。"""
        self.ensure_serving()
        try:
            self.queue.admit(intent)
        except RateLimited:
            self._counters["rate_limited"] += 1
            raise

    def serve_batch(self, *, max_intents: int = 50) -> int:
        """取一批意图并**一次提交**；返回本次提交的记录数（0 表示队列为空）。

        批量提交是队列等待的结构性解法：N 条记录只写一次 ``state.json``，
        因此"最后一条的等待时间"不再随积压条数线性增长。
        """
        self.ensure_serving()
        return len(self._serve_batch(max_intents=max_intents))

    def serve_once(self) -> int | None:
        """执行队列中的一个意图；队列为空返回 ``None``。"""
        revisions = self._serve_batch(max_intents=1)
        return revisions[0] if revisions else None

    def drain(self, *, max_intents: int = 0) -> int:
        """执行完当前队列，返回执行的意图数（供基准与恢复使用）。"""
        served = 0
        while True:
            batch = self._serve_batch(max_intents=50)
            if not batch:
                break
            served += len(batch)
            if max_intents and served >= max_intents:
                break
        return served

    def _serve_batch(self, *, max_intents: int) -> tuple[int, ...]:
        batch: list[tuple[float, WriteIntent]] = []
        while len(batch) < max(1, max_intents):
            taken = self.queue.take()
            if taken is None:
                break
            batch.append(taken)
        if not batch:
            return ()
        started = time.perf_counter()
        try:
            with self.repository.unit_of_work(lease_held=True, epoch=self._epoch) as unit:
                for _, intent in batch:
                    unit.put(
                        intent.kind,
                        intent.record_id,
                        intent.payload,
                        expected_revision=intent.expected_revision,
                    )
                revisions = unit.flush()
        except StaleRevision:
            self._counters["stale_rejected"] += 1
            raise
        finished = time.perf_counter()
        share_ms = (finished - started) * 1000 / len(batch)
        for admitted, _ in batch:
            self._samples.add((finished - admitted) * 1000, share_ms)
        self._counters["commits"] += len(batch)
        return tuple(revisions)

    # ---------------------------------------------------------------- metrics

    def metrics(self) -> dict[str, Any]:
        return {
            "instance_id": self.instance_id,
            "writer_epoch": self._epoch,
            "opened": self._opened,
            "queue": self.queue.counts(),
            "counts": dict(self._counters),
            "queue_wait_ms": _percentiles(self._samples.queue_wait_ms),
            "commit_ms": _percentiles(self._samples.commit_ms),
        }


def _percentiles(values: list[float]) -> dict[str, float | int]:
    if not values:
        return {"samples": 0, "p50": 0.0, "p95": 0.0, "max": 0.0}
    ordered = sorted(values)

    def pick(fraction: float) -> float:
        index = min(len(ordered) - 1, int(round(fraction * (len(ordered) - 1))))
        return round(ordered[index], 3)

    return {
        "samples": len(ordered),
        "p50": pick(0.5),
        "p95": pick(0.95),
        "max": round(ordered[-1], 3),
    }
