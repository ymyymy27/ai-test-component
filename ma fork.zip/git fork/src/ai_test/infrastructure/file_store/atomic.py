"""原子写文件（同目录临时文件 + fsync + 原子替换），带 Windows 瞬时失败重试。

为什么需要重试：Windows 上对"刚刚创建、仍可能被杀毒/索引服务持有句柄"的文件做
``os.replace`` 会瞬时返回 ``ERROR_ACCESS_DENIED``（WinError 5）或共享冲突（WinError 32）。
这在真实 Windows 宿主上会出现，因此比照可靠性要求做**有界重试**：失败若干次后仍然
抛出原错误，绝不吞掉（不允许出现"看起来提交成功、其实没落盘"的情况）。
"""

from __future__ import annotations

import errno as errno_module
import json
import os
import sys
import tempfile
import time
from contextlib import suppress
from pathlib import Path
from typing import Any

#: 瞬时错误：按 **errno** 判断才是对的——Python 在 Windows 上把 WinError 5（拒绝访问）
#: 与 WinError 32（共享冲突）都映射成 ``errno.EACCES``(13)，直接比较 winerror 数字会在
#: POSIX 路径下失效，而比较 ``errno in {5, 32}`` 则**永远不会命中**（曾经的实现错误）。
TRANSIENT_ERRNOS = {errno_module.EACCES, errno_module.EPERM, errno_module.EBUSY}
TRANSIENT_WINERRORS = {5, 32}
#: 重试预算：Windows 上杀毒/索引服务会短暂持有新建文件的句柄。
#: 默认 14 次、指数退避（上限 0.5 秒）≈ 7 秒总预算；可用环境变量
#: ``AITEST_REPLACE_ATTEMPTS`` 调整（部署侧可加大）。
DEFAULT_ATTEMPTS = 14
DEFAULT_BASE_DELAY = 0.02
MAX_DELAY = 0.5


def is_transient(error: OSError) -> bool:
    """该错误是否属于"稍后重试可能成功"的瞬时拒绝。"""
    if error.errno in TRANSIENT_ERRNOS:
        return True
    winerror = getattr(error, "winerror", None)
    return winerror in TRANSIENT_WINERRORS


def configured_attempts() -> int:
    """默认重试次数（可被 ``AITEST_REPLACE_ATTEMPTS`` 覆盖）。"""
    raw = os.environ.get("AITEST_REPLACE_ATTEMPTS", "")
    if raw.isdigit() and int(raw) > 0:
        return int(raw)
    return DEFAULT_ATTEMPTS


def replace_with_retry(
    source: str | os.PathLike[str],
    destination: str | os.PathLike[str],
    *,
    attempts: int | None = None,
    base_delay: float = DEFAULT_BASE_DELAY,
) -> None:
    """``os.replace`` + 瞬时失败有界重试（指数退避，上限 ``MAX_DELAY``）。"""
    budget = configured_attempts() if attempts is None else max(1, attempts)
    last_error: OSError | None = None
    for attempt in range(budget):
        try:
            os.replace(source, destination)
            return
        except OSError as error:
            if not is_transient(error):
                raise
            last_error = error
            delay = min(MAX_DELAY, base_delay * (2**attempt))
            print(
                f"[aitest] transient replace denial ({error.errno}); "
                f"retry {attempt + 1}/{budget} in {delay:.2f}s",
                file=sys.stderr,
            )
            time.sleep(delay)
    assert last_error is not None  # pragma: no cover - 循环至少执行一次
    raise last_error


def write_json(
    path: Path,
    value: dict[str, Any],
    *,
    attempts: int | None = None,
    base_delay: float = DEFAULT_BASE_DELAY,
) -> None:
    """把 ``value`` 原子写入 ``path``（同目录临时文件 → fsync → 原子替换）。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        replace_with_retry(temporary, path, attempts=attempts, base_delay=base_delay)
    except BaseException:
        with suppress(FileNotFoundError):
            os.unlink(temporary)
        raise
