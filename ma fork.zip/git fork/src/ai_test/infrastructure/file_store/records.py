"""Immutable record storage over one workspace directory.

索引方案见 ``docs/adr/ADR-001-record-index-chunking.md``（Stage 0 冻结，本文件即其实现）::

    <workspace>/
    ├── current.json                        # 指针：schema_version / generation / writer_epoch
    ├── generations/<generation>/
    │   ├── state.json                      # 只存：修订、writer_epoch、额度、每个 kind 的块入口
    │   ├── blocks/<kind>/<NNNNNN>.json      # 索引块：≤ block_size 条摘要，封块后不可变
    │   ├── records/<kind>/<id>/r########.json
    │   └── traces/seg-NNNNNN.jsonl          # 限长段（由上层写入，见 ADR-001 §3）
    ├── objects/sha256/<xx>/<digest>
    └── .locks/writer.lock

四条关键性质（对应 ADR-001 的不变量）：

1. ``state.json`` 的大小**只与 kind 数量有关**，与记录总数无关；
2. 一次 ``put`` 只重写**一个**索引块（外加不可变记录与 state 入口）；
3. ``index_page`` 只读"指针 + 入口 + 命中块"，读取文件数不随总量增长；
4. 记录正文的定位不依赖索引遍历：``records/<kind>/<id>/r########.json`` 的文件名自带
   修订号，因此 ``get`` 与修订校验只需列一次该记录的目录（自愈：索引损坏也能读单条）。

与 v1 的差异：``aatp.workspace-state/1.0`` 把每条记录内嵌在 state.json 里，本实现使用
``/2.0``；遇到 1.0 工作空间会**拒绝读取**并提示迁移（ADR-003：旧/未知版本不猜结构），
迁移器属 M1 第④片。
"""

from __future__ import annotations

import json
import os
import re
import tempfile
from collections.abc import Iterator
from contextlib import contextmanager, suppress
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, cast

from ai_test.application.errors import StaleRevision, WorkspaceNotReady
from ai_test.application.ports.storage import IndexEntry, IndexPage
from ai_test.application.ports.system import DEGRADED, HEALTHY, NOT_READY, WorkspaceCheck
from ai_test.infrastructure.file_store.atomic import write_json
from ai_test.infrastructure.file_store.locks import WriterLease

#: 保留旧名以兼容既有调用方（错误类型本身已上移到 application 层，见审查 P2-8）。
ConflictError = StaleRevision

STATE_SCHEMA = "aatp.workspace-state/2.0"
POINTER_SCHEMA = "aatp.workspace-pointer/1.0"
BLOCK_SCHEMA = "aatp.index-block/1.0"
INITIAL_GENERATION = "gen-000001"
DEFAULT_BLOCK_SIZE = 200
MAX_PAGE_LIMIT = 200
#: doctor 校验块链的上限，避免诊断本身退化成全量扫描
MAX_DOCTOR_BLOCKS = 50
_RECORD_FILE = re.compile(r"^r(\d{8})\.json$")


#: 类里定义了 `list` 方法，会遮蔽内建 `list`；模块级别名让类型标注仍可用。
_StrList = list[str]


def _schema_version_of(value: object) -> str:
    """Best-effort ``schema_version`` for error details; never raises."""
    if isinstance(value, dict):
        return str(value.get("schema_version", ""))
    return ""


class FileRecordRepository:
    """单工作空间的记录存储：分块索引 + 不可变记录 + 写入租约。"""

    STATE_SCHEMA = STATE_SCHEMA
    POINTER_SCHEMA = POINTER_SCHEMA
    BLOCK_SCHEMA = BLOCK_SCHEMA
    INITIAL_GENERATION = INITIAL_GENERATION

    def __init__(
        self,
        workspace: Path,
        *,
        lock_timeout_seconds: float = 10.0,
        block_size: int = DEFAULT_BLOCK_SIZE,
    ) -> None:
        self.workspace = Path(workspace).expanduser().resolve()
        self.generations = self.workspace / "generations"
        self.current_file = self.workspace / "current.json"
        self.block_size = max(1, int(block_size))
        self._lease = WriterLease(
            self.workspace / ".locks" / "writer.lock", lock_timeout_seconds
        )

    # ------------------------------------------------------------------ setup

    def initialize(self) -> None:
        """创建布局；仅在为空的工作空间里创建 generation 1。

        指针缺失但已有 generation 数据时抛 ``WorkspaceNotReady``：这种状态需要显式恢复，
        绝不能用空索引覆盖（P1-9 的回归测试守护这条性质）。
        """
        self._ensure_layout()
        if self.current_file.exists():
            return
        with self._lease.acquire():
            if self.current_file.exists():
                return
            self._create_initial_generation()

    def _ensure_layout(self) -> None:
        self.workspace.mkdir(parents=True, exist_ok=True)
        (self.workspace / "objects" / "sha256").mkdir(parents=True, exist_ok=True)
        self.generations.mkdir(parents=True, exist_ok=True)
        (self.workspace / ".locks").mkdir(parents=True, exist_ok=True)

    def _create_initial_generation(self) -> None:
        occupied = self._occupied_generations()
        if occupied:
            raise WorkspaceNotReady(
                "workspace pointer (current.json) is missing but generation data exists; "
                "refusing to overwrite the record index",
                details={"reason": "POINTER_MISSING_WITH_DATA", "generations": occupied},
            )
        state = {
            "schema_version": self.STATE_SCHEMA,
            "revision": 0,
            "writer_epoch": 0,
            "quotas": {},
            "blocks": {},
        }
        write_json(self._state_file(self.INITIAL_GENERATION), state)
        write_json(
            self.current_file,
            {
                "schema_version": self.POINTER_SCHEMA,
                "generation": self.INITIAL_GENERATION,
                "writer_epoch": 0,
            },
        )

    def _occupied_generations(self) -> list[str]:
        if not self.generations.exists():
            return []
        occupied: list[str] = []
        for directory in sorted(self.generations.iterdir()):
            if directory.is_dir() and any(path.is_file() for path in directory.rglob("*")):
                occupied.append(directory.name)
        return occupied

    # ------------------------------------------------------------------ reads

    def get(self, kind: str, record_id: str) -> dict[str, Any] | None:
        """读取一条记录的最新修订。

        定位走文件名约定（``r########.json``），不遍历索引块，因此成本与工作空间总量无关，
        索引块缺失也能读（自愈）。版本门禁仍生效：state 不可读或结构不受支持时拒绝读取。
        """
        self._validate_segment(kind, "kind")
        self._validate_segment(record_id, "record_id")
        generation = self._read_pointer()
        self._read_state(generation)
        path = self._latest_record_path(generation, kind, record_id)
        if path is None:
            return None
        return self._read_record(path)

    def list(self, kind: str) -> Iterator[dict[str, Any]]:
        """全量迭代某 kind 的记录（最新修订优先，同一 key 只出现一次）。

        这是"全量扫描"口径：会读取该 kind 的所有块与记录正文。页面查询请用
        ``index_page``（ADR-001：查询不得随总量线性增长）。
        """
        state, generation = self._load_state()
        for relative in self._entry_paths(generation, kind, state):
            path = self.workspace / relative
            self._ensure_inside_workspace(path)
            yield self._read_record(path)

    def index_page(
        self,
        kind: str,
        *,
        limit: int = MAX_PAGE_LIMIT,
        cursor: str | None = None,
    ) -> IndexPage:
        """读取一页索引摘要：只打开指针、state 与命中的块。"""
        self._validate_segment(kind, "kind")
        size = max(1, min(int(limit), MAX_PAGE_LIMIT))
        state, generation = self._load_state()

        block_relative: str | None
        offset = 0
        if cursor:
            block_relative, offset = self._parse_cursor(cursor)
        else:
            descriptor = state["blocks"].get(kind)
            block_relative = (
                str(descriptor["file"])
                if isinstance(descriptor, dict) and descriptor.get("file")
                else None
            )

        items: list[IndexEntry] = []
        seen: set[str] = set()
        next_cursor: str | None = None
        while block_relative is not None:
            block = self._read_block(generation, block_relative)
            entries: dict[str, Any] = cast(dict[str, Any], block["entries"])
            names = sorted(entries)
            position = offset
            offset = 0
            while position < len(names) and len(items) < size:
                name = names[position]
                position += 1
                if name in seen:
                    continue
                seen.add(name)
                entry = entries[name]
                items.append(
                    IndexEntry(
                        key=name,
                        kind=kind,
                        record_id=name.split("/", 1)[-1],
                        revision=int(entry["revision"]),
                        path=str(entry["path"]),
                    )
                )
            if len(items) < size:
                block_relative = self._next_of(block)
                continue
            # 页满：本块还有剩就停在块内，否则指向下一个块的起点；链尾则结束。
            if position < len(names):
                next_cursor = self._cursor(block_relative, position)
            else:
                following = self._next_of(block)
                next_cursor = self._cursor(following, 0) if following else None
            break
        return IndexPage(kind=kind, items=tuple(items), next_cursor=next_cursor)

    # ------------------------------------------------------------------ write

    def put(
        self,
        kind: str,
        record_id: str,
        payload: dict[str, Any],
        *,
        expected_revision: int | None = None,
        lease_held: bool = False,
        epoch: int | None = None,
    ) -> int:
        """写入一条记录的新修订。

        ``lease_held=True`` 表示调用方（写入协调者）已经持有本工作空间的租约，
        此时不再重复加锁（锁非重入，ADR-002）；``epoch`` 非空时会在提交前核对
        ``writer_epoch``，不一致即拒绝（旧协调者的迟到提交）。
        """
        self._validate_segment(kind, "kind")
        self._validate_segment(record_id, "record_id")
        self._ensure_layout()
        if lease_held:
            return self._commit(kind, record_id, payload, expected_revision, epoch)
        with self._lease.acquire():
            return self._commit(kind, record_id, payload, expected_revision, epoch)

    def _commit(
        self,
        kind: str,
        record_id: str,
        payload: dict[str, Any],
        expected_revision: int | None,
        epoch: int | None,
    ) -> int:
        if not self.current_file.exists():
            self._create_initial_generation()
        pointer = self._read_pointer_document()
        generation = str(pointer["generation"])
        current_epoch = int(pointer.get("writer_epoch", 0))
        if epoch is not None and epoch != current_epoch:
            raise StaleRevision(
                "this writer no longer owns the workspace (writer_epoch changed)",
                details={
                    "reason": "OLD_WRITER_EPOCH",
                    "writer_epoch": epoch,
                    "current_epoch": current_epoch,
                },
            )
        state = self._read_state(generation)
        actual_revision = self._current_revision(generation, kind, record_id)
        if expected_revision is not None and expected_revision != actual_revision:
            raise StaleRevision(
                f"expected revision {expected_revision}, found {actual_revision}",
                details={
                    "kind": kind,
                    "record_id": record_id,
                    "expected_revision": expected_revision,
                    "actual_revision": actual_revision,
                },
            )
        revision = actual_revision + 1
        document = deepcopy(payload)
        document["revision"] = revision
        relative = (
            Path("generations")
            / generation
            / "records"
            / kind
            / record_id
            / f"r{revision:08d}.json"
        )
        # 先规划块（此步会读取现有块，索引不可读时**在写入任何东西之前**失败），
        # 再依次写：不可变记录 → 索引块 → state 入口。
        block_relative, block_document, descriptor = self._plan_block(
            generation, state, kind, self._key(kind, record_id), revision, relative
        )
        write_json(self.workspace / relative, document)
        write_json(self._generation_dir(generation) / block_relative, block_document)
        blocks: dict[str, Any] = cast(dict[str, Any], state["blocks"])
        blocks[kind] = descriptor
        state["revision"] = int(state["revision"]) + 1
        # ADR-002 §2：每次提交把 writer_epoch 写入状态（与 current.json 一致）
        state["writer_epoch"] = current_epoch
        write_json(self._state_file(generation), state)
        return revision

    # ------------------------------------------------------------ unit of work

    @contextmanager
    def unit_of_work(
        self,
        *,
        lease_held: bool = False,
        epoch: int | None = None,
    ) -> Iterator[WorkspaceUnit]:
        """打开一次工作单元（批量提交）。

        工作单元退出时**不会自动提交**：调用方显式 ``flush()`` 才落盘；不调用即等于
        什么都没发生（暂存阶段不写任何文件）。``lease_held=True`` 表示调用方已持有租约
        （写入协调者），此时不重复加锁（锁非重入）。
        """
        if lease_held:
            yield self._open_unit(epoch)
            return
        self._ensure_layout()
        with self._lease.acquire():
            yield self._open_unit(epoch)

    def _open_unit(self, epoch: int | None) -> WorkspaceUnit:
        if not self.current_file.exists():
            self._create_initial_generation()
        pointer = self._read_pointer_document()
        generation = str(pointer["generation"])
        current_epoch = int(pointer.get("writer_epoch", 0))
        if epoch is not None and epoch != current_epoch:
            raise StaleRevision(
                "this writer no longer owns the workspace (writer_epoch changed)",
                details={
                    "reason": "OLD_WRITER_EPOCH",
                    "writer_epoch": epoch,
                    "current_epoch": current_epoch,
                },
            )
        return WorkspaceUnit(self, generation, self._read_state(generation), epoch)

    def _plan_block(
        self,
        generation: str,
        state: dict[str, Any],
        kind: str,
        key: str,
        revision: int,
        record_relative: Path,
    ) -> tuple[str, dict[str, Any], dict[str, Any]]:
        """规划本次提交要写的索引块；块满则封块并新建（旧块保持不可变）。"""
        descriptor = state["blocks"].get(kind) if isinstance(state["blocks"], dict) else None
        current_file = (
            str(descriptor["file"])
            if isinstance(descriptor, dict) and descriptor.get("file")
            else None
        )
        previous_file = (
            str(descriptor["next"])
            if isinstance(descriptor, dict) and descriptor.get("next")
            else None
        )
        entries = self._read_block_entries(generation, current_file) if current_file else {}
        if current_file is None or (len(entries) >= self.block_size and key not in entries):
            previous_file = current_file
            current_file = self._next_block_path(generation, kind, current_file)
            entries = {}
        entries[key] = {"revision": revision, "path": record_relative.as_posix()}
        block_document = {
            "schema_version": BLOCK_SCHEMA,
            "kind": kind,
            "created_revision": int(state["revision"]) + 1,
            "next": previous_file,
            "entries": entries,
        }
        descriptor_out = {"file": current_file, "count": len(entries), "next": previous_file}
        return current_file, block_document, descriptor_out

    def _next_block_path(self, generation: str, kind: str, current_file: str | None) -> str:
        directory = self._generation_dir(generation) / "blocks" / kind
        sequence = 1
        if current_file:
            match = re.search(r"(\d+)\.json$", current_file)
            sequence = int(match.group(1)) + 1 if match else 1
        while (directory / f"{sequence:06d}.json").exists():
            sequence += 1
        return (Path("blocks") / kind / f"{sequence:06d}.json").as_posix()

    def _current_revision(self, generation: str, kind: str, record_id: str) -> int:
        directory = self._generation_dir(generation) / "records" / kind / record_id
        if not directory.is_dir():
            return 0
        highest = 0
        for candidate in directory.iterdir():
            match = _RECORD_FILE.match(candidate.name)
            if match:
                highest = max(highest, int(match.group(1)))
        return highest

    def _latest_record_path(self, generation: str, kind: str, record_id: str) -> Path | None:
        directory = self._generation_dir(generation) / "records" / kind / record_id
        if not directory.is_dir():
            return None
        best: Path | None = None
        best_revision = -1
        for candidate in directory.iterdir():
            match = _RECORD_FILE.match(candidate.name)
            if match and int(match.group(1)) > best_revision:
                best, best_revision = candidate, int(match.group(1))
        return best

    def _read_record(self, path: Path) -> dict[str, Any]:
        self._ensure_inside_workspace(path)
        with path.open("r", encoding="utf-8") as handle:
            return cast(dict[str, Any], json.load(handle))

    # ------------------------------------------------------------------ index

    def _entry_paths(self, generation: str, kind: str, state: dict[str, Any]) -> _StrList:
        """按"最新块优先"遍历索引链，返回每个 key 最新修订的记录路径。"""
        descriptor = state["blocks"].get(kind) if isinstance(state["blocks"], dict) else None
        block_relative = (
            str(descriptor["file"])
            if isinstance(descriptor, dict) and descriptor.get("file")
            else None
        )
        seen: set[str] = set()
        paths: list[str] = []
        while block_relative is not None:
            block = self._read_block(generation, block_relative)
            entries: dict[str, Any] = cast(dict[str, Any], block["entries"])
            for name in sorted(entries):
                if name in seen:
                    continue
                seen.add(name)
                paths.append(str(entries[name]["path"]))
            block_relative = self._next_of(block)
        return paths

    def _read_block(self, generation: str, block_relative: str) -> dict[str, Any]:
        path = self._generation_dir(generation) / block_relative
        if not path.exists():
            raise WorkspaceNotReady(
                "record index block is missing",
                details={"reason": "INDEX_BLOCK_MISSING", "block": block_relative},
            )
        try:
            block = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise WorkspaceNotReady(
                "record index block is unreadable or not valid JSON",
                details={"reason": "INDEX_BLOCK_UNREADABLE", "block": block_relative},
            ) from error
        if not isinstance(block, dict) or block.get("schema_version") != BLOCK_SCHEMA:
            raise WorkspaceNotReady(
                "record index block uses an unsupported schema_version",
                details={
                    "reason": "INDEX_BLOCK_SCHEMA_UNSUPPORTED",
                    "block": block_relative,
                    "expected": BLOCK_SCHEMA,
                    "found": _schema_version_of(block),
                },
            )
        if not isinstance(block.get("entries"), dict):
            raise WorkspaceNotReady(
                "record index block has no entries map",
                details={"reason": "INDEX_BLOCK_ENTRIES_MISSING", "block": block_relative},
            )
        return block

    def _read_block_entries(self, generation: str, block_relative: str) -> dict[str, Any]:
        block = self._read_block(generation, block_relative)
        return dict(cast(dict[str, Any], block["entries"]))

    @staticmethod
    def _next_of(block: dict[str, Any]) -> str | None:
        value = block.get("next")
        return str(value) if value else None

    @staticmethod
    def _cursor(block_relative: str, offset: int) -> str:
        return f"{block_relative}#{offset}"

    @staticmethod
    def _parse_cursor(cursor: str) -> tuple[str, int]:
        block_relative, _, offset = cursor.rpartition("#")
        if not block_relative or not offset.isdigit():
            raise ValueError("invalid index cursor")
        return block_relative, int(offset)

    # ------------------------------------------------------------------ state

    def _state_file(self, generation: str) -> Path:
        return self._generation_dir(generation) / "state.json"

    def _generation_dir(self, generation: str) -> Path:
        self._validate_segment(generation, "generation")
        return self.generations / generation

    def _load_state(self) -> tuple[dict[str, Any], str]:
        """读取指针与状态。只读：不初始化、不修复、不建目录。"""
        generation = self._read_pointer()
        return self._read_state(generation), generation

    def _read_pointer_document(self) -> dict[str, Any]:
        """读取并校验指针文档（generation + writer_epoch 的来源）。"""
        if not self.current_file.exists():
            raise WorkspaceNotReady(
                "workspace is not initialized: current.json is missing",
                details={"reason": "NOT_INITIALIZED", "hint": "run: aitest init"},
            )
        try:
            pointer = json.loads(self.current_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise WorkspaceNotReady(
                "workspace pointer current.json is unreadable or not valid JSON",
                details={"reason": "POINTER_UNREADABLE"},
            ) from error
        found = _schema_version_of(pointer)
        if not isinstance(pointer, dict) or pointer.get("schema_version") != POINTER_SCHEMA:
            raise WorkspaceNotReady(
                "workspace pointer uses an unsupported schema_version",
                details={
                    "reason": "POINTER_SCHEMA_UNSUPPORTED",
                    "expected": POINTER_SCHEMA,
                    "found": found,
                },
            )
        self._validate_segment(str(pointer.get("generation", "")), "generation")
        return pointer

    def _read_pointer(self) -> str:
        return str(self._read_pointer_document()["generation"])

    def read_writer_epoch(self) -> int:
        """当前指针里的 ``writer_epoch``（0 表示尚未有协调者递增过）。"""
        return int(self._read_pointer_document().get("writer_epoch", 0))

    def set_writer_epoch(self, epoch: int) -> None:
        """原子更新指针中的 ``writer_epoch``（由协调者在取得租约后调用，ADR-002 §2）。"""
        pointer = self._read_pointer_document()
        pointer["writer_epoch"] = int(epoch)
        write_json(self.current_file, pointer)

    def _read_state(self, generation: str) -> dict[str, Any]:
        state_file = self._state_file(generation)
        if not state_file.exists():
            raise WorkspaceNotReady(
                "workspace state for the current generation is missing",
                details={"reason": "STATE_MISSING", "generation": generation},
            )
        try:
            state = json.loads(state_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise WorkspaceNotReady(
                "workspace state is unreadable or not valid JSON",
                details={"reason": "STATE_UNREADABLE", "generation": generation},
            ) from error
        if not isinstance(state, dict) or state.get("schema_version") != self.STATE_SCHEMA:
            raise WorkspaceNotReady(
                "workspace state uses an unsupported schema_version; refusing to guess",
                details={
                    "reason": "STATE_SCHEMA_UNSUPPORTED",
                    "generation": generation,
                    "expected": self.STATE_SCHEMA,
                    "found": _schema_version_of(state),
                    "hint": "1.0 工作空间需迁移（M1 第④片提供 aitest migrate）",                },
            )
        if not isinstance(state.get("blocks"), dict):
            raise WorkspaceNotReady(
                "workspace state has no block index",
                details={"reason": "STATE_INDEX_MISSING", "generation": generation},
            )
        return state

    # ----------------------------------------------------------------- health

    def inspect(self) -> tuple[WorkspaceCheck, ...]:
        """侧效应为零的工作空间诊断（供 ``aitest doctor`` 使用）。"""
        checks: list[WorkspaceCheck] = []
        if not self.workspace.exists():
            return (
                WorkspaceCheck("workspace", NOT_READY, "workspace directory does not exist"),
            )
        checks.append(WorkspaceCheck("workspace", HEALTHY, "workspace directory exists"))

        missing = [
            name
            for name, path in (
                ("objects/sha256", self.workspace / "objects" / "sha256"),
                ("generations", self.generations),
                (".locks", self.workspace / ".locks"),
            )
            if not path.exists()
        ]
        checks.append(
            WorkspaceCheck(
                "layout",
                HEALTHY if not missing else DEGRADED,
                "layout complete" if not missing else f"missing: {', '.join(missing)}",
            )
        )

        writable = self._probe_writable()
        checks.append(
            WorkspaceCheck(
                "writable",
                HEALTHY if writable else NOT_READY,
                "write probe succeeded" if writable else "workspace is not writable",
            )
        )

        try:
            generation = self._read_pointer()
        except WorkspaceNotReady as error:
            checks.append(WorkspaceCheck("pointer", NOT_READY, error.message))
            return tuple(checks)
        checks.append(WorkspaceCheck("pointer", HEALTHY, f"generation={generation}"))

        try:
            state = self._read_state(generation)
        except WorkspaceNotReady as error:
            checks.append(WorkspaceCheck("state", NOT_READY, error.message))
            return tuple(checks)

        checks.append(
            WorkspaceCheck(
                "state",
                HEALTHY,
                f"revision={state.get('revision')}, kinds={len(state.get('blocks', {}))}",
            )
        )

        index_detail, index_status = self._inspect_index(generation, state)
        checks.append(WorkspaceCheck("index", index_status, index_detail))

        occupied = self._occupied_generations()
        checks.append(
            WorkspaceCheck(
                "generations",
                HEALTHY if len(occupied) <= 1 else DEGRADED,
                f"generations={occupied}" if occupied else "no generation on disk",
            )
        )
        return tuple(checks)

    def _inspect_index(self, generation: str, state: dict[str, Any]) -> tuple[str, str]:
        """校验块链与已提交引用的可读性（每个 kind 最多检查 MAX_DOCTOR_BLOCKS 个块）。"""
        kinds = sorted(state["blocks"]) if isinstance(state["blocks"], dict) else []
        checked_blocks = 0
        checked_entries = 0
        dangling: list[str] = []
        for kind in kinds:
            descriptor = state["blocks"][kind]
            block_relative = (
                str(descriptor["file"])
                if isinstance(descriptor, dict) and descriptor.get("file")
                else None
            )
            while block_relative is not None and checked_blocks < MAX_DOCTOR_BLOCKS:
                try:
                    block = self._read_block(generation, block_relative)
                except WorkspaceNotReady as error:
                    return error.message, NOT_READY
                checked_blocks += 1
                entries = cast(dict[str, Any], block["entries"])
                for name, entry in entries.items():
                    checked_entries += 1
                    if not (self.workspace / str(entry.get("path", ""))).exists():
                        dangling.append(name)
                block_relative = self._next_of(block)
        if dangling:
            return (
                f"{len(dangling)} committed record(s) missing on disk: {sorted(dangling)[:3]}",
                NOT_READY,
            )
        detail = f"kinds={len(kinds)}, blocks_checked={checked_blocks}, entries={checked_entries}"
        if checked_blocks >= MAX_DOCTOR_BLOCKS:
            detail += f"（已达检查上限 {MAX_DOCTOR_BLOCKS}，更早的块未校验）"
        return detail, HEALTHY

    def _probe_writable(self) -> bool:
        descriptor = -1
        temporary = ""
        try:
            descriptor, temporary = tempfile.mkstemp(prefix=".probe.", dir=self.workspace)
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                descriptor = -1
                handle.write("ok")
        except OSError:
            return False
        finally:
            if descriptor != -1:
                with suppress(OSError):
                    os.close(descriptor)
            if temporary:
                with suppress(OSError):
                    os.unlink(temporary)
        return True

    # ----------------------------------------------------------------- helpers

    @staticmethod
    def _validate_segment(value: str, name: str) -> None:
        if not value or value in {".", ".."} or any(char in value for char in "/\\"):
            raise ValueError(f"invalid {name}")

    @staticmethod
    def _key(kind: str, record_id: str) -> str:
        return f"{kind}/{record_id}"

    def _ensure_inside_workspace(self, path: Path) -> None:
        if not path.resolve().is_relative_to(self.workspace):
            raise ValueError("record path escapes workspace")


#: 类里定义了 `list` 方法会遮蔽内建 `list`；模块级别名供类型标注使用。
_IntList = list[int]


@dataclass(frozen=True, slots=True)
class _StagedRecord:
    kind: str
    record_id: str
    key: str
    payload: dict[str, Any]
    revision: int
    relative: Path


class WorkspaceUnit:
    """一次工作单元：在同一租约与同一 ``writer_epoch`` 下批量写入多条记录。

    与逐条 ``put`` 的差别在**提交次数**：记录正文、受影响的索引块与 ``state.json`` 都在
    ``flush()`` 时统一写盘——N 条记录只写一次 state，而不是 N 次。因此队列积压时
    "最后一条的等待时间"从 O(N x 单条提交) 降为"写块 + 一次 state"。

    ``flush()`` 之前会再核对一次 ``writer_epoch``：旧协调者的迟到提交不会留下任何文件。
    """

    def __init__(
        self,
        repository: FileRecordRepository,
        generation: str,
        state: dict[str, Any],
        epoch: int | None,
    ) -> None:
        self._repository = repository
        self._generation = generation
        self._state = state
        self._epoch = epoch
        self._staged: dict[str, _StagedRecord] = {}
        self._order: _StrList = []
        self._current_blocks: dict[str, tuple[str, dict[str, Any]]] = {}
        self._block_documents: dict[str, dict[str, Any]] = {}
        self._descriptors: dict[str, dict[str, Any]] = {}
        self._flushed = False

    @property
    def generation(self) -> str:
        return self._generation

    @property
    def pending(self) -> int:
        return len(self._order)

    def put(
        self,
        kind: str,
        record_id: str,
        payload: dict[str, Any],
        *,
        expected_revision: int | None = None,
    ) -> int:
        """暂存一条记录的新修订，返回它将获得的修订号（``flush`` 时才落盘）。"""
        if self._flushed:
            raise WorkspaceNotReady(
                "workspace unit has already been flushed",
                details={"reason": "UNIT_CLOSED"},
            )
        repository = self._repository
        repository._validate_segment(kind, "kind")
        repository._validate_segment(record_id, "record_id")
        key = repository._key(kind, record_id)
        staged = self._staged.get(key)
        actual = (
            staged.revision
            if staged is not None
            else repository._current_revision(self._generation, kind, record_id)
        )
        if expected_revision is not None and expected_revision != actual:
            raise StaleRevision(
                f"expected revision {expected_revision}, found {actual}",
                details={
                    "kind": kind,
                    "record_id": record_id,
                    "expected_revision": expected_revision,
                    "actual_revision": actual,
                },
            )
        revision = actual + 1
        relative = (
            Path("generations")
            / self._generation
            / "records"
            / kind
            / record_id
            / f"r{revision:08d}.json"
        )
        record = _StagedRecord(
            kind=kind,
            record_id=record_id,
            key=key,
            payload=dict(payload),
            revision=revision,
            relative=relative,
        )
        if staged is None:
            self._order.append(key)
        self._staged[key] = record
        self._stage_in_index(record)
        return revision

    def flush(self) -> _IntList:
        """提交：写记录正文与索引块，然后只写一次 ``state.json``。"""
        if self._flushed:
            raise WorkspaceNotReady(
                "workspace unit has already been flushed",
                details={"reason": "UNIT_CLOSED"},
            )
        repository = self._repository
        if self._epoch is not None:
            current = repository.read_writer_epoch()
            if current != self._epoch:
                raise StaleRevision(
                    "this writer no longer owns the workspace (writer_epoch changed)",
                    details={
                        "reason": "OLD_WRITER_EPOCH",
                        "writer_epoch": self._epoch,
                        "current_epoch": current,
                    },
                )
        revisions: _IntList = []
        for key in self._order:
            staged = self._staged[key]
            document = deepcopy(staged.payload)
            document["revision"] = staged.revision
            write_json(repository.workspace / staged.relative, document)
            revisions.append(staged.revision)
        for block_file, block_document in self._block_documents.items():
            write_json(repository._generation_dir(self._generation) / block_file, block_document)
        blocks: dict[str, Any] = cast(dict[str, Any], self._state["blocks"])
        blocks.update(self._descriptors)
        self._state["revision"] = int(self._state["revision"]) + len(self._order)
        if self._epoch is not None:
            self._state["writer_epoch"] = self._epoch
        write_json(repository._state_file(self._generation), self._state)
        self._flushed = True
        return revisions

    # ----------------------------------------------------------------- helpers

    def _stage_in_index(self, staged: _StagedRecord) -> None:
        repository = self._repository
        block_file, block_document = self._current_block(staged.kind)
        entries: dict[str, Any] = cast(dict[str, Any], block_document["entries"])
        if len(entries) >= repository.block_size and staged.key not in entries:
            # 块满：封块（旧块留在待写集合中不再改动），另起一块
            previous_file = block_file
            block_file = repository._next_block_path(self._generation, staged.kind, block_file)
            block_document = {
                "schema_version": BLOCK_SCHEMA,
                "kind": staged.kind,
                "created_revision": int(self._state["revision"]) + 1,
                "next": previous_file,
                "entries": {},
            }
            self._current_blocks[staged.kind] = (block_file, block_document)
            self._block_documents[block_file] = block_document
            entries = cast(dict[str, Any], block_document["entries"])
        entries[staged.key] = {"revision": staged.revision, "path": staged.relative.as_posix()}
        self._descriptors[staged.kind] = {
            "file": block_file,
            "count": len(entries),
            "next": block_document["next"],
        }

    def _current_block(self, kind: str) -> tuple[str, dict[str, Any]]:
        existing = self._current_blocks.get(kind)
        if existing is not None:
            return existing
        repository = self._repository
        descriptor = (
            self._state["blocks"].get(kind) if isinstance(self._state["blocks"], dict) else None
        )
        block_file = (
            str(descriptor["file"])
            if isinstance(descriptor, dict) and descriptor.get("file")
            else None
        )
        previous = (
            str(descriptor["next"])
            if isinstance(descriptor, dict) and descriptor.get("next")
            else None
        )
        entries = (
            repository._read_block_entries(self._generation, block_file) if block_file else {}
        )
        if block_file is None:
            block_file = repository._next_block_path(self._generation, kind, None)
            entries = {}
        block_document: dict[str, Any] = {
            "schema_version": BLOCK_SCHEMA,
            "kind": kind,
            "created_revision": int(self._state["revision"]) + 1,
            "next": previous,
            "entries": entries,
        }
        self._current_blocks[kind] = (block_file, block_document)
        self._block_documents[block_file] = block_document
        return block_file, block_document
