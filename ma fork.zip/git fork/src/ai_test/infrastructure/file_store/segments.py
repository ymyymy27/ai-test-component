"""限长段式日志（ADR-001 §3）：事件与链路节点按段存储。

* 段文件：``<generation>/streams/<kind>/seg-NNNNNN.jsonl``（一行一条，自带 ``event_id``）；
* 段索引：``<generation>/streams/<kind>/index.json``，记录每段首末 ``event_id``、行数、
  字节与封段标记；
* 达到 ``segment_lines`` 行或 ``segment_bytes`` 字节即封段，后续写入落新段；
* 查询按 ``event_id`` 直接定位命中段：读取文件数 = 1（索引）+ 命中段数，不随总量增长。

``event_id`` 在单个流内单调递增，由本类分配（调用方不必提供）。
"""

from __future__ import annotations

import json
from collections.abc import Iterable
from pathlib import Path
from typing import Any, cast

from ai_test.infrastructure.file_store.atomic import write_json

STREAM_INDEX_SCHEMA = "aatp.stream-index/1.0"
DEFAULT_SEGMENT_LINES = 10_000
DEFAULT_SEGMENT_BYTES = 8 * 1024 * 1024


class SegmentedLog:
    """一个流（kind）的限长段日志。"""

    def __init__(
        self,
        generation_dir: Path,
        kind: str,
        *,
        segment_lines: int = DEFAULT_SEGMENT_LINES,
        segment_bytes: int = DEFAULT_SEGMENT_BYTES,
    ) -> None:
        self.directory = Path(generation_dir) / "streams" / kind
        self.index_file = self.directory / "index.json"
        self.kind = kind
        self.segment_lines = max(1, int(segment_lines))
        self.segment_bytes = max(1, int(segment_bytes))

    # ------------------------------------------------------------------ write

    def append(self, payloads: Iterable[dict[str, Any]]) -> dict[str, Any]:
        """追加一批记录；返回追加条数、末尾 event_id 与段数。"""
        index = self._load_index()
        appended = 0
        buffer: list[str] = []
        buffer_bytes = 0
        segment: dict[str, Any] | None = None

        for payload in payloads:
            if segment is None or segment.get("sealed"):
                segment = self._current_segment(index)
            entry = dict(payload)
            entry["event_id"] = int(index["next_id"])
            line = json.dumps(entry, ensure_ascii=False, sort_keys=True) + "\n"
            encoded = len(line.encode("utf-8"))
            buffer.append(line)
            buffer_bytes += encoded
            index["next_id"] = int(index["next_id"]) + 1
            segment["last_id"] = entry["event_id"]
            segment["lines"] = int(segment["lines"]) + 1
            appended += 1
            if len(buffer) >= self.segment_lines or buffer_bytes >= self.segment_bytes:
                self._flush(segment, buffer, buffer_bytes)
                buffer, buffer_bytes = [], 0
                segment["sealed"] = True

        if buffer and segment is not None:
            self._flush(segment, buffer, buffer_bytes)

        self._save_index(index)
        return {
            "appended": appended,
            "last_id": int(index["next_id"]) - 1,
            "segments": len(index["segments"]),
            "sealed": bool(index["segments"] and index["segments"][-1].get("sealed")),
        }

    def _flush(self, segment: dict[str, Any], buffer: list[str], byte_count: int) -> None:
        segment["bytes"] = int(segment["bytes"]) + byte_count
        if not buffer:
            return
        self.directory.mkdir(parents=True, exist_ok=True)
        with (self.directory / str(segment["file"])).open(
            "a", encoding="utf-8", newline="\n"
        ) as handle:
            handle.writelines(buffer)

    # ------------------------------------------------------------------- read

    def read(self, *, after_id: int = -1, limit: int = 200) -> tuple[dict[str, Any], ...]:
        """按 ``event_id`` 顺序读取一页；只打开索引与命中的段。"""
        size = max(1, int(limit))
        target = int(after_id) + 1
        index = self._load_index()
        collected: list[dict[str, Any]] = []
        for segment in index["segments"]:
            if int(segment["last_id"]) < target:
                continue
            path = self.directory / str(segment["file"])
            if not path.exists():
                continue
            with path.open("r", encoding="utf-8") as handle:
                for raw in handle:
                    text = raw.strip()
                    if not text:
                        continue
                    entry = cast(dict[str, Any], json.loads(text))
                    if int(entry.get("event_id", -1)) < target:
                        continue
                    collected.append(entry)
                    if len(collected) >= size:
                        return tuple(collected)
        return tuple(collected)

    # ------------------------------------------------------------------ stats

    def segments(self) -> tuple[dict[str, Any], ...]:
        return tuple(self._load_index()["segments"])

    def stats(self) -> dict[str, Any]:
        index = self._load_index()
        return {
            "kind": self.kind,
            "segments": len(index["segments"]),
            "sealed_segments": sum(1 for s in index["segments"] if s.get("sealed")),
            "lines": sum(int(s["lines"]) for s in index["segments"]),
            "bytes": sum(int(s["bytes"]) for s in index["segments"]),
            "next_id": int(index["next_id"]),
        }

    # ----------------------------------------------------------------- helpers

    def _load_index(self) -> dict[str, Any]:
        if not self.index_file.exists():
            return {
                "schema_version": STREAM_INDEX_SCHEMA,
                "kind": self.kind,
                "segment_lines": self.segment_lines,
                "segment_bytes": self.segment_bytes,
                "next_id": 0,
                "segments": [],
            }
        index = cast(
            dict[str, Any], json.loads(self.index_file.read_text(encoding="utf-8"))
        )
        if index.get("schema_version") != STREAM_INDEX_SCHEMA:
            raise ValueError("unsupported stream index schema_version")
        if not isinstance(index.get("segments"), list):
            raise ValueError("stream index has no segments list")
        return index

    def _save_index(self, index: dict[str, Any]) -> None:
        write_json(self.index_file, index)

    @staticmethod
    def _current_segment(index: dict[str, Any]) -> dict[str, Any]:
        """返回当前可写段；上一段已封或没有段时新建。"""
        segments: list[dict[str, Any]] = cast(list[dict[str, Any]], index["segments"])
        if segments and not segments[-1].get("sealed"):
            return segments[-1]
        sequence = len(segments) + 1
        first_id = int(index["next_id"])
        segment: dict[str, Any] = {
            "file": f"seg-{sequence:06d}.jsonl",
            "first_id": first_id,
            "last_id": first_id - 1,
            "lines": 0,
            "bytes": 0,
            "sealed": False,
        }
        segments.append(segment)
        return segment
