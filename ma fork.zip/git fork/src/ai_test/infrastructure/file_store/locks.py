"""Writer lease and sidecar diagnostics (ADR-002).

* ``.locks/writer.lock`` —— OS 级互斥，唯一权威：进程异常退出后由操作系统释放；
* ``.locks/writer.json`` —— 只作诊断的侧车元数据（instance/pid/host/取得时间/心跳/epoch）。
  **遗留的元数据不代表仍持锁**；任何"清理锁文件"的动作都必须以成功取得 OS 锁且确认原进程
  不存在为前提（ADR-002 §1）。

取不到租约时抛 ``WorkspaceInUse``（标准错误码 ``WORKSPACE_IN_USE``），并附带**脱敏**的持有者诊断：
只有实例编号、进程号、主机名、取得时间、心跳年龄与 epoch，不含路径与凭据。
"""

from __future__ import annotations

import json
import socket
from collections.abc import Iterator
from contextlib import contextmanager, suppress
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from ai_test.application.errors import WorkspaceInUse
from ai_test.infrastructure.file_store.atomic import write_json

HOLDER_FILE = "writer.json"

#: 本进程的近似启动时间（模块导入时刻）。用于判断"持有者是否换了进程"，
#: 判活始终以 OS 锁为准。
PROCESS_STARTED_AT = datetime.now(UTC).isoformat(timespec="seconds")


def utc_now() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds")


def parse_utc(value: str) -> datetime | None:
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)


def age_seconds(value: str) -> float | None:
    """给定 ISO 时间距今的秒数；无法解析时返回 None。"""
    parsed = parse_utc(value)
    if parsed is None:
        return None
    return (datetime.now(UTC) - parsed).total_seconds()


@dataclass(frozen=True, slots=True)
class WriterHolder:
    instance_id: str
    pid: int
    host: str
    process_started_at: str
    acquired_at: str
    heartbeat_at: str
    writer_epoch: int

    def as_dict(self) -> dict[str, Any]:
        return {
            "instance_id": self.instance_id,
            "pid": self.pid,
            "host": self.host,
            "process_started_at": self.process_started_at,
            "acquired_at": self.acquired_at,
            "heartbeat_at": self.heartbeat_at,
            "writer_epoch": self.writer_epoch,
        }

    def sanitized(self) -> dict[str, Any]:
        """对外诊断信息：不含路径与凭据。"""
        data = self.as_dict()
        heartbeat_age = age_seconds(self.heartbeat_at)
        if heartbeat_age is not None:
            data["heartbeat_age_seconds"] = round(heartbeat_age, 1)
        return data

    @classmethod
    def from_dict(cls, raw: object) -> WriterHolder | None:
        if not isinstance(raw, dict):
            return None
        try:
            return cls(
                instance_id=str(raw["instance_id"]),
                pid=int(raw["pid"]),
                host=str(raw.get("host", "")),
                process_started_at=str(raw.get("process_started_at", "")),
                acquired_at=str(raw.get("acquired_at", "")),
                heartbeat_at=str(raw.get("heartbeat_at", "")),
                writer_epoch=int(raw.get("writer_epoch", 0)),
            )
        except (KeyError, TypeError, ValueError):
            return None


def holder_path(lease_path: Path) -> Path:
    return lease_path.with_name(HOLDER_FILE)


def read_holder(lease_path: Path) -> WriterHolder | None:
    path = holder_path(lease_path)
    if not path.exists():
        return None
    try:
        return WriterHolder.from_dict(json.loads(path.read_text(encoding="utf-8")))
    except (OSError, json.JSONDecodeError):
        return None


def write_holder(lease_path: Path, holder: WriterHolder) -> None:
    write_json(holder_path(lease_path), holder.as_dict())


def clear_holder(lease_path: Path) -> None:
    with suppress(OSError):
        holder_path(lease_path).unlink()


def current_host() -> str:
    return socket.gethostname()


class WriterLease:
    """Bounded cross-process writer lock backed by portalocker."""

    def __init__(self, path: Path, timeout_seconds: float = 10.0) -> None:
        self.path = path
        self.timeout_seconds = timeout_seconds

    @contextmanager
    def acquire(self) -> Iterator[None]:
        import portalocker

        self.path.parent.mkdir(parents=True, exist_ok=True)
        lock = portalocker.Lock(
            str(self.path),
            mode="a",
            timeout=self.timeout_seconds,
            flags=portalocker.LOCK_EX | portalocker.LOCK_NB,
        )
        try:
            lock.acquire()
        except portalocker.exceptions.LockException as error:
            holder = read_holder(self.path)
            raise WorkspaceInUse(
                "workspace writer lease is held by another writer",
                details={
                    "holder": holder.sanitized() if holder else None,
                    "timeout_seconds": self.timeout_seconds,
                },
            ) from error
        try:
            yield
        finally:
            lock.release()
