"""工作空间结构版本与迁移计划（ADR-003；迁移器本体属 M1 第④片）。

注意：``supported_workspace_schema()`` **必须由当前实现的结构常量驱动**，不能写死字符串 ——
索引结构升到 ``aatp.workspace-state/2.0``（ADR-001）后，写死的 "1.0" 会让迁移器与门禁都判错版本。
"""

from dataclasses import dataclass

from ai_test.infrastructure.file_store.records import STATE_SCHEMA

#: 迁移器需要理解的**旧**结构版本（2.0 是当前版本，不在其中）
SOURCE_SCHEMAS: tuple[str, ...] = ("aatp.workspace-state/1.0",)


@dataclass(frozen=True, slots=True)
class MigrationPlan:
    source_version: str
    target_version: str
    dry_run: bool = True


def supported_workspace_schema() -> str:
    """当前实现支持的工作空间结构版本。"""
    return STATE_SCHEMA


def needs_migration(found_version: str) -> bool:
    """给定工作空间的结构版本是否需要迁移（当前版本之外的旧版本都需要）。"""
    return found_version in SOURCE_SCHEMAS
