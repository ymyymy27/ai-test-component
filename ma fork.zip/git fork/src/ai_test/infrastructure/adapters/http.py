"""HTTP testing adapter boundary."""

