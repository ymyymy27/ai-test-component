"""Source-control adapter boundary."""

