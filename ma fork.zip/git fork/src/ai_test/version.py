"""Single source of the package version.

Kept in a dependency-free module so both ``ai_test.__init__`` and the capability
report can import it without creating an import cycle. When the package is
installed, the value comes from the built distribution metadata (i.e. from
``pyproject.toml``, the real single source); running straight from a source tree
falls back to ``0.1.0``.
"""

from importlib.metadata import PackageNotFoundError, version

_DISTRIBUTION = "ai-test-component"
_FALLBACK = "0.1.0"


def _resolve_version() -> str:
    try:
        return version(_DISTRIBUTION)
    except PackageNotFoundError:
        return _FALLBACK


__version__ = _resolve_version()
