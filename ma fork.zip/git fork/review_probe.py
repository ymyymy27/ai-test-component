"""代码审查探针：用真实代码路径复现 CODE_REVIEW.md 中的关键发现。

运行方式（仓库根目录）：
    python review_probe.py

说明：
* 只读写 `.review-probe/` 下的临时工作空间，不改动仓库源码。
* Stage 0 之后，F/G/H 三段用于验证修复效果（此前的行为已写入 CODE_REVIEW.md §8）。
"""

from __future__ import annotations

import contextlib
import io
import json
import shutil
import sys
import time
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
PROBE = ROOT / ".review-probe"


def hdr(title: str) -> None:
    print("\n" + "=" * 72)
    print(f"## {title}")
    print("=" * 72)


# ---------------------------------------------------------------- A: 会签顺序依赖
hdr("A) 双人会签判定是否依赖输入顺序（P1-7）")
from ai_test.domain.reports import AcceptanceSignature, has_two_distinct_signers  # noqa: E402

sig_a = AcceptanceSignature("report-A", 1, "hash", "alice")
sig_a2 = AcceptanceSignature("report-A", 1, "hash", "carol")
sig_b = AcceptanceSignature("report-B", 1, "hash", "bob")
print("顺序 [(B,bob),(A,alice),(A,carol)] ->", has_two_distinct_signers((sig_b, sig_a, sig_a2)))
print("顺序 [(A,alice),(A,carol),(B,bob)] ->", has_two_distinct_signers((sig_a, sig_a2, sig_b)))
print("同一人重复签署 [(A,alice),(A,alice)] ->", has_two_distinct_signers((sig_a, sig_a)))
print("空元组 ->", has_two_distinct_signers(()))

# ------------------------------------------------- B: 记录多出未知字段 / 未知 schema
hdr("B) 读记录无容错：未知字段与未知 schema（P1-6）")
from ai_test.application.use_cases.project_context import ProjectContext  # noqa: E402


class _FakeRepo:
    def __init__(self, record: dict[str, object]) -> None:
        self._record = record

    def get(self, kind: str, record_id: str) -> dict[str, object] | None:
        return self._record


future_record = {
    "project_id": "p1",
    "name": "P",
    "schema_version": "aatp.project/1.0",
    "revision": 1,
    "modules": [],
    "operator": "alice",
    "created_at": "2026-01-01T00:00:00Z",
}
try:
    ProjectContext(_FakeRepo(future_record)).get("p1")  # type: ignore[arg-type]
    print("含审计字段的记录：读取成功（有容错）")
except BaseException as error:  # noqa: BLE001
    print(f"含审计字段的记录：读取失败 -> {type(error).__name__}: {error}")

unknown_schema = dict(future_record, schema_version="aatp.project/9.9")
del unknown_schema["operator"]
del unknown_schema["created_at"]
try:
    loaded = ProjectContext(_FakeRepo(unknown_schema)).get("p1")  # type: ignore[arg-type]
    print(f"未知 schema_version：被静默接受 -> {loaded.schema_version!r}")  # type: ignore[union-attr]
except BaseException as error:  # noqa: BLE001
    print(f"未知 schema_version：报错 -> {type(error).__name__}")

# ------------------------------------------------------- C: 面板资源路径穿越
hdr("C) panel.asset_text() 路径穿越（P2-5）")
from ai_test.interfaces.panel import asset_text  # noqa: E402

probes = (
    "index.js",
    "styles.css",
    "../../../../pyproject.toml",
    "../schemas/host-event.schema.json",
)
for name in probes:
    try:
        text = asset_text(name)
        first = text.splitlines()[0][:70] if text.splitlines() else ""
        print(f"  asset_text({name!r}) -> {len(text)} 字节 | 首行: {first!r}")
    except BaseException as error:  # noqa: BLE001
        print(f"  asset_text({name!r}) -> {type(error).__name__}: {error}")

# ---------------------------------------------------------- D: 版本号单一真相
hdr("D) 版本号来源（P1-8）")
import ai_test  # noqa: E402
from ai_test.application.use_cases.capabilities import describe_capabilities  # noqa: E402

pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
print("pyproject.toml :", pyproject["project"]["version"])
print("ai_test.__version__ :", ai_test.__version__)
print("describe_capabilities()['version'] :", describe_capabilities()["version"])

# ------------------------------------------------------------- E: CLI 行为契约
hdr("E) CLI 行为与错误处理（P1-1 / P1-5，Stage 0 后应全部为 JSON 信封 + 固定退出码）")
from ai_test.interfaces import cli  # noqa: E402

WS = PROBE / "ws"
if WS.exists():
    shutil.rmtree(WS)


def run_cli(args: list[str]) -> tuple[object, str]:
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code: object = cli.main(["--workspace", str(WS), *args])
        except SystemExit as exit_error:
            code = f"SystemExit({exit_error.code})"
        except BaseException as error:  # noqa: BLE001
            code = f"{type(error).__name__}: {str(error)[:90]}"
    text = " ".join(out.getvalue().split())[:150]
    return code, text


for args in (
    ["init"],
    ["project-create", "demo", "演示项目"],
    ["project-get", "demo"],
    ["capabilities"],
    ["doctor"],
):
    code, text = run_cli(args)
    print(f"  {' '.join(args):<34} -> exit/异常={code} | {text}")

for label, args in (
    ("重复 project-create", ["project-create", "demo", "重复创建"]),
    ("空 project_id", ["project-create", "", "空 id"]),
    ("project-get 不存在", ["project-get", "not-exist"]),
):
    code, text = run_cli(args)
    print(f"  {label:<34} -> {code} | {text}")

# ------------------------------------------- F: current.json 丢失后的行为
hdr("F) current.json 丢失后是否还会覆盖索引（P1-9，Stage 0 已修）")
state_path = WS / "generations" / "gen-000001" / "state.json"
records_dir = WS / "generations" / "gen-000001" / "records"
before_state = json.loads(state_path.read_text(encoding="utf-8"))
print("丢失前 state.records =", list(before_state["records"]))
print("丢失前 state.revision =", before_state["revision"])
print("丢失前磁盘记录文件 =", sorted(p.name for p in records_dir.rglob("*.json")))

(WS / "current.json").unlink()
print("已删除 current.json（模拟指针丢失 / 备份恢复不完整）")
code, text = run_cli(["project-get", "demo"])
print(f"  再 project-get demo -> exit/异常={code} | {text}")

after_state = json.loads(state_path.read_text(encoding="utf-8"))
print("丢失后 state.records =", list(after_state["records"]))
print("丢失后 state.revision =", after_state["revision"])
unchanged = list(after_state["records"]) == list(before_state["records"])
print(f"判定：索引是否被覆盖 = {not unchanged}（期望 False）")

# ------------------------------------------- G: doctor 在状态损坏时是否仍报 ok
hdr("G) doctor 是否真的做检查（P1-1，Stage 0 已修）")
corrupted = json.loads(state_path.read_text(encoding="utf-8"))
corrupted["schema_version"] = "aatp.workspace-state/0.0-broken"
state_path.write_text(json.dumps(corrupted, indent=2), encoding="utf-8")
print("已把 state.json 的 schema_version 改成:", corrupted["schema_version"])
code, text = run_cli(["doctor"])
print(f"  doctor           -> exit/异常={code} | {text}")
code, text = run_cli(["project-get", "demo"])
print(f"  project-get demo -> exit/异常={code} | {text}")

# ------------------------------------------- H: 持锁状态下再次加锁（锁非重入）
hdr("H) 持锁状态下调用 _load_state()（P2-1，Stage 0 已修）")
from ai_test.infrastructure.file_store.records import FileRecordRepository  # noqa: E402

ws2 = PROBE / "ws2"
repo = FileRecordRepository(ws2, lock_timeout_seconds=0.5)
repo.initialize()
print("initialize() 后 current.json 存在:", (ws2 / "current.json").exists())
(ws2 / "current.json").unlink()
started = time.perf_counter()
try:
    with repo._lease.acquire():
        repo._load_state()
    print("结果：未报错（意外）")
except BaseException as error:  # noqa: BLE001
    elapsed = time.perf_counter() - started
    print(f"结果：{type(error).__name__}: {str(error)[:110]}")
    print(f"耗时 {elapsed:.2f}s（Stage 0 前是锁超时 0.50s，现在是立即报 NOT_INITIALIZED）")

# ------------------------------------------- I: put() 静默覆盖 payload 的 revision
hdr("I) put() 静默覆盖 payload 中的 revision（P2-4，未修，属 M1）")
ws3 = PROBE / "ws3"
repo3 = FileRecordRepository(ws3)
revision = repo3.put("projects", "x", {"name": "n", "revision": 999})
print("put(..., {'revision': 999}) 返回 ->", revision)
print("get() ->", repo3.get("projects", "x"))

# ------------------------------------------- J: list() 的 state 重读次数
hdr("J) list() 的 state 解析次数（P2-2，Stage 0 已改为 1 次）")
ws4 = PROBE / "ws4"
repo4 = FileRecordRepository(ws4)
for index in range(5):
    repo4.put("projects", f"p{index}", {"name": f"n{index}"})
calls = {"count": 0}
original = repo4._load_state


def counting_load_state():  # type: ignore[no-untyped-def]
    calls["count"] += 1
    return original()


repo4._load_state = counting_load_state  # type: ignore[method-assign]
items = list(repo4.list("projects"))
print(f"list() 返回 {len(items)} 条记录，期间 _load_state() 被调用 {calls['count']} 次")

# ------------------------------------------- K: 冲突错误类型所在层 + 重复写入
hdr("K) 冲突错误与版本校验（P2-8，Stage 0 已上移到 application 层）")
from ai_test.application.errors import StaleRevision  # noqa: E402

ws5 = PROBE / "ws5"
repo5 = FileRecordRepository(ws5)
first_revision = repo5.put("projects", "p", {"name": "a"}, expected_revision=0)
print("首次 put(expected_revision=0) ->", first_revision)
try:
    repo5.put("projects", "p", {"name": "b"}, expected_revision=0)
except StaleRevision as error:
    print("陈旧 expected_revision -> StaleRevision:", error)
print("StaleRevision 定义位置:", StaleRevision.__module__, "| code:", StaleRevision.code)

print("\n探针结束。")
