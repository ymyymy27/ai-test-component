"""Exact current snapshot references, immutable history and atomic publication failures."""

from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

import pytest

from aitest.application.execution.commit import ExecutionCommitBatch, ExecutionCommitCoordinator
from aitest.contracts.execution_facts import ExecutionFacts
from aitest.domain.execution.runs import (
    AttemptState,
    RecoveryCheckpoint,
    RecoveryRecord,
    StepRevisionRef,
)
from aitest.infrastructure.file_store.unit_of_work import FileUnitOfWork
from tests.unit.test_serial_runner import _attempt


def _batch():
    facts = ExecutionFacts.model_validate_json(
        (Path(__file__).parents[1] / "contracts/fixtures/execution_facts/success.json").read_text(
            encoding="utf-8"
        )
    )
    step = facts.attempts[0].step_revision_ref
    attempt = replace(
        _attempt(),
        state=AttemptState.COMPLETED,
        step_revision_ref=StepRevisionRef(step.step_revision_id, step.revision_no, step.digest),
    )
    checkpoint = RecoveryRecord(
        RecoveryCheckpoint(attempt.run_id, attempt.step_id, attempt.attempt_id, "completed"),
        attempt,
    )
    return ExecutionCommitBatch(checkpoint=checkpoint, evidence_refs=(), facts=facts)


def _publish(unit, batch, request="publish"):
    unit.begin(request, batch.facts.project_id)
    return ExecutionCommitCoordinator(unit).stage_and_commit(batch)


def test_current_reference_and_snapshot_share_the_actual_boundary_and_preserve_old_revision(
    tmp_path,
):
    unit = FileUnitOfWork(tmp_path)
    first = _publish(unit, _batch(), "first")
    coordinator = ExecutionCommitCoordinator(FileUnitOfWork(tmp_path))
    assert coordinator.read_current_facts(project_id="project-1", run_id="run-1") == first.facts
    assert first.facts.snapshot_cursor == first.committed["commit_sequence"]
    second = _publish(unit, _batch(), "second")
    assert second.facts.snapshot_cursor == second.committed["commit_sequence"]
    assert coordinator.read_current_facts(project_id="project-1", run_id="run-1") == second.facts
    historical = unit.read(
        aggregate_kind="execution_facts", record_id=first.facts.snapshot_commit_id, revision=1
    )
    assert historical.payload == first.facts.model_dump(mode="json")
    assert first.facts.snapshot_commit_id != second.facts.snapshot_commit_id
    assert coordinator.read_current_facts(project_id="foreign", run_id="run-1") is None


@pytest.mark.parametrize("field", ["digest", "snapshot_commit_id", "project_id", "schema_version"])
def test_unverifiable_current_reference_never_falls_back_to_a_successful_history_item(
    tmp_path, monkeypatch, field
):
    unit = FileUnitOfWork(tmp_path)
    _publish(unit, _batch())
    original = unit.read

    def wrong_reference(**kwargs):
        record = original(**kwargs)
        if kwargs["aggregate_kind"] == "execution_facts_current":
            payload = dict(record.payload)
            payload[field] = "unverifiable"
            return SimpleNamespace(payload=payload)
        return record

    monkeypatch.setattr(unit, "read", wrong_reference)
    with pytest.raises((ValueError, KeyError)):
        ExecutionCommitCoordinator(unit).read_current_facts(project_id="project-1", run_id="run-1")


def test_current_snapshot正文_digest_is_verified_after_exact_revision_read(tmp_path, monkeypatch):
    unit = FileUnitOfWork(tmp_path)
    _publish(unit, _batch())
    original = unit.read

    def wrong_bytes(**kwargs):
        record = original(**kwargs)
        if kwargs["aggregate_kind"] == "execution_facts":
            return SimpleNamespace(payload={**record.payload, "facts_id": "altered"})
        return record

    monkeypatch.setattr(unit, "read", wrong_bytes)
    with pytest.raises(ValueError, match="digest"):
        ExecutionCommitCoordinator(unit).read_current_facts(project_id="project-1", run_id="run-1")


def test_failed_snapshot_staging_cannot_publish_the_preceding_pointer_or_checkpoint(
    tmp_path, monkeypatch
):
    unit = FileUnitOfWork(tmp_path)
    first = _publish(unit, _batch(), "first")
    before = unit.current_commit_sequence()
    original = unit.stage_record

    def fail_snapshot(**kwargs):
        if kwargs["aggregate_kind"] == "execution_facts":
            raise OSError("injected snapshot stage failure after pointer")
        return original(**kwargs)

    monkeypatch.setattr(unit, "stage_record", fail_snapshot)
    with pytest.raises(OSError, match="after pointer"):
        _publish(unit, _batch(), "failed")
    assert unit.current_commit_sequence() == before
    assert unit.current_revision(aggregate_kind="execution_checkpoint", record_id="attempt-1") == 1
    assert (
        ExecutionCommitCoordinator(unit).read_current_facts(project_id="project-1", run_id="run-1")
        == first.facts
    )
    assert unit.pending == [] and unit.project is None


@pytest.mark.parametrize("change", ["map", "current_flag", "step_run", "duplicate", "run_revision"])
def test_inconsistent_current_attempt_facts_are_rejected_before_any_publication(tmp_path, change):
    unit, batch = FileUnitOfWork(tmp_path), _batch()
    facts = batch.facts
    changed = {
        "map": facts.model_copy(update={"current_attempt_by_step": {"step-1": None}}),
        "current_flag": facts.model_copy(
            update={"attempts": (facts.attempts[0].model_copy(update={"is_current": False}),)}
        ),
        "step_run": facts.model_copy(
            update={"steps": (facts.steps[0].model_copy(update={"run_id": "foreign"}),)}
        ),
        "duplicate": facts.model_copy(update={"attempts": facts.attempts * 2}),
        "run_revision": facts.model_copy(update={"run_revision": facts.run_revision + 1}),
    }[change]
    with pytest.raises(ValueError, match="execution snapshot"):
        _publish(unit, replace(batch, facts=changed))
    assert unit.current_commit_sequence() == 0
    assert unit.pending == [] and unit.project is None


def test_current_reference_rejects_rebinding_the_frozen_run_intent(tmp_path):
    unit, batch = FileUnitOfWork(tmp_path), _batch()
    first = _publish(unit, batch, "first")
    changed = batch.facts.model_copy(
        update={"run": batch.facts.run.model_copy(update={"intent_id": "foreign-intent"})}
    )
    before = unit.current_commit_sequence()
    with pytest.raises(ValueError, match="frozen run identity"):
        _publish(unit, replace(batch, facts=changed), "rebind")
    assert unit.current_commit_sequence() == before
    assert (
        ExecutionCommitCoordinator(unit).read_current_facts(project_id="project-1", run_id="run-1")
        == first.facts
    )
