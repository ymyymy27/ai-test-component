"""A frozen step reference must resolve to independently saved exact content."""

from tests.unit.test_authoritative_preparation import authoritative as authoritative
from tests.unit.test_authoritative_preparation import prepare
from tests.unit.test_initial_run_registration import register


def test_initial_step_reference_has_actual_content_in_the_same_authority(authoritative):
    core, inputs, _ = authoritative
    prepared = prepare(core, inputs).result
    facts = register(core, prepared)
    for step in facts.steps:
        reference = step.step_revision_ref
        assert core.unit_of_work.repo.current_revision(
            "step_revision", reference.step_revision_id
        ) == reference.revision_no
        record = core.unit_of_work.repo.read(
            aggregate_kind="step_revision", record_id=reference.step_revision_id,
            revision=reference.revision_no,
        )
        assert record.payload["project_id"] == inputs.project_id
        assert record.payload["run_id"] == facts.run_id
        assert record.payload["step_id"] == step.step_id
        assert record.payload["case_content"]["case_id"] == step.case_id
