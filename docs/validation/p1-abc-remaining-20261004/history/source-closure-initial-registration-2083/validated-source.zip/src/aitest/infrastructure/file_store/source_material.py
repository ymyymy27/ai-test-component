"""Read-only checks of immutable source metadata and its actual pinned bytes."""

from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from aitest.infrastructure.security import (
    KnownSecretRegistry,
    UnsafeMaterialError,
    copy_unchanged_safe_bytes,
    guard_value,
)

MAX_METADATA_BYTES = 16 * 1024 * 1024
_SNAPSHOT_ID = re.compile(r"snap-[0-9a-f]{16}\Z")
_HEX = re.compile(r"[0-9a-f]{64}\Z")


class SourceMaterialError(ValueError):
    """No byte-identity or safety claim can be made for this material."""

    code = "COMMIT_MATERIAL_UNVERIFIED"


def reject_links(path: Path) -> None:
    if any(p.is_symlink() or p.is_junction() for p in (path, *path.parents)):
        raise SourceMaterialError("pinned source material path contains a filesystem link")


def metadata_path(root: Path, snapshot_id: str) -> Path:
    if not isinstance(snapshot_id, str) or not _SNAPSHOT_ID.fullmatch(snapshot_id):
        raise SourceMaterialError("pinned source snapshot identity is invalid")
    return root / "snapshots" / f"{snapshot_id}.json"


def _relative(name: object) -> bool:
    return (
        isinstance(name, str)
        and bool(name)
        and not any(ord(c) < 32 for c in name)
        and not any(c in name for c in '\\:*?"<>|')
        and not Path(name).is_absolute()
        and not Path(name).drive
        and all(p not in {"", ".", ".."} for p in name.split("/"))
    )


def _unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise SourceMaterialError("duplicate pinned source metadata field")
        result[key] = value
    return result


def read_metadata(
    root: Path, snapshot_id: str, *, registry: KnownSecretRegistry | None = None
) -> dict[str, Any]:
    path = metadata_path(root, snapshot_id)
    reject_links(path)
    try:
        if path.stat().st_size > MAX_METADATA_BYTES:
            raise SourceMaterialError("pinned source metadata exceeds its read budget")
        with path.open("rb") as stream:
            raw = stream.read(MAX_METADATA_BYTES + 1)
        if len(raw) > MAX_METADATA_BYTES:
            raise SourceMaterialError("pinned source metadata exceeds its read budget")
        record = json.loads(raw, object_pairs_hook=_unique)
    except (OSError, RecursionError, UnicodeError, json.JSONDecodeError) as error:
        raise SourceMaterialError("pinned source metadata is missing or unreadable") from error
    safe, changed = guard_value(record, registry)
    if changed or safe != record:
        raise SourceMaterialError("pinned source metadata cannot preserve safe byte identity")
    if (
        not isinstance(record, dict)
        or record.get("schema") != "aitest.source-snapshot/1.0"
        or record.get("snapshot_id") != snapshot_id
        or not isinstance(record.get("purpose"), str)
        or not record["purpose"]
        or not isinstance(record.get("canonical_path"), str)
        or not Path(record["canonical_path"]).is_absolute()
        or any(ord(c) < 32 for c in record["canonical_path"])
        or not isinstance(record.get("selected_paths"), list)
        or any(not _relative(p) for p in record["selected_paths"])
        or len(set(record["selected_paths"])) != len(record["selected_paths"])
        or not isinstance(record.get("exclusion_rules"), list)
        or any(not _relative(p) for p in record["exclusion_rules"])
        or not isinstance(record.get("files"), list)
    ):
        raise SourceMaterialError("pinned source metadata identity or scope is invalid")
    paths: set[str] = set()
    sizes: dict[str, int] = {}
    for item in record["files"]:
        if (
            not isinstance(item, dict)
            or not _relative(item.get("relative_path"))
            or item["relative_path"] in paths
            or not isinstance(item.get("sha256"), str)
            or not _HEX.fullmatch(item["sha256"])
            or type(item.get("size")) is not int
            or item["size"] < 0
            or item["sha256"] in sizes
            and sizes[item["sha256"]] != item["size"]
        ):
            raise SourceMaterialError("pinned source file reference identity/size is invalid")
        paths.add(item["relative_path"])
        sizes[item["sha256"]] = item["size"]
    identity = json.dumps(
        [
            record[k]
            for k in ("canonical_path", "purpose", "selected_paths", "exclusion_rules", "files")
        ],
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    if "snap-" + hashlib.sha256(identity).hexdigest()[:16] != snapshot_id:
        raise SourceMaterialError("pinned source manifest digest differs from its identity")
    return record


def verify_pinned_material(
    root: Path, snapshot_id: str, *, registry: KnownSecretRegistry | None = None
) -> dict[str, Any]:
    record = read_metadata(root, snapshot_id, registry=registry)
    seen: set[str] = set()
    for item in record["files"]:
        digest, size = item["sha256"], item["size"]
        if digest in seen:
            continue
        seen.add(digest)
        path = root / "snapshots/blobs" / digest
        reject_links(path)
        try:
            if not path.is_file() or path.stat().st_size != size:
                raise SourceMaterialError("pinned source blob is missing or has a different size")
            with path.open("rb") as stream:
                actual, actual_size = copy_unchanged_safe_bytes(stream, registry=registry)
        except (OSError, UnsafeMaterialError) as error:
            raise SourceMaterialError(
                "pinned source blob cannot preserve safe byte identity"
            ) from error
        if actual != digest or actual_size != size:
            raise SourceMaterialError("pinned source blob digest/size mismatch")
    return record


def verify_source_reference(root: Path, body: Mapping[str, object], project_id: str) -> set[str]:
    """Validate an explicit business snapshot; ordinary inline hashes are ignored."""
    if not {"pinned_manifest_digest", "pinned_snapshot_id"}.intersection(body):
        return set()
    snapshot_id = body.get("pinned_snapshot_id")
    if (
        not isinstance(snapshot_id, str)
        or not isinstance(body.get("pinned_manifest_digest"), str)
        or body.get("project_id") != project_id
    ):
        raise SourceMaterialError("pinned source business reference has unknown owner/identity")
    record = verify_pinned_material(root, snapshot_id)
    canonical = json.dumps(
        record, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode("utf-8")
    expected_files = [
        {
            "relative_path": f["relative_path"],
            "size": f["size"],
            "content_digest": "sha256:" + f["sha256"],
        }
        for f in record["files"]
    ]
    selection, exclusions = body.get("selected_paths"), body.get("exclusion_rules")
    if (
        body["pinned_manifest_digest"] != "sha256:" + hashlib.sha256(canonical).hexdigest()
        or body.get("files") != expected_files
        or body.get("purpose") != record["purpose"]
        or not isinstance(selection, (list, tuple))
        or list(selection) != record["selected_paths"]
        or not isinstance(exclusions, (list, tuple))
        or list(exclusions) != record["exclusion_rules"]
    ):
        raise SourceMaterialError("business source snapshot differs from actual pinned material")
    return {
        metadata_path(root, snapshot_id).relative_to(root).as_posix(),
        *("snapshots/blobs/" + f["sha256"] for f in record["files"]),
    }
