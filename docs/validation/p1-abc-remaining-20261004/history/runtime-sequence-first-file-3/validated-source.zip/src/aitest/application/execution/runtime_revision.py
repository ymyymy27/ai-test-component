"""Persisted runtime revision material and exact effective-case provenance."""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from dataclasses import replace
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, TypeAdapter

from aitest.application.execution.step_content import StepContentReader
from aitest.application.planning.draft import text_digest
from aitest.application.planning.publish import payload_digest
from aitest.application.planning.run_mode import request_runtime_revision
from aitest.application.planning.serialization import (
    case_content_digest,
    case_from_payload,
    case_to_payload,
)
from aitest.application.ports import AggregateKind, CommittedRecord, RecordRepository
from aitest.contracts.execution_facts import ExecutionFacts, StepRevisionRefFact
from aitest.contracts.prepared_run import CaseRevisionRef, PlanRevisionRef, RunDriverFact
from aitest.domain.execution.runs import Run, Step, StepLevel, StepRevisionRef
from aitest.domain.planning.plans import Case, Plan, RunDriver
from aitest.domain.planning.plans import CaseRevisionRef as DomainCaseRevisionRef
from aitest.domain.planning.runtime_revision import CaseRuntimeChange, RuntimeRevisionRequest


class SnapshotContentRef(BaseModel):
    model_config = ConfigDict(strict=True, frozen=True, extra="forbid")

    snapshot_commit_id: str = Field(min_length=1)
    snapshot_cursor: int = Field(ge=0)
    digest: str = Field(min_length=1)

    @classmethod
    def of(cls, facts: ExecutionFacts) -> SnapshotContentRef:
        return cls(
            snapshot_commit_id=facts.snapshot_commit_id,
            snapshot_cursor=facts.snapshot_cursor,
            digest=payload_digest(facts.model_dump(mode="json")),
        )


class StepContentChange(BaseModel):
    model_config = ConfigDict(strict=True, frozen=True, extra="forbid")

    step_id: str = Field(min_length=1)
    previous_ref: StepRevisionRefFact
    next_ref: StepRevisionRefFact


class RunRevisionRecord(BaseModel):
    model_config = ConfigDict(strict=True, frozen=True, extra="forbid")

    schema_version: Literal["aitest.run-plan-revision/1.0"]
    record_id: str = Field(min_length=1)
    project_id: str = Field(min_length=1)
    origin_workspace_id: str = Field(min_length=1)
    run_id: str = Field(min_length=1)
    intent_id: str = Field(min_length=1)
    input_digest: str = Field(min_length=1)
    revision_no: int = Field(ge=1)
    previous_revision_ref: str | None
    initial_plan_ref: PlanRevisionRef
    base_snapshot: SnapshotContentRef
    result_snapshot: SnapshotContentRef
    request_payload: dict[str, Any]
    confirmation_ids: tuple[str, ...]
    effective_case_refs: tuple[CaseRevisionRef, ...]
    step_changes: tuple[StepContentChange, ...]
    invalidated_basis_step_ids: tuple[str, ...]
    invalidated_consumer_attempt_ids: tuple[str, ...]
    pause_required: bool
    effective_driver: RunDriverFact
    created_at: datetime

    @property
    def reference(self) -> str:
        return f"run_plan_revision:{self.record_id}@1"


def revision_record_id(project_id: str, run_id: str, intent_id: str) -> str:
    return "run-revision-" + payload_digest([project_id, run_id, intent_id])[7:]


def revision_request_payload(request: RuntimeRevisionRequest, project_id: str) -> dict[str, Any]:
    return {
        "base_plan_revision_id": request.base_plan_revision_id,
        "base_plan_revision_no": request.base_plan_revision_no,
        "base_plan_revision_digest": request.base_plan_revision_digest,
        "observed_snapshot_cursor": request.observed_snapshot_cursor,
        "case_changes": [
            {
                "case_content": case_to_payload(change.next_case, project_id=project_id),
                "target_step_ids": sorted(change.target_step_ids),
                "remove_from_required": change.remove_from_required,
            }
            for change in sorted(request.case_changes, key=lambda change: change.next_case.case_id)
        ],
        "reason": request.reason,
        "operator_ref": request.operator_ref,
        "requested_driver": request.requested_driver.value if request.requested_driver else None,
    }


def request_from_payload(payload: Mapping[str, Any], project_id: str) -> RuntimeRevisionRequest:
    expected = {
        "base_plan_revision_id",
        "base_plan_revision_no",
        "base_plan_revision_digest",
        "observed_snapshot_cursor",
        "case_changes",
        "reason",
        "operator_ref",
        "requested_driver",
    }
    if set(payload) != expected or any(
        type(payload[key]) is not int
        for key in ("base_plan_revision_no", "observed_snapshot_cursor")
    ):
        raise ValueError("runtime revision request shape cannot be verified")
    for key in ("base_plan_revision_id", "reason", "operator_ref"):
        if not isinstance(payload[key], str) or not payload[key].strip():
            raise ValueError("runtime revision request text cannot be verified")
    for key in ("base_plan_revision_digest", "requested_driver"):
        if payload[key] is not None and not isinstance(payload[key], str):
            raise ValueError("runtime revision request reference cannot be verified")
    changes = payload["case_changes"]
    if not isinstance(changes, list):
        raise ValueError("runtime revision changes must be a list")
    parsed = []
    for change in changes:
        if (
            not isinstance(change, dict)
            or set(change) != {"case_content", "target_step_ids", "remove_from_required"}
            or type(change["remove_from_required"]) is not bool
            or not isinstance(change["target_step_ids"], list)
            or any(
                not isinstance(item, str) or not item.strip() for item in change["target_step_ids"]
            )
            or not isinstance(change["case_content"], dict)
            or change["case_content"].get("project_id") != project_id
        ):
            raise ValueError("runtime revision case change cannot be verified")
        parsed.append(
            CaseRuntimeChange(
                case_from_payload(change["case_content"]),
                tuple(change["target_step_ids"]),
                change["remove_from_required"],
            )
        )
    request = RuntimeRevisionRequest(
        base_plan_revision_id=payload["base_plan_revision_id"],
        base_plan_revision_no=payload["base_plan_revision_no"],
        base_plan_revision_digest=payload["base_plan_revision_digest"],
        observed_snapshot_cursor=payload["observed_snapshot_cursor"],
        case_changes=tuple(parsed),
        reason=payload["reason"],
        operator_ref=payload["operator_ref"],
        requested_driver=(
            RunDriver(payload["requested_driver"])
            if payload["requested_driver"] is not None
            else None
        ),
    )
    if revision_request_payload(request, project_id) != dict(payload):
        raise ValueError("runtime revision request is not its canonical complete content")
    return request


def revision_input_digest(
    *,
    project_id: str,
    run_id: str,
    request_payload: Mapping[str, Any],
    confirmation_ids: tuple[str, ...],
) -> str:
    return payload_digest([project_id, run_id, dict(request_payload), sorted(confirmation_ids)])


class SavedRuntimeRevisionReader:
    """Check every saved link; a sequence count cannot establish effective content."""

    def __init__(self, records: RecordRepository) -> None:
        self.records = records

    def _read(self, kind: str, record_id: str, revision: int, project_id: str) -> dict[str, Any]:
        if type(revision) is not int or revision < 1:
            raise ValueError("runtime material requires an exact warehouse revision")
        record = self.records.read(aggregate_kind=kind, record_id=record_id, revision=revision)
        raw_payload = getattr(record, "payload", None)
        if (
            (
                getattr(record, "aggregate_kind", None),
                getattr(record, "record_id", None),
                getattr(record, "revision", None),
            )
            != (kind, record_id, revision)
            or type(getattr(record, "revision", None)) is not int
            or not isinstance(raw_payload, Mapping)
        ):
            raise ValueError("runtime material envelope cannot be verified")
        payload = dict(raw_payload)
        if payload.get("project_id") != project_id:
            raise ValueError("runtime material belongs to another project")
        return payload

    def read_record(self, *, project_id: str, reference: str) -> RunRevisionRecord:
        match = re.fullmatch(r"run_plan_revision:(run-revision-[0-9a-f]{64})@1", reference)
        if match is None:
            raise ValueError("saved runtime revision sequence is not readable")
        raw = self._read("run_plan_revision", match[1], 1, project_id)
        record = RunRevisionRecord.model_validate_json(json.dumps(raw), strict=True)
        if (
            record.record_id != match[1]
            or record.record_id != revision_record_id(project_id, record.run_id, record.intent_id)
            or record.input_digest
            != revision_input_digest(
                project_id=project_id,
                run_id=record.run_id,
                request_payload=record.request_payload,
                confirmation_ids=record.confirmation_ids,
            )
            or len(record.confirmation_ids) != len(set(record.confirmation_ids))
        ):
            raise ValueError("saved runtime revision identity or input cannot be verified")
        request_from_payload(record.request_payload, project_id)
        return record

    def read_snapshot(
        self, *, project_id: str, run_id: str, reference: SnapshotContentRef
    ) -> ExecutionFacts:
        raw = self._read("execution_facts", reference.snapshot_commit_id, 1, project_id)
        facts = ExecutionFacts.model_validate_json(json.dumps(raw), strict=True)
        if facts.run_id != run_id or SnapshotContentRef.of(facts) != reference:
            raise ValueError("runtime revision snapshot cannot be verified")
        return facts

    def read_effective_cases(
        self, *, facts: ExecutionFacts, plan: Plan, initial_cases: tuple[Case, ...]
    ) -> tuple[Case, ...]:
        references = facts.runtime_revision_refs
        if references != facts.run.runtime_revision_refs or len(references) != len(set(references)):
            raise ValueError("runtime revision sequence disagrees with the saved run")
        if not references:
            return initial_cases
        project_id, run_id = facts.project_id, facts.run_id
        original_run = TypeAdapter(Run).validate_python(self._read("run", run_id, 1, project_id))
        if original_run.origin_workspace_id != facts.run.origin_workspace_id:
            raise ValueError("runtime revision workspace cannot be verified")
        effective = {case.case_id: case for case in initial_cases}
        step_refs = {}
        original_steps = {}
        for fact in facts.steps:
            step = TypeAdapter(Step).validate_python(
                self._read("step", fact.step_id, 1, project_id)
            )
            if (step.run_id, step.case_id) != (run_id, fact.case_id):
                raise ValueError("runtime step origin cannot be verified")
            StepContentReader(self.records).read(run=original_run, step=step)
            original_steps[step.step_id] = step
            step_refs[step.step_id] = StepRevisionRefFact(
                step_revision_id=step.step_revision_ref.step_revision_id,
                revision_no=step.step_revision_ref.revision_no,
                digest=step.step_revision_ref.digest,
                inherited=step.step_revision_ref.inherited,
                base_step_revision_id=step.step_revision_ref.base_step_revision_id,
            )
        previous_ref = None
        for ordinal, reference in enumerate(references, 1):
            record = self.read_record(project_id=project_id, reference=reference)
            if (
                record.run_id != run_id
                or record.origin_workspace_id != facts.run.origin_workspace_id
                or record.revision_no != ordinal
                or record.previous_revision_ref != previous_ref
                or record.initial_plan_ref.model_dump() != facts.plan_revision.model_dump()
            ):
                raise ValueError(
                    "runtime revision order, ownership or frozen plan cannot be verified"
                )
            before = self.read_snapshot(
                project_id=project_id, run_id=run_id, reference=record.base_snapshot
            )
            after = self.read_snapshot(
                project_id=project_id, run_id=run_id, reference=record.result_snapshot
            )
            if (
                before.runtime_revision_refs != references[: ordinal - 1]
                or after.runtime_revision_refs != references[:ordinal]
                or before.run.runtime_revision_refs != before.runtime_revision_refs
                or after.run.runtime_revision_refs != after.runtime_revision_refs
                or record.result_snapshot.snapshot_cursor <= record.base_snapshot.snapshot_cursor
                or {s.step_id: s.step_revision_ref for s in before.steps} != step_refs
            ):
                raise ValueError("runtime revision snapshots do not prove the exact sequence")
            request = request_from_payload(record.request_payload, project_id)
            decision = request_runtime_revision(
                plan=plan,
                cases=tuple(effective.values()),
                confirmations=(),
                request=request,
                facts=before,
                effective_case_revisions=tuple(
                    DomainCaseRevisionRef(
                        case.case_id,
                        case.revision,
                        case_content_digest(case, project_id=project_id),
                    )
                    for case in effective.values()
                )
                if ordinal > 1
                else (),
            )
            if (
                not decision.accepted
                or decision.revision_no != ordinal
                or decision.pause_required != record.pause_required
                or decision.invalidated_basis_step_ids != record.invalidated_basis_step_ids
                or decision.effective_driver.value != record.effective_driver.value
                or after.run.driver != record.effective_driver
            ):
                raise ValueError("saved runtime revision no longer proves its guarded change")
            for change in request.case_changes:
                effective[change.next_case.case_id] = change.next_case
            expected_case_refs = tuple(
                sorted(
                    (
                        CaseRevisionRef(
                            case_id=case.case_id,
                            revision=case.revision,
                            digest=case_content_digest(case, project_id=project_id),
                        )
                        for case in effective.values()
                    ),
                    key=lambda ref: ref.case_id,
                )
            )
            if expected_case_refs != record.effective_case_refs:
                raise ValueError("runtime revision effective case set cannot be verified")
            for ref in expected_case_refs:
                saved_case = case_from_payload(
                    self._read("case", ref.case_id, ref.revision, project_id)
                )
                if saved_case != effective[
                    ref.case_id
                ] or saved_case.assertion_basis.text_digest != (
                    text_digest(saved_case.assertion_basis.text) or ""
                ):
                    raise ValueError("runtime effective case content cannot be verified")
            updates = {change.step_id: change for change in record.step_changes}
            if len(updates) != len(record.step_changes) or set(updates) != set(
                decision.affected_step_ids
            ):
                raise ValueError("runtime revision step changes do not match its exact guard")
            after_steps = {s.step_id: s for s in after.steps}
            for step_id, update in updates.items():
                if step_refs.get(step_id) != update.previous_ref:
                    raise ValueError("runtime revision step content chain is broken")
                step = replace(
                    original_steps[step_id],
                    step_revision_ref=StepRevisionRef(**update.next_ref.model_dump()),
                    level=StepLevel(after_steps[step_id].level.value),
                )
                body = StepContentReader(self.records).read(run=original_run, step=step)
                if body.case_revision_ref not in expected_case_refs:
                    raise ValueError("runtime step content differs from the effective case basis")
                step_refs[step_id] = update.next_ref
            if {s.step_id: s.step_revision_ref for s in after.steps} != step_refs:
                raise ValueError("runtime revision snapshot substitutes step content")
            if record.pause_required and (
                after.run.control_state.value != "paused"
                or any(s.state.value == "running" for s in after.steps)
                or any(
                    a.state.value
                    in {"intent_recorded", "starting", "running", "stop_requested", "collecting"}
                    for a in after.attempts
                )
            ):
                raise ValueError("runtime revision pause is not an actual step boundary")
            previous_ref = reference
        if {s.step_id: s.step_revision_ref for s in facts.steps} != step_refs:
            raise ValueError("current step content disagrees with the saved runtime sequence")
        return tuple(effective[case.case_id] for case in initial_cases)


class RuntimePlanningRecordReader:
    """Adapt the common A record port using the same strict envelope/context checks."""

    def __init__(self, records: SavedRuntimeRevisionReader, project_id: str) -> None:
        self.records, self.project_id = records, project_id

    def read(
        self, *, aggregate_kind: AggregateKind, record_id: str, revision: int
    ) -> CommittedRecord:
        return CommittedRecord(
            aggregate_kind,
            record_id,
            revision,
            self.records._read(aggregate_kind, record_id, revision, self.project_id),
        )
