"""Default publication must prove an exact controlled gesture and saved material."""

from aitest.contracts.commands import Command
from tests.unit.test_authoritative_preparation import authoritative as authoritative
from tests.unit.test_binding_controlled_origin import HUMAN, make_core


def test_a_bare_human_label_and_draft_boolean_cannot_publish_rules(tmp_path):
    core, _ = make_core(tmp_path)
    try:
        before = core.unit_of_work.current_commit_sequence()
        result = core.api.dispatch(
            Command(
                action="publish_rules",
                project_id="project",
                request_id="raw-rule-publication",
                intent_id="raw-rule-intent",
                expected_revision=0,
                parameters={
                    "project_revision": 1,
                    "expected_revision": 0,
                    "draft": {
                        "rule_id": "rule",
                        "revision": 7,
                        "scope": "project",
                        "text": "assert exact output",
                        "source": "manual",
                        "steps": ["compare output"],
                        "evidence_requirements": ["actual output"],
                        "confirmed": True,
                    },
                },
            ),
            HUMAN,
        )
        assert result.error is not None and result.error.code == "AWAITING_USER_CONFIRMATION"
        assert core.unit_of_work.repo.current_revision("rule_version", "rule") == 0
        assert core.unit_of_work.current_commit_sequence() == before
    finally:
        core.lifetime_lock.release()


def test_a_bare_human_label_cannot_publish_plan(authoritative):
    core, inputs, _ = authoritative
    repo = core.unit_of_work.repo
    scope = repo.read(
        aggregate_kind="acceptance_scope", record_id=inputs.scope_id, revision=1
    ).payload
    cases = [
        dict(repo.read(aggregate_kind="case", record_id=ref.case_id, revision=ref.revision).payload)
        for ref in inputs.case_revisions
    ]
    before = core.unit_of_work.current_commit_sequence()
    result = core.api.dispatch(
        Command(
            action="publish_plan",
            project_id=inputs.project_id,
            request_id="raw-plan-publication",
            intent_id="raw-plan-intent",
            expected_revision=0,
            parameters={
                "project_revision": 1,
                "expected_revision": 0,
                "plan_id": "untrusted-plan",
                "revision": 7,
                "scope": dict(scope),
                "cases": cases,
            },
        ),
        HUMAN,
    )
    assert result.error is not None and result.error.code == "AWAITING_USER_CONFIRMATION"
    assert repo.current_revision("plan", "untrusted-plan") == 0
    assert core.unit_of_work.current_commit_sequence() == before
