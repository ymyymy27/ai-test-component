"""Binding confirmation must be saved and consumed as exact controlled origin."""

from aitest.application.project.serialization import binding_to_payload, project_to_payload
from aitest.bootstrap import assemble_workspace_core
from aitest.contracts.commands import Command
from aitest.domain.project.context import BindingForm, LocalProject, LocalProjectBinding
from aitest.interfaces.local.api import EntryKind, Session

HUMAN = Session("binding-origin-fixture", EntryKind.HUMAN_UI, True)


def make_core(tmp_path):
    source = tmp_path / "tested"
    source.mkdir()
    (source / "main.py").write_text("VALUE = 1\n", encoding="utf-8")
    core = assemble_workspace_core(tmp_path / "workspace", instance_id="binding-origin-core")
    project = LocalProject("project", core.workspace.workspace_id, "binding", "goal", "0")
    response = core.api.dispatch(
        Command(
            action="save_context",
            project_id="project",
            request_id="owner-save",
            intent_id="owner-intent",
            expected_revision=0,
            parameters={"project": project_to_payload(project)},
        ),
        HUMAN,
    )
    assert response.error is None
    return core, LocalProjectBinding(
        "binding",
        1,
        "project",
        source.as_posix(),
        BindingForm.PLAIN,
        manifest_digest="declared-baseline",
        confirmed=True,
    )


def command(binding, *, intent="binding-intent", request="binding-request"):
    return Command(
        action="save_binding",
        project_id="project",
        intent_id=intent,
        request_id=request,
        expected_revision=0,
        parameters={
            "project_revision": 1,
            "expected_revision": 0,
            "binding": binding_to_payload(binding),
        },
    )


def test_a_bare_human_label_cannot_create_confirmed_binding(tmp_path):
    core, binding = make_core(tmp_path)
    try:
        before = core.unit_of_work.current_commit_sequence()
        response = core.api.dispatch(command(binding), HUMAN)
        assert response.error is not None
        assert response.error.code == "AWAITING_USER_CONFIRMATION"
        assert core.unit_of_work.repo.current_revision("binding", "binding") == 0
        assert core.unit_of_work.current_commit_sequence() == before
    finally:
        core.lifetime_lock.release()


def test_legacy_confirmed_binding_is_not_permission_to_pin_source(tmp_path, monkeypatch):
    core, binding = make_core(tmp_path)
    try:
        unit = core.unit_of_work
        unit.begin("legacy-binding", "project", intent_id="legacy-binding-intent")
        unit.stage_record(
            aggregate_kind="binding",
            record_id="binding",
            expected_revision=0,
            payload=binding_to_payload(binding),
        )
        unit.commit("legacy-binding")

        def forbidden(**kwargs):
            raise AssertionError("source pinning must not precede controlled origin validation")

        monkeypatch.setattr(core.snapshot_store, "pin", forbidden)
        before = unit.current_commit_sequence()
        response = core.api.dispatch(
            Command(
                action="analyze_project",
                project_id="project",
                request_id="legacy-pin",
                intent_id="legacy-pin-intent",
                expected_revision=0,
                binding_revision=1,
                parameters={"binding_id": "binding", "purpose": "prepare", "source_scope": "."},
            ),
            Session("binding-relay", EntryKind.AGENT_RELAY),
        )
        assert response.error is not None
        assert response.error.code == "B_SOURCE_UNVERIFIED"
        assert unit.current_commit_sequence() == before
    finally:
        core.lifetime_lock.release()
