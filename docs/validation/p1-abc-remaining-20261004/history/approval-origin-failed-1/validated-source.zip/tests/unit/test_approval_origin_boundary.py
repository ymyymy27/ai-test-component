"""A role label alone cannot supply an actual user confirmation fact."""

from aitest.application.planning.serialization import case_from_payload
from tests.unit.test_authoritative_preparation import authoritative as authoritative
from tests.unit.test_default_source_analysis import dispatch


def test_default_basis_confirmation_requires_a_core_challenge_and_user_interaction(authoritative):
    core, inputs, _ = authoritative
    reference = inputs.case_revisions[0]
    case = case_from_payload(
        core.unit_of_work.repo.read(
            aggregate_kind="case",
            record_id=reference.case_id,
            revision=reference.revision,
        ).payload
    )
    sequence = core.unit_of_work.current_commit_sequence()
    response = dispatch(
        core,
        "confirm_basis",
        project=inputs.project_id,
        request="no-user-gesture-request",
        intent="no-user-gesture-intent",
        parameters={
            "case_id": case.case_id,
            "case_revision": case.revision,
            "basis_revision": case.assertion_basis.revision,
            "basis_text_digest": case.assertion_basis.text_digest,
        },
    )
    assert response.error is not None
    assert response.error.code == "AWAITING_USER_CONFIRMATION"
    assert core.unit_of_work.current_commit_sequence() == sequence
