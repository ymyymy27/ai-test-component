"""Real default policy persistence with synthetic controlled events and provider transport."""

import json

import pytest
from pydantic import TypeAdapter

from aitest.application.project.context import create_project
from aitest.application.project.serialization import project_to_payload
from aitest.bootstrap import assemble_workspace_core
from aitest.contracts.commands import Command
from aitest.domain.planning.model_outbound import ModelOutboundPolicy
from aitest.infrastructure.adapters.model import HttpResponse
from aitest.infrastructure.credentials import EnvironmentSecretProvider, SecretManager
from aitest.interfaces.local.api import EntryKind, Session
from tests.unit.test_model_orchestration import PROJECT_ID, _policy


HUMAN = Session("model-policy-controlled-fixture", EntryKind.HUMAN_UI, True)
RELAY = Session("model-policy-relay-fixture", EntryKind.AGENT_RELAY)


@pytest.fixture
def policy_core(tmp_path, monkeypatch):
    monkeypatch.setenv("AITEST_POLICY_PROOF_FIXTURE", "synthetic-policy-proof-secret")
    policy = _policy()
    core = assemble_workspace_core(
        tmp_path / "workspace", instance_id="policy-proof-fixture",
        model_endpoint=policy.endpoint.address, model_secret_reference=("model", "policy-proof"),
        secret_manager=SecretManager((EnvironmentSecretProvider({
            ("model", "policy-proof"): "AITEST_POLICY_PROOF_FIXTURE",
        }),)),
    )
    project = create_project(project_id=PROJECT_ID, workspace_id=core.workspace.workspace_id,
                             name="policy proof", goal="draft only", created_at_commit="0")
    response = core.api.dispatch(Command(
        action="save_context", request_id="policy-project-request", intent_id="policy-project-intent",
        project_id=PROJECT_ID, expected_revision=0,
        parameters={"project": project_to_payload(project)},
    ), HUMAN)
    assert response.error is None
    calls = []

    class Transport:
        def post(self, url, *, headers, body, timeout_seconds):
            calls.append(url)
            return HttpResponse(200, json.dumps({"id":"fixture-model-response", "choices":[{
                "message":{"content":"safe policy draft"},
            }]}).encode())

    core.model_provider._transport = Transport()
    yield core, calls
    core.lifetime_lock.release()


def policy_command(*, policy=None, intent="model-policy-save-intent", request="model-policy-save-request",
                   expected=0):
    return Command(
        action="save_model_outbound_policy", project_id=PROJECT_ID, intent_id=intent,
        request_id=request, expected_revision=expected,
        parameters={"project_revision":1, "policy":TypeAdapter(ModelOutboundPolicy).dump_python(
            policy or _policy(), mode="json",
        )},
    )


def generation_command(*, intent="model-policy-generation", request="model-policy-generation-request"):
    return Command(action="generate_draft", project_id=PROJECT_ID, request_id=request, intent_id=intent,
                   expected_revision=0, parameters={
        "generation_mode":"model", "project_revision":1, "policy_revision":1,
        "source_revision":0, "base_manual_revision":0, "task_type":"check_content_draft",
        "draft_kind":"check_content", "selected_material":{"project_context":"safe selected context"},
    })


def test_role_and_client_confirmation_cannot_save_a_confirmed_model_policy(policy_core):
    core, calls = policy_core
    sequence = core.unit_of_work.current_commit_sequence()
    response = core.api.dispatch(policy_command(), HUMAN)
    assert response.error is not None
    assert response.error.code == "AWAITING_USER_CONFIRMATION"
    assert core.unit_of_work.current_commit_sequence() == sequence
    assert calls == []


def test_default_generation_cannot_use_a_legacy_policy_without_saved_origin(policy_core):
    core, calls = policy_core
    unit = core.unit_of_work
    unit.begin("legacy-policy-fixture", PROJECT_ID, intent_id="legacy-policy-fixture-intent")
    unit.stage_record(aggregate_kind="model_outbound_policy", record_id="model-policy:"+PROJECT_ID,
                      expected_revision=0, payload=TypeAdapter(ModelOutboundPolicy).dump_python(
                          _policy(), mode="json",
                      ))
    unit.commit("legacy-policy-fixture")
    sequence = unit.current_commit_sequence()
    response = core.api.dispatch(generation_command(), RELAY)
    assert response.error is not None
    assert response.error.code == "AWAITING_USER_CONFIRMATION"
    assert calls == []
    assert unit.current_commit_sequence() == sequence
