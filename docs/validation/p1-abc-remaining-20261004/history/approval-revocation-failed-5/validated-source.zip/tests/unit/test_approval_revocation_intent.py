"""Revocation is a persistent business intent, not merely an idempotent state setter."""

import pytest

from aitest.domain.approvals import ApprovalConflict, ApprovalRequired, ChallengeState
from tests.unit.test_approval_service import approvals as approvals
from tests.unit.test_approval_service import click, confirm, prepare


def test_same_revocation_intent_cannot_revoke_another_challenge(approvals):
    service, unit, _ = approvals
    first = prepare(service)
    second = service.prepare(
        project_id="project",
        action_intent_id="business2",
        preparation_intent_id="prepare2",
        request_id="request2",
        action="confirm_basis",
        target="case",
        parameters={"basis": "original"},
    )
    service.revoke(
        project_id="project",
        challenge_id=first.challenge_id,
        request_id="first-revocation-request",
        intent_id="same-revocation",
    )
    sequence = unit.sequence
    with pytest.raises(ApprovalConflict):
        service.revoke(
            project_id="project",
            challenge_id=second.challenge_id,
            request_id="second-revocation-request",
            intent_id="same-revocation",
        )
    assert unit.sequence == sequence
    assert service.read_challenge(project_id="project", challenge_id=second.challenge_id).state is (
        ChallengeState.PENDING
    )


@pytest.mark.parametrize(
    "missing", ["approval_confirmation", "approval_interaction", "approval_challenge"]
)
def test_missing_accurate_origin_returns_a_blocked_confirmation_not_a_raw_error(approvals, missing):
    service, unit, actors = approvals
    challenge = prepare(service)
    click(actors, challenge)
    saved = confirm(service, challenge)
    key = next(key for key in unit.saved if key[0] == missing and key[2] == 1)
    del unit.saved[key]
    with pytest.raises(ApprovalRequired):
        service.read_confirmation(project_id="project", confirmation_id=saved.confirmation_id)


def test_boolean_warehouse_revision_cannot_prove_an_immutable_confirmation(approvals, monkeypatch):
    service, unit, actors = approvals
    challenge = prepare(service)
    click(actors, challenge)
    saved = confirm(service, challenge)
    original = unit.current_revision

    def invalid_revision(**kwargs):
        if kwargs["aggregate_kind"] == "approval_confirmation":
            return True
        return original(**kwargs)

    monkeypatch.setattr(unit, "current_revision", invalid_revision)
    with pytest.raises(ApprovalRequired):
        service.read_confirmation(project_id="project", confirmation_id=saved.confirmation_id)
